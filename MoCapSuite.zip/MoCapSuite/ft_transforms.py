#from asyncio import start_server
#from multiprocessing import context
import bpy
from bpy.types import Operator
#from math import radians 
from bpy.props import *
from .ft_panel import FT_PT_Panel
from array import *
from mathutils import Quaternion
from mathutils import Vector
from mathutils import Euler
import math
from math import radians

import mathutils

class FT_OT_Transforms(Operator):

    bl_idname = "object.set_transforms" 
    bl_label = "Start mocap"

    HEAD_IK = None 
    Avatar_MESH = None
    TRACKING_Cam = None
    HEAD_TARGET_EMPTY = None
    
    lastFrameQ_w = None
    lastFrameQ_x = None
    lastFrameQ_y = None
    lastFrameQ_z = None
    difference_x = None
    difference_y = None
    difference_z = None
    camLastpos_x = None
    camLastpos_y = None
    camLastpos_z = None
    lastHeadPos_x = None
    lastHeadPos_y = None
    lastHeadPos_z = None

    cam_og_loc_x = None
    cam_og_loc_y = None
    cam_og_loc_z = None
    empty_og_loc_x = None
    empty_og_loc_y = None
    empty_og_loc_z = None
    empty_og_rot_w = None
    empty_og_rot_x = None
    empty_og_rot_y = None
    empty_og_rot_z = None
    cam_og_rot_w = None
    cam_og_rot_x = None
    cam_og_rot_y = None
    cam_og_rot_z = None

    face_og_loc_x = None
    face_og_loc_y = None
    face_og_loc_z = None
    face_og_rot_w = None
    face_og_rot_x = None
    face_og_rot_y = None
    face_og_rot_z = None

    cam_correction_x = None
    cam_correction_y = None
    cam_correction_z = None


    REC = False
    useArma = False
    
    cFirstFrame = True
    firstFrameQ = True 
    headFirstFrame = False

    rotFace = False
    movFace = False

    shapes = [
    'eyeblinkleft',
    'eyelookdownleft',
    'eyelookinleft',
    'eyelookoutleft',
    'eyelookupleft',
    'eyesquintleft',
    'eyewideleft',
    'eyeblinkright',
    'eyelookdownright',
    'eyelookinright',
    'eyelookoutright',
    'eyelookupright',
    'eyesquintright',
    'eyewideright',
    'jawforward',
    'jawleft',
    'jawopen',
    'jawright',
    'mouthpucker',
    'mouthfunnel',
    'mouthclose',
    'mouthsmileright',
    'mouthleft',
    'mouthright',
    'mouthsmileleft',
    'mouthfrownleft',
    'mouthfrownright',
    'mouthdimpleleft',
    'mouthdimpleright',
    'mouthstretchleft',
    'mouthstretchright',
    'mouthrollupper',
    'mouthrolllower',
    'mouthshrugupper',
    'mouthshruglower',
    'mouthpressleft',
    'mouthpressright',
    'mouthlowerdownleft',
    'mouthlowerdownright',
    'mouthupperupleft',
    'mouthupperupright',
    'browdownleft',
    'browdownright',
    'browinnerup',
    'browouterupright',
    'browouterupleft',
    'cheekpuff',
    'cheeksquintleft',
    'cheeksquintright',
    'nosesneerleft',
    'nosesneerright',
    'tongueout',
    ]

    def save_initial_values():

        if(FT_OT_Transforms.HEAD_IK is not None):

            FT_OT_Transforms.empty_og_rot_w = FT_OT_Transforms.HEAD_IK.rotation_quaternion[0]
            FT_OT_Transforms.empty_og_rot_x = FT_OT_Transforms.HEAD_IK.rotation_quaternion[1]
            FT_OT_Transforms.empty_og_rot_y = FT_OT_Transforms.HEAD_IK.rotation_quaternion[2]
            FT_OT_Transforms.empty_og_rot_z = FT_OT_Transforms.HEAD_IK.rotation_quaternion[3]
            FT_OT_Transforms.empty_og_loc_x = FT_OT_Transforms.HEAD_IK.location.x
            FT_OT_Transforms.empty_og_loc_y = FT_OT_Transforms.HEAD_IK.location.y
            FT_OT_Transforms.empty_og_loc_z = FT_OT_Transforms.HEAD_IK.location.z

        if(FT_OT_Transforms.TRACKING_Cam is not None):

            FT_OT_Transforms.cam_og_rot_w = FT_OT_Transforms.TRACKING_Cam.rotation_quaternion[0]
            FT_OT_Transforms.cam_og_rot_x = FT_OT_Transforms.TRACKING_Cam.rotation_quaternion[1]
            FT_OT_Transforms.cam_og_rot_y = FT_OT_Transforms.TRACKING_Cam.rotation_quaternion[2]
            FT_OT_Transforms.cam_og_rot_z = FT_OT_Transforms.TRACKING_Cam.rotation_quaternion[3]
            FT_OT_Transforms.cam_og_loc_x = FT_OT_Transforms.TRACKING_Cam.location.x
            FT_OT_Transforms.cam_og_loc_y = FT_OT_Transforms.TRACKING_Cam.location.y
            FT_OT_Transforms.cam_og_loc_z = FT_OT_Transforms.TRACKING_Cam.location.z

       # if(FT_OT_Transforms.CURRENT_Avatar is not None):
            # FT_OT_Transforms.face_og_loc_x = FT_OT_Transforms.Avatar_MESH.location.x
            # FT_OT_Transforms.face_og_loc_y = FT_OT_Transforms.Avatar_MESH.location.y
            # FT_OT_Transforms.face_og_loc_z = FT_OT_Transforms.Avatar_MESH.location.z
            # FT_OT_Transforms.face_og_rot_w = FT_OT_Transforms.Avatar_MESH.rotation_quaternion[0]
            # FT_OT_Transforms.face_og_rot_x = FT_OT_Transforms.Avatar_MESH.rotation_quaternion[1]
            # FT_OT_Transforms.face_og_rot_y = FT_OT_Transforms.Avatar_MESH.rotation_quaternion[2]
            # FT_OT_Transforms.face_og_rot_z = FT_OT_Transforms.Avatar_MESH.rotation_quaternion[3]

    def head_rotation_q(w,x,y,z):

        ao = FT_OT_Transforms.HEAD_IK
        #ao.rotation_mode = 'QUATERNION'

        #### TEST
        ao.rotation_quaternion[0] = w   #(FT_OT_Transforms.lastFrameQ_w - w)  #w  
        ao.rotation_quaternion[1] = -x  #(FT_OT_Transforms.lastFrameQ_x - x)#-x  
        ao.rotation_quaternion[2] = -z   #(FT_OT_Transforms.lastFrameQ_y - y)#-z  
        ao.rotation_quaternion[3] = -y   #(FT_OT_Transforms.lastFrameQ_z - z)#-y

        if FT_OT_Transforms.REC:
            ao.keyframe_insert(data_path="location", frame=bpy.data.scenes[0].frame_current)
            ao.keyframe_insert(data_path="rotation_quaternion", frame=bpy.data.scenes[0].frame_current)
        #rotQ = True

    quatCor = Quaternion((1,1,0,0))
    quatCam = Quaternion((0,0,0,0))
    quatHIPS = Quaternion((0,0,0,0))
    quatORIGO = Quaternion((0,0,0,0))
    quatORIGO_dif = Quaternion((0,0,0,0))
    
    def from_axis_angle(axis, angle):
        half_angle = angle / 2.0
        scalar = math.cos(half_angle)
        factor = math.sin(half_angle)

        return Quaternion((
            scalar,
            axis[0] * factor,
            axis[1] * factor,
            axis[2] * factor
        ))

    def moveCamera(cw,cx,cy,cz,tx,ty,tz):
    
        #if FT_OT_Transforms.cFirstFrame:
        cam = FT_OT_Transforms.TRACKING_Cam
         #   FT_OT_Transforms.cFirstFrame = False

        FT_OT_Transforms.quatCam[0] = cw
        FT_OT_Transforms.quatCam[1] = -cx
        FT_OT_Transforms.quatCam[2] = -cz
        FT_OT_Transforms.quatCam[3] = -cy
        world_quaternion = FT_OT_Transforms.quatCam

        y_rotation_angle_degrees = 180.0
        y_rotation_angle_radians = radians(y_rotation_angle_degrees)
        y_rotation_axis = (0.0, 1.0, 0.0)
        y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
        x_rotation_angle_degrees =-90.0
        x_rotation_angle_radians = radians(x_rotation_angle_degrees)
        x_rotation_axis = (1.0, 0.0, 0.0)
        x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
        z_rotation_angle_degrees = 180.0#-22.5
        z_rotation_angle_radians = radians(z_rotation_angle_degrees)
        z_rotation_axis = (0.0, 0.0, 1.0)
        z_rotation_quaternion_change = Quaternion(z_rotation_axis,z_rotation_angle_radians)                    
        new_rotation_quaternion = world_quaternion @ x_rotation_quaternion_change
        new_rotation_quaternion = new_rotation_quaternion @ y_rotation_quaternion_change
        new_rotation_quaternion = new_rotation_quaternion @ z_rotation_quaternion_change
        q = new_rotation_quaternion

        o = FT_OT_Transforms.quatCam  # use your object name here
        r_inv = o.inverted()
        CAM = FT_OT_Transforms.TRACKING_Cam
        t = Vector((tx, tz, ty))
        headLoc = FT_OT_Transforms.Avatar.matrix_world @ FT_OT_Transforms.bones[5].matrix.translation

        headLoc_cor = Vector((headLoc.x,headLoc.z,headLoc.y))
        camLoc = headLoc - t

        FT_OT_Transforms.TRACKING_Cam.rotation_quaternion = q 

       # c = Vector(FT_OT_Transforms.TRACKING_Cam.location)
        f = headLoc - t
        c = headLoc - t

       # CAM.location = f# Vector((f.y, f.x, f.z))
        fin = Vector((c.y, c.x, c.z))
        CAM.location = camLoc#t# Vector((f.y, f.x, f.z))
        #CAM.location.x = camLoc.x
        #CAM.location.y = camLoc.y
        #CAM.location.z = camLoc.z
        #FT_OT_Transforms.TRACKING_Cam.location.y = ty#(FT_OT_Transforms.camLastpos_y - ty)
        #FT_OT_Transforms.TRACKING_Cam.location.z = tz#(FT_OT_Transforms.camLastpos_z - tz)
        ao = FT_OT_Transforms.TRACKING_Cam

        if FT_OT_Transforms.REC:
            ao.keyframe_insert(data_path="location", frame=bpy.data.scenes[0].frame_current)
            ao.keyframe_insert(data_path="rotation_quaternion", frame=bpy.data.scenes[0].frame_current)

    def moveHIPS(cw,cx,cy,cz,tx,tz,ty):

        FT_OT_Transforms.quatHIPS[3] = cw
        FT_OT_Transforms.quatHIPS[0] = -cx
        FT_OT_Transforms.quatHIPS[2] = -cz
        FT_OT_Transforms.quatHIPS[1] = -cy
        o = FT_OT_Transforms.quatHIPS  # use your object name here
        r_inv = o.inverted()

        FT_OT_Transforms.HIP_IK_TARGET.rotation_quaternion = FT_OT_Transforms.IK_PARENT.rotation_quaternion

        FT_OT_Transforms.HIP_IK_TARGET.location.x = -tx#(FT_OT_Transforms.camLastpos_x - tx) 
        FT_OT_Transforms.HIP_IK_TARGET.location.y = -ty#(FT_OT_Transforms.camLastpos_y - ty)
        FT_OT_Transforms.HIP_IK_TARGET.location.z = -tz#(FT_OT_Transforms.camLastpos_z - tz)
        ao = FT_OT_Transforms.HIP_IK_TARGET

        if FT_OT_Transforms.REC:
            ao.keyframe_insert(data_path="location", frame=bpy.data.scenes[0].frame_current)
            ao.keyframe_insert(data_path="rotation_quaternion", frame=bpy.data.scenes[0].frame_current)

            # ao.keyframe_insert(data_path="rotation_quaternion")
            # ao.keyframe_insert(data_path="location")
    ORIGO = None

    def SetOrigo_PosRot(px,py,pz,w,x,y,z):

        FT_OT_Transforms.IK_PARENT.location.x = 0
        FT_OT_Transforms.IK_PARENT.location.y = 0
        FT_OT_Transforms.IK_PARENT.location.z = 0
        # FT_OT_Transforms.IK_PARENT.location.x = -px
        # FT_OT_Transforms.IK_PARENT.location.y = -py
        # FT_OT_Transforms.IK_PARENT.location.z = -pz
        FT_OT_Transforms.quatORIGO[0] = -y
        FT_OT_Transforms.quatORIGO[1] = -x
        FT_OT_Transforms.quatORIGO[2] = -z
        FT_OT_Transforms.quatORIGO[3] = w
        FT_OT_Transforms.quatORIGO_dif[0] = w
        FT_OT_Transforms.quatORIGO_dif[1] = -x
        FT_OT_Transforms.quatORIGO_dif[2] = -z
        FT_OT_Transforms.quatORIGO_dif[3] = -y
       # q = FT_OT_Transforms.IK_PARENT.matrix_world.to_quaternion().rotation_difference(FT_OT_Transforms.HIP_IK_TARGET.matrix_world.to_quaternion())
        euler = FT_OT_Transforms.quatORIGO.to_euler()


        zero_orientation = Quaternion((0, 0, 0, 1))
        diff = zero_orientation.rotation_difference(FT_OT_Transforms.quatORIGO)
        #q = empty1.matrix_world.to_quaternion().rotation_difference(empty2.matrix_world.to_quaternion())

       # q_inv = q.invert()

       # FT_OT_Transforms.IK_PARENT.rotation_quaternion = FT_OT_Transforms.quatORIGO
        FT_OT_Transforms.IK_PARENT.rotation_quaternion = diff
        #euler = FT_OT_Transforms.quatORIGO.to_euler()


        zero_orientation = Quaternion((0, 0, 0, 1))
        _diff = zero_orientation.rotation_difference(FT_OT_Transforms.IK_PARENT.rotation_quaternion)
        #q = empty1.matrix_world.to_quaternion().rotation_difference(empty2.matrix_world.to_quaternion())

       # q_inv = q.invert()

       # FT_OT_Transforms.IK_PARENT.rotation_quaternion = FT_OT_Transforms.quatORIGO
        FT_OT_Transforms.ORIGO.rotation_quaternion = _diff

       # FT_OT_Transforms.ORIGO.rotation_quaternion = FT_OT_Transforms.ORIGO.parent.rotation_quaternion
       # FT_OT_Transforms.IK_PARENT.rotation_quaternion = FT_OT_Transforms.ORIGO.parent.rotation_quaternion
        #print('origorot')

    def moveHead(x,z,y):
        ao = FT_OT_Transforms.HEAD_IK
        ao.location.x = -x 
        ao.location.y = -y
        ao.location.z = -z

        if FT_OT_Transforms.REC:
            ao.keyframe_insert(data_path="location", frame=bpy.data.scenes[0].frame_current)
            ao.keyframe_insert(data_path="rotation_quaternion", frame=bpy.data.scenes[0].frame_current)
        return
    test = False

    def process_command(arr):
        #print(FT_OT_Transforms.a)
        i = 0
        if FT_OT_Transforms.rotQ:
            #print("going to rotQ")
            FT_OT_Transforms.head_rotation_q(arr[0], arr[1], arr[2], arr[3])
            i = 3
            #print("out of rotQ")
            for y in FT_OT_Transforms.Avatar_MESH.data.shape_keys.key_blocks:
                if(i < (52 + 4) and not 3):
                    y.value = arr[i]
                    #print(arr[i])
                    if FT_PT_Panel.REC_shapes == True:
                        y.keyframe_insert("value", frame=bpy.data.scenes[0].frame_current)
                    i += 1
                if(i == 3):
                    y.value = 0
                    i += 1

    def process_handIKs(rpos_x, rpos_y, rpos_z, rrot_w, rrot_x, rrot_y, rrot_z, lpos_x, lpos_y, lpos_z, lrot_w, lrot_x, lrot_y, lrot_z):
        
        r_IK = FT_OT_Transforms.HAND_IK_TARGET_R
        r_IK.location.x = -rpos_x 
        r_IK.location.y = -rpos_z
        r_IK.location.z = -rpos_y
        #return
        l_IK = FT_OT_Transforms.HAND_IK_TARGET_L
        l_IK.location.x = -lpos_x
        l_IK.location.y = -lpos_z
        l_IK.location.z = -lpos_y

        #### TEST
        r_IK.rotation_quaternion[0] = rrot_w   #(FT_OT_Transforms.lastFrameQ_w - w)  #w  
        r_IK.rotation_quaternion[1] = -rrot_x  #(FT_OT_Transforms.lastFrameQ_x - x)#-x  
        r_IK.rotation_quaternion[2] = -rrot_z   #(FT_OT_Transforms.lastFrameQ_y - y)#-z  
        r_IK.rotation_quaternion[3] = -rrot_y
        #### TEST
        l_IK.rotation_quaternion[0] = lrot_w   #(FT_OT_Transforms.lastFrameQ_w - w)  #w  
        l_IK.rotation_quaternion[1] = -lrot_x  #(FT_OT_Transforms.lastFrameQ_x - x)#-x  
        l_IK.rotation_quaternion[2] = -lrot_z   #(FT_OT_Transforms.lastFrameQ_y - y)#-z  
        l_IK.rotation_quaternion[3] = -lrot_y 
        #return

        if FT_OT_Transforms.REC:
            ao = r_IK
            ao.keyframe_insert(data_path="location", frame=bpy.data.scenes[0].frame_current)
            ao.keyframe_insert(data_path="rotation_quaternion", frame=bpy.data.scenes[0].frame_current)
        if FT_OT_Transforms.REC:
            ao = l_IK
            ao.keyframe_insert(data_path="location", frame=bpy.data.scenes[0].frame_current)
            ao.keyframe_insert(data_path="rotation_quaternion", frame=bpy.data.scenes[0].frame_current)


    def process_legIKs(rpos_x, rpos_y, rpos_z, rrot_w, rrot_x, rrot_y, rrot_z, lpos_x, lpos_y, lpos_z, lrot_w, lrot_x, lrot_y, lrot_z):
        
        r_IK = FT_OT_Transforms.LEG_IK_TARGET_R
        r_IK.location.x = -rpos_x 
        r_IK.location.y = -rpos_z
        r_IK.location.z = -rpos_y

        if FT_OT_Transforms.REC:
           FT_OT_Transforms.LEG_IK_TARGET_R.keyframe_insert(data_path="location")
        #return
        l_IK = FT_OT_Transforms.LEG_IK_TARGET_L
        l_IK.location.x = -lpos_x
        l_IK.location.y = -lpos_z
        l_IK.location.z = -lpos_y


        if FT_OT_Transforms.REC:
          FT_OT_Transforms.LEG_IK_TARGET_L.keyframe_insert(data_path="location")

        zero_orientation = Quaternion((0, 0, 0, 1))
        diff = zero_orientation.rotation_difference(FT_OT_Transforms.quatORIGO)
        l_IK.rotation_quaternion = FT_OT_Transforms.IK_PARENT.rotation_quaternion
        #### TEST
        # r_IK.rotation_quaternion[3] = rrot_w   #(FT_OT_Transforms.lastFrameQ_w - w)  #w  
        # r_IK.rotation_quaternion[0] = -rrot_x  #(FT_OT_Transforms.lastFrameQ_x - x)#-x  
        # r_IK.rotation_quaternion[1] = -rrot_z   #(FT_OT_Transforms.lastFrameQ_y - y)#-z  
        # r_IK.rotation_quaternion[2] = -rrot_y

        quat_lk = Quaternion()
        #### TEST
        l_IK.rotation_quaternion = FT_OT_Transforms.IK_PARENT.rotation_quaternion
        # l_IK.rotation_quaternion[3] = lrot_w   #(FT_OT_Transforms.lastFrameQ_w - w)  #w  
        # l_IK.rotation_quaternion[0] = -lrot_x  #(FT_OT_Transforms.lastFrameQ_x - x)#-x  
        # l_IK.rotation_quaternion[1] = -lrot_z   #(FT_OT_Transforms.lastFrameQ_y - y)#-z  
        # l_IK.rotation_quaternion[2] = -lrot_y 
        #return

    HAND_IK_TARGET_L = None
    HAND_IK_TARGET_R = None
    LEG_IK_TARGET_R = None
    LEG_IK_TARGET_L = None
    HIP_IK_TARGET = None
    IK_PARENT = None

    def process_bs(values):

        # _values = values#[:52]
        # for i, value in enumerate(_values):
        #     for key in (FT_OT_Transforms.Avatar_MESH.data.shape_keys.key_blocks):
        #         if key.name.lower() == FT_OT_Transforms.shapes[i].lower():
        #             #check if value is greater than 1 if it is then divide it by 100
        #             if values[i+1] > 1:
        #                 values[i+1] = values[i+1]/100

        #             key.value = values[i+1]
        #             if FT_OT_Transforms.REC: #bpy.data.scenes[0].REC_shapes == True:
        #                 key.keyframe_insert("value", frame=bpy.data.scenes[0].frame_current)
        _values = values[:52]
        for i, value in enumerate(_values):
            for key in (FT_OT_Transforms.Avatar_MESH.data.shape_keys.key_blocks):
                if key.name.lower() == FT_OT_Transforms.shapes[i].lower():
                    #check if value is greater than 1 if it is then divide it by 100
                    #if values[i+1] > 1:
                    #    values[i+1] = values[i+1]/100

                    key.value = values[i]
                    if FT_OT_Transforms.REC: #bpy.data.scenes[0].REC_shapes == True:
                        key.keyframe_insert("value", frame=bpy.data.scenes[0].frame_current)
    firstPose = True
    empties = []
    # function to process mediapipe pose data


#
#    public const int Nose = 0;
#    public const int LeftEyeInner = 1;
#    public const int LeftEye = 2;
#    public const int LeftEyeOuter = 3;
#    public const int RightEyeInner = 4;
#    public const int RightEye = 5;
#    public const int RightEyeOuter = 6;
#    public const int LeftEar = 7;
#    public const int RightEar = 8;
#    public const int MouthLeft = 9;
#    public const int MouthRight = 10;
#    public const int LeftShoulder = 11;
#    public const int RightShoulder = 12;
#    public const int LeftElbow = 13;
#    public const int RightElbow = 14;
#    public const int LeftWrist = 15;
#    public const int RightWrist = 16;
#    public const int LeftPinky = 17;
#    public const int RightPinky = 18;
#    public const int LeftIndex = 19;
#    public const int RightIndex = 20;
#    public const int LeftThumb = 21;
#    public const int RightThumb = 22;
#    public const int LeftHip = 23;
#    public const int RightHip = 24;
#    public const int LeftKnee = 25;
#    public const int RightKnee = 26;
#    public const int LeftAnkle = 27;
#    public const int RightAnkle = 28;
#    public const int LeftHeel = 29;
#    public const int RightHeel = 30;
#    public const int LeftFootIndex = 31;
#    public const int RightFootIndex = 32;

    bones = []
    zero_dif = []
    Avatar = None
    AVATAR_PARENT =  None
    first = False
    def allBones(b):
            _range = int(len(b)/4)
            print('range', _range)
            for i in range(_range - 1, -1, -1):
                if(FT_OT_Transforms.first):
                    for i in range(_range):
                        world_matrix = FT_OT_Transforms.Avatar.matrix_world @ FT_OT_Transforms.bones[i].matrix
                        world_rotation = world_matrix.to_3x3().to_euler('XYZ')
                        print(f"World Rotation of : {world_rotation}")
                        FT_OT_Transforms.zero_dif.append((world_rotation.to_quaternion()).inverted())
                        FT_OT_Transforms.first = False
                        
                if(i == 0):
                #continue
                    world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))
                    y_rotation_angle_degrees = 0.0
                    y_rotation_angle_radians = radians(y_rotation_angle_degrees)
                    y_rotation_axis = (0.0, 1.0, 0.0)
                    y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
                    x_rotation_angle_degrees = 90.0
                    x_rotation_angle_radians = radians(x_rotation_angle_degrees)
                    x_rotation_axis = (1.0, 0.0, 0.0)
                    x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                    z_rotation_angle_degrees = 0.0#-22.5
                    z_rotation_angle_radians = radians(z_rotation_angle_degrees)
                    z_rotation_axis = (0.0, 0.0, 1.0)
                    z_rotation_quaternion_change = Quaternion(z_rotation_axis,z_rotation_angle_radians)                    
                    new_rotation_quaternion = world_quaternion @ x_rotation_quaternion_change
                    new_rotation_quaternion = new_rotation_quaternion @ y_rotation_quaternion_change
                    new_rotation_quaternion = new_rotation_quaternion @ z_rotation_quaternion_change
                    q = new_rotation_quaternion
                    qfin = Quaternion((q.w, -q.x, q.y,q.z))

                    FT_OT_Transforms.bones[i].rotation_quaternion = qfin #Quaternion((r.w, r.x, r.y, r.z))
                    continue

                world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))
                y_rotation_angle_degrees = 0.0
                y_rotation_angle_radians = radians(y_rotation_angle_degrees)
                y_rotation_axis = (0.0, 1.0, 0.0)
                y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
                x_rotation_angle_degrees = 0.0
                x_rotation_angle_radians = radians(x_rotation_angle_degrees)
                x_rotation_axis = (1.0, 0.0, 0.0)
                x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                z_rotation_angle_degrees = 0.0#-22.5
                z_rotation_angle_radians = radians(z_rotation_angle_degrees)
                z_rotation_axis = (0.0, 0.0, 1.0)
                z_rotation_quaternion_change = Quaternion(z_rotation_axis,z_rotation_angle_radians)                    
                new_rotation_quaternion = world_quaternion @ x_rotation_quaternion_change
                new_rotation_quaternion = new_rotation_quaternion @ y_rotation_quaternion_change
                new_rotation_quaternion = new_rotation_quaternion @ z_rotation_quaternion_change
                q = new_rotation_quaternion
                qfin = Quaternion((q.w, -q.x, q.y,q.z))

                FT_OT_Transforms.bones[i].rotation_quaternion = qfin #Quaternion((r.w, r.x, r.y, r.z))

            return
            for i in range(_range - 1, -1, -1):

                world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))
                y_rotation_angle_degrees = 0.0
                y_rotation_angle_radians = radians(y_rotation_angle_degrees)
                y_rotation_axis = (0.0, 1.0, 0.0)
                y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
                x_rotation_angle_degrees = 0.0
                x_rotation_angle_radians = radians(x_rotation_angle_degrees)
                x_rotation_axis = (1.0, 0.0, 0.0)
                x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                z_rotation_angle_degrees = 0.0#-22.5
                z_rotation_angle_radians = radians(z_rotation_angle_degrees)
                z_rotation_axis = (0.0, 0.0, 1.0)
                z_rotation_quaternion_change = Quaternion(z_rotation_axis,z_rotation_angle_radians)                    
                new_rotation_quaternion = world_quaternion @ x_rotation_quaternion_change
                new_rotation_quaternion = new_rotation_quaternion @ y_rotation_quaternion_change
                new_rotation_quaternion = new_rotation_quaternion @ z_rotation_quaternion_change
                q = new_rotation_quaternion

                # final = world_quaternion @ correction
                qfin = Quaternion((-q.w, q.x, -q.z, -q.y))
                FT_OT_Transforms.bones[i].rotation_quaternion = qfin
                continue


                if(i == 0):
                    world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))
                    y_rotation_angle_degrees = 0.0
                    y_rotation_angle_radians = radians(y_rotation_angle_degrees)
                    y_rotation_axis = (0.0, 1.0, 0.0)
                    y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
                    x_rotation_angle_degrees = -90.0
                    x_rotation_angle_radians = radians(x_rotation_angle_degrees)
                    x_rotation_axis = (1.0, 0.0, 0.0)
                    x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                    new_rotation_quaternion = world_quaternion @ x_rotation_quaternion_change
                    #new_rotation_quaternion = new_rotation_quaternion @ y_rotation_quaternion_change
                    q = new_rotation_quaternion

                    qfin = Quaternion((q.w, -q.x,-q.y, q.z))
                    FT_OT_Transforms.bones[i].rotation_quaternion = qfin

                    #FT_OT_Transforms.bones[i].rotation_quaternion = new_rotation_quaternion
                    continue
                if(i == 9):


                    # world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))
                    # y_rotation_angle_degrees = 180.0
                    # y_rotation_angle_radians = radians(y_rotation_angle_degrees)
                    # y_rotation_axis = (0.0, 1.0, 0.0)
                    # y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
                    # x_rotation_angle_degrees = 90.0
                    # x_rotation_angle_radians = radians(x_rotation_angle_degrees)
                    # x_rotation_axis = (1.0, 0.0, 0.0)
                    # qa= world_quaternion
                    # x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                    # new_rotation_quaternion = qa @ x_rotation_quaternion_change
                    # new_rotation_quaternion = new_rotation_quaternion @ y_rotation_quaternion_change
                    # q = new_rotation_quaternion
                    # #q = world_quaternion
                    # # final = world_quaternion @ correction
                    # # qfin = Quaternion((q.w, q.x,-q.y, q.z))
                    # # FT_OT_Transforms.bones[i].rotation_quaternion = qfin

                    # q = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))
                    # # final = world_quaternion @ correction
                    # qfin = Quaternion((q.w, q.x,-q.y, -q.z))
                    # FT_OT_Transforms.bones[i].rotation_quaternion = qfin

                    continue
                    world_quaternion = Quaternion((b[i * 4],-b[i * 4 + 1],-b[i * 4 + 2],-b[i * 4 + 3]))
                    y_rotation_angle_degrees = 180.0
                    y_rotation_angle_radians = radians(y_rotation_angle_degrees)
                    y_rotation_axis = (0.0, 1.0, 0.0)
                    y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
                    x_rotation_angle_degrees = 90.0
                    x_rotation_angle_radians = radians(x_rotation_angle_degrees)
                    x_rotation_axis = (1.0, 0.0, 0.0)
                    x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                    z_rotation_angle_degrees = 90.0
                    z_rotation_angle_radians = radians(z_rotation_angle_degrees)
                    z_rotation_axis = (0.0, 0.0, 1.0)
                    z_rotation_quaternion_change = Quaternion(z_rotation_axis,z_rotation_angle_radians)                    
                    new_rotation_quaternion = world_quaternion @ y_rotation_quaternion_change
                    new_rotation_quaternion = new_rotation_quaternion @ x_rotation_quaternion_change
                    new_rotation_quaternion = new_rotation_quaternion @ z_rotation_quaternion_change
                    FT_OT_Transforms.bones[i].rotation_quaternion = new_rotation_quaternion
                if(i == 10):

                    
                    world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))
                    y_rotation_angle_degrees = 0.0
                    y_rotation_angle_radians = radians(y_rotation_angle_degrees)
                    y_rotation_axis = (0.0, 1.0, 0.0)
                    y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
                    x_rotation_angle_degrees = -45.0
                    x_rotation_angle_radians = radians(x_rotation_angle_degrees)
                    x_rotation_axis = (1.0, 0.0, 0.0)
                    x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                    z_rotation_angle_degrees = 0.0
                    z_rotation_angle_radians = radians(z_rotation_angle_degrees)
                    z_rotation_axis = (0.0, 0.0, 1.0)
                    z_rotation_quaternion_change = Quaternion(z_rotation_axis,z_rotation_angle_radians)                    
                    new_rotation_quaternion = world_quaternion @ x_rotation_quaternion_change
                    new_rotation_quaternion = new_rotation_quaternion @ y_rotation_quaternion_change
                    new_rotation_quaternion = new_rotation_quaternion @ z_rotation_quaternion_change
                    q = new_rotation_quaternion


                    # final = world_quaternion @ correction
                    qfin = Quaternion((q.w, q.x, -q.y, -q.z))
                    FT_OT_Transforms.bones[i].rotation_quaternion = qfin

                    continue



                    world_quaternion = Quaternion((b[i * 4],-b[i * 4 + 1],-b[i * 4 + 2],-b[i * 4 + 3]))
                    y_rotation_angle_degrees = 90.0
                    y_rotation_angle_radians = radians(y_rotation_angle_degrees)
                    y_rotation_axis = (0.0, 1.0, 0.0)
                    y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
                    x_rotation_angle_degrees = 90.0
                    x_rotation_angle_radians = radians(x_rotation_angle_degrees)
                    x_rotation_axis = (1.0, 0.0, 0.0)
                    x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                    new_rotation_quaternion = world_quaternion @ y_rotation_quaternion_change
                    #new_rotation_quaternion = new_rotation_quaternion @ x_rotation_quaternion_change
                    FT_OT_Transforms.bones[i].rotation_quaternion = new_rotation_quaternion
                    continue
                if(i == 33):

                    continue
                    q = Quaternion((b[i * 4],-b[i * 4 + 1],b[i * 4 + 2],-b[i * 4 + 3]))
                    # final = world_quaternion @ correction
                    qfin = Quaternion((q.w, -q.x,-q.y, q.z))
                    FT_OT_Transforms.bones[i].rotation_quaternion = qfin

                    world_quaternion = Quaternion((b[i * 4],-b[i * 4 + 1],-b[i * 4 + 2],-b[i * 4 + 3]))
                    y_rotation_angle_degrees = 180.0
                    y_rotation_angle_radians = radians(y_rotation_angle_degrees)
                    y_rotation_axis = (0.0, 1.0, 0.0)
                    y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
                    x_rotation_angle_degrees = -90.0
                    x_rotation_angle_radians = radians(x_rotation_angle_degrees)
                    x_rotation_axis = (1.0, 0.0, 0.0)
                    x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                    new_rotation_quaternion = world_quaternion @ y_rotation_quaternion_change
                    new_rotation_quaternion = new_rotation_quaternion @ x_rotation_quaternion_change
                    FT_OT_Transforms.bones[i].rotation_quaternion = new_rotation_quaternion
                   # continue
                if(i == 34):
                    world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))
                    y_rotation_angle_degrees = 0.0
                    y_rotation_angle_radians = radians(y_rotation_angle_degrees)
                    y_rotation_axis = (0.0, 1.0, 0.0)
                    y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
                    x_rotation_angle_degrees = -45.0
                    x_rotation_angle_radians = radians(x_rotation_angle_degrees)
                    x_rotation_axis = (1.0, 0.0, 0.0)
                    x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                    new_rotation_quaternion = world_quaternion @ x_rotation_quaternion_change
                    #new_rotation_quaternion = new_rotation_quaternion @ y_rotation_quaternion_change
                    q = new_rotation_quaternion


                    # final = world_quaternion @ correction
                    qfin = Quaternion((q.w, q.x, q.y, -q.z))
                    FT_OT_Transforms.bones[i].rotation_quaternion = qfin

                    continue
                if(i == 57):

                    world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))
                    y_rotation_angle_degrees = 180.0
                    y_rotation_angle_radians = radians(y_rotation_angle_degrees)
                    y_rotation_axis = (0.0, 1.0, 0.0)
                    y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
                    x_rotation_angle_degrees = 180.0
                    x_rotation_angle_radians = radians(x_rotation_angle_degrees)
                    x_rotation_axis = (1.0, 0.0, 0.0)
                    x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                    new_rotation_quaternion = world_quaternion @ x_rotation_quaternion_change
                    new_rotation_quaternion = new_rotation_quaternion @ y_rotation_quaternion_change
                    q = new_rotation_quaternion

                    # q = Quaternion((b[i * 4],-b[i * 4 + 1],b[i * 4 + 2],-b[i * 4 + 3]))
                    # final = world_quaternion @ correction
                    qfin = Quaternion((q.w, -q.x,q.y, -q.z))
                    FT_OT_Transforms.bones[i].rotation_quaternion = qfin

                    continue
                if(i == 62):

                    world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))
                    y_rotation_angle_degrees = 180.0
                    y_rotation_angle_radians = radians(y_rotation_angle_degrees)
                    y_rotation_axis = (0.0, 1.0, 0.0)
                    y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
                    x_rotation_angle_degrees = 180.0
                    x_rotation_angle_radians = radians(x_rotation_angle_degrees)
                    x_rotation_axis = (1.0, 0.0, 0.0)
                    x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                    new_rotation_quaternion = world_quaternion @ x_rotation_quaternion_change
                    new_rotation_quaternion = new_rotation_quaternion @ y_rotation_quaternion_change
                    q = new_rotation_quaternion

                    # q = Quaternion((b[i * 4],-b[i * 4 + 1],b[i * 4 + 2],-b[i * 4 + 3]))
                    # final = world_quaternion @ correction
                    qfin = Quaternion((q.w, -q.x,q.y, -q.z))
                    FT_OT_Transforms.bones[i].rotation_quaternion = qfin
                    continue

                world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))
                y_rotation_angle_degrees = 0.0
                y_rotation_angle_radians = radians(y_rotation_angle_degrees)
                y_rotation_axis = (0.0, 1.0, 0.0)
                y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)
                x_rotation_angle_degrees = 0.0
                x_rotation_angle_radians = radians(x_rotation_angle_degrees)
                x_rotation_axis = (1.0, 0.0, 0.0)
                x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                z_rotation_angle_degrees = 0.0#-22.5
                z_rotation_angle_radians = radians(z_rotation_angle_degrees)
                z_rotation_axis = (0.0, 0.0, 1.0)
                z_rotation_quaternion_change = Quaternion(z_rotation_axis,z_rotation_angle_radians)                    
                new_rotation_quaternion = world_quaternion @ x_rotation_quaternion_change
                new_rotation_quaternion = new_rotation_quaternion @ y_rotation_quaternion_change
                new_rotation_quaternion = new_rotation_quaternion @ z_rotation_quaternion_change
                q = new_rotation_quaternion

                # final = world_quaternion @ correction
                qfin = Quaternion((q.w, q.x, q.y, q.z))
                FT_OT_Transforms.bones[i].rotation_quaternion = qfin
                    ## HOX MINUS X ADDED COULD CHANGE STUFF
                # q = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))
                # # final = world_quaternion @ correction
                # qfin = Quaternion((q.w, q.x,-q.y, -q.z))
                # FT_OT_Transforms.bones[i].rotation_quaternion = qfin
                #FT_OT_Transforms.bones[i].rotation_quaternion = world_quaternion
                continue
                
                if(pyllu):
                    world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))
                    y_rotation_angle_degrees = 180.0

                    # Convert the angle to radians
                    y_rotation_angle_radians = radians(y_rotation_angle_degrees)

                    # Define the rotation axis (y-axis)
                    y_rotation_axis = (0.0, 1.0, 0.0)

                    # Create a quaternion representing the desired rotation
                    y_rotation_quaternion_change = Quaternion(y_rotation_axis,y_rotation_angle_radians)


                    x_rotation_angle_degrees = 90.0

                    # Convert the angle to radians
                    x_rotation_angle_radians = radians(x_rotation_angle_degrees)

                    # Define the rotation axis (y-axis)
                    x_rotation_axis = (1.0, 0.0, 0.0)

                    # Create a quaternion representing the desired rotation
                    x_rotation_quaternion_change = Quaternion(x_rotation_axis,x_rotation_angle_radians)                    
                    
                    # Rotate the original quaternion by the desired amount
                    new_rotation_quaternion = world_quaternion @ y_rotation_quaternion_change
                    new_rotation_quaternion = new_rotation_quaternion @ x_rotation_quaternion_change

                    # final = world_quaternion @ correction
                    FT_OT_Transforms.bones[i].rotation_quaternion = new_rotation_quaternion
                    #world_quaternion = Quaternion((0,0,0,0))
                    # final = world_quaternion @ correction
                    #FT_OT_Transforms.bones[i].rotation_quaternion = world_quaternion
                    continue
                if(i == 33):
                    # rotation_angle_degrees = 90.0
                    # world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],-b[i * 4 + 2],b[i * 4 + 3]))

                    # # Convert the angle to radians
                    # rotation_angle_radians = radians(rotation_angle_degrees)

                    # # Define the rotation axis (y-axis)
                    # rotation_axis = (0.0, 1.0, 0.0)

                    # # Create a quaternion representing the desired rotation
                    # rotation_quaternion_change = Quaternion(rotation_axis,rotation_angle_radians)

                    # # Rotate the original quaternion by the desired amount
                    # new_rotation_quaternion =  FT_OT_Transforms.bones[i].rotation_quaternion @ rotation_quaternion_change

                    # # final = world_quaternion @ correction
                    # FT_OT_Transforms.bones[i].rotation_quaternion = new_rotation_quaternion
                    continue
                if(i == 34):


# Define the rotation angle in degrees
                    rotation_angle_degrees = -90.0
                    world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],b[i * 4 + 2],b[i * 4 + 3]))

                    # Convert the angle to radians
                    rotation_angle_radians = radians(rotation_angle_degrees)

                    # Define the rotation axis (y-axis)
                    rotation_axis = (1.0, 0.0, 0.0)

                    # Create a quaternion representing the desired rotation
                    rotation_quaternion_change = Quaternion(rotation_axis,rotation_angle_radians)

                    # Rotate the original quaternion by the desired amount
                    new_rotation_quaternion = world_quaternion @ rotation_quaternion_change

                    # final = world_quaternion @ correction
                    FT_OT_Transforms.bones[i].rotation_quaternion = world_quaternion
                    #world_quaternion = Quaternion((0,0,0,0))
                    # final = world_quaternion @ correction
                    #FT_OT_Transforms.bones[i].rotation_quaternion = world_quaternion
                    continue
                if(i == 9):
                    continue
                if(i == 10):

                    world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],-b[i * 4 + 2],b[i * 4 + 3]))
                    # final = world_quaternion @ correction
                    FT_OT_Transforms.bones[i].rotation_quaternion = world_quaternion
                    #world_quaternion = Quaternion((0,0,0,0))
                    # final = world_quaternion @ correction
                    #FT_OT_Transforms.bones[i].rotation_quaternion = world_quaternion
                    continue

                world_quaternion = Quaternion((b[i * 4],b[i * 4 + 1],-b[i * 4 + 2],b[i * 4 + 3]))
                # final = world_quaternion @ correction
                FT_OT_Transforms.bones[i].rotation_quaternion = world_quaternion
                    #left
                # if(i == 9):

                # else:
                # #correction = Quaternion((-0.2353829 ,0.3812674, 0.4696361, -0.7607049))
                #     world_quaternion = Quaternion((-b[i * 4],b[i * 4 + 1],-b[i * 4 + 2],-b[i * 4 + 3]))

                # # final = world_quaternion @ correction
                #     FT_OT_Transforms.bones[i].rotation_quaternion = world_quaternion
                
                
                #     x = b[i * 4 + 1] 
                #     y = b[i * 4 + 3]
                #     z = b[i * 4 + 2] 
                #     euler_angles = [math.radians(x), math.radians(y +90), math.radians(z)]
                #     correction = [math.radians(90),math.radians(0),math.radians(0)]
                #     FT_OT_Transforms.bones[i].rotation_euler = euler_angles 
                #     continue
                # if(i == 33):
                #     x = b[i * 4 + 1] 
                #     y = b[i * 4 + 3]
                #     z = b[i * 4 + 2] 
                
                #     euler_angles = [math.radians(x), math.radians(y +90), math.radians(z)]
                #     correction = [math.radians(90),math.radians(0),math.radians(0)]
                #     FT_OT_Transforms.bones[i].rotation_euler = euler_angles 
                #     continue
                # if(i == 57):
                #     x = b[i * 4 + 1] 
                #     y = b[i * 4 + 3]
                #     z = b[i * 4 + 2] 
                #     euler_angles = [math.radians(x +180), math.radians(y), math.radians(z)]
                #     correction = [math.radians(90),math.radians(0),math.radians(0)]
                #     FT_OT_Transforms.bones[i].rotation_euler = euler_angles 
                #     continue
                # if(i == 62):
                #     x = b[i * 4 + 1] 
                #     y = b[i * 4 + 3]
                #     z = b[i * 4 + 2] 
                #     euler_angles = [math.radians(x +180 ), math.radians(y), math.radians(z)]
                #     correction = [math.radians(90),math.radians(0),math.radians(0)]
                #     FT_OT_Transforms.bones[i].rotation_euler = euler_angles 
                #     continue

                # x = b[i * 4 + 1]
                # y = b[i * 4 + 3]
                # z = b[i * 4 + 2] 
                # euler_angles = [math.radians(x), math.radians(y), math.radians(z)]
                # world_quaternion = Quaternion((1,0,0,0))
                # correction = [math.radians(0),math.radians(0),math.radians(0)]
                # #euler_angles = [math.radians(x), math.radians(y), math.radians(z)]
                # FT_OT_Transforms.bones[i].rotation_euler = euler_angles
                    #right  
                # if(i > 32 and i < 57):

                #     x = -b[i * 4 + 1]
                #     y = b[i * 4 + 3]
                #     z = -b[i * 4 + 2] 
                #     euler_angles = [math.radians(x), math.radians(y), math.radians(z)]
                #     correction = [math.radians(90),math.radians(0),math.radians(0)]
                #     FT_OT_Transforms.bones[i].rotation_euler = euler_angles 
                #     #left   
                # if(i > 57 and i < 63):
                #     x = b[i * 4 + 1]
                #     y = -b[i * 4 + 3]
                #     z = -b[i * 4 + 2] 
                #     euler_angles = [math.radians(x), math.radians(y), math.radians(z)]
                #     correction = [math.radians(90),math.radians(0),math.radians(0)]
                #     FT_OT_Transforms.bones[i].rotation_euler = euler_angles    
                #     #right

                # if(i > 62 and i < 68):
                #     x = b[i * 4 + 1]
                #     y = -b[i * 4 + 3]
                #     z = -b[i * 4 + 2] 
                #     euler_angles = [math.radians(x), math.radians(y), math.radians(z)]
                #     correction = [math.radians(90),math.radians(0),math.radians(0)]
                #     FT_OT_Transforms.bones[i].rotation_euler = euler_angles    



            # for i in range(_range):
            #         continue
            # #else:


            #     correction_x =  -90
            #     correction_y =  -180
            #     correction_z =  0
            #     if(i == 58):
            #         x = b[i * 4 + 1]
            #         y = b[i * 4 + 3]
            #         z = b[i * 4 + 2]
            #         euler_angles = [math.radians(x + correction_x), math.radians(y + correction_y), math.radians(z + correction_z)]
            #         correction = [math.radians(correction_x),math.radians(correction_y),math.radians(correction_z)]
            #         FT_OT_Transforms.bones[i].rotation_euler = euler_angles 
            #         continue          
            #     if(i == 63):
            #         x = b[i * 4 + 1] + correction_x
            #         y = b[i * 4 + 3] + correction_y
            #         z = b[i * 4 + 2] + correction_z
            #         euler_angles = [math.radians(x + correction_x), math.radians(y + correction_y), math.radians(z + correction_z)]
            #         correction = [math.radians(90),math.radians(0),math.radians(0)]
            #         FT_OT_Transforms.bones[i].rotation_euler = euler_angles 
            #         continue          
            #     if(i == 34):
            #         x = b[i * 4 + 1] + correction_x
            #         y = b[i * 4 + 3] + correction_y
            #         z = b[i * 4 + 2] + correction_z
            #         euler_angles = [math.radians(x + correction_x), math.radians(y + correction_y), math.radians(z + correction_z)]
            #         correction = [math.radians(90),math.radians(0),math.radians(0)]
            #         FT_OT_Transforms.bones[i].rotation_euler = euler_angles 
            #         continue         
            #     if(i == 10):
            #         x = b[i * 4 + 1] + correction_x
            #         y = b[i * 4 + 3] + correction_y
            #         z = b[i * 4 + 2] + correction_z
            #         euler_angles = [math.radians(x + correction_x), math.radians(y + correction_y), math.radians(z + correction_z)]
            #         correction = [math.radians(90),math.radians(0),math.radians(0)]
            #         FT_OT_Transforms.bones[i].rotation_euler = euler_angles  
            #         continue         
              
       


    def process_pose(values):
        #make 33 empties 
        #print how many values we have
        print(len(values))
        if FT_OT_Transforms.firstPose:
            for i in range(33):
                bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                bpy.context.selected_objects[0].name = 'mp'+str(i)
                FT_OT_Transforms.empties.append(bpy.data.objects['mp'+str(i)])
            FT_OT_Transforms.firstPose = False
        #set the empties locations
        for i in range(33):
            #if(values[i*3] is not 0):
                #make empty visible
                #empties[i].hide_viewport = False
                FT_OT_Transforms.empties[i].location.x = values[i*3]
            #else:
                #make empty invisible
                #empties[i].hide_viewport = True
            #if(values[i*3+1] is not 0):
                FT_OT_Transforms.empties[i].location.y = values[i*3+1]
            #if(values[i*3+2] is not 0):
                FT_OT_Transforms.empties[i].location.z = values[i*3+2]

    firstHand = True
    r_hand_empties = []
    l_hand_empties = []
    #function to process mediapipe hand data
    def process_hand(values):
        #make 21 r_hand empties
        #make 21 l_hand empties
        if FT_OT_Transforms.firstHand:
            for i in range(21):
                bpy.ops.object.empty_add(type='ARROWS', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                bpy.context.selected_objects[0].name = 'r_hand'+str(i)
                bpy.ops.object.empty_add(type='ARROWS', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                bpy.context.selected_objects[0].name = 'l_hand'+str(i)

            #get the empties
            for i in range(21):
                #change r_hand empties color to red
                bpy.data.objects['r_hand'+str(i)].empty_display_size = 0.1
                FT_OT_Transforms.r_hand_empties.append(
                    bpy.data.objects['r_hand'+str(i)])

                #change l_hand empties color to blue
                bpy.data.objects['l_hand'+str(i)].empty_display_size = 0.1
                FT_OT_Transforms.l_hand_empties.append(
                    bpy.data.objects['l_hand'+str(i)])
            FT_OT_Transforms.firstHand = False

        #set the empties locations
        for i in range(21):
            if(values[i*3] is not 0):
                #make empty visible if its not
                #r_hand_empties[i].hide_viewport = False
                FT_OT_Transforms.r_hand_empties[i].location.x = values[i*3]
            #else:
                #make empty invisible
                #r_hand_empties[i].hide_viewport = True
            if (values[i*3+1] is not 0):
                FT_OT_Transforms.r_hand_empties[i].location.y = values[i*3+1]
            if(values[i*3+2] is not 0):
                FT_OT_Transforms.r_hand_empties[i].location.z = values[i*3+2]
            if(values[i*3+63] is not 0):
                #make empty visible if its not
                #r_hand_empties[i].hide_viewport = False
                FT_OT_Transforms.l_hand_empties[i].location.x = values[i*3+63]
            #else:
                #make empty invisible
                #r_hand_empties[i].hide_viewport = True
            if (values[i*3+64] is not 0):
                FT_OT_Transforms.l_hand_empties[i].location.y = values[i*3+64]
            if(values[i*3+65] is not 0):
                FT_OT_Transforms.l_hand_empties[i].location.z = values[i*3+65]
        ## make empties look at 

        #bpy.data.objects.get(f'r_hand{i}')
        # R
        # 1
        FT_OT_Transforms.r_hand_empties[1]
        direction = FT_OT_Transforms.r_hand_empties[2].location - FT_OT_Transforms.r_hand_empties[1].location
        up_vector = FT_OT_Transforms.r_hand_empties[1-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[1].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[1].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 2
        FT_OT_Transforms.r_hand_empties[2]
        direction = FT_OT_Transforms.r_hand_empties[3].location - FT_OT_Transforms.r_hand_empties[2].location
        up_vector = FT_OT_Transforms.r_hand_empties[2-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[2].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[2].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 3
        FT_OT_Transforms.r_hand_empties[3]
        direction = FT_OT_Transforms.r_hand_empties[4].location - FT_OT_Transforms.r_hand_empties[3].location
        up_vector = FT_OT_Transforms.r_hand_empties[3-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[3].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[3].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 5
        FT_OT_Transforms.r_hand_empties[5]
        direction = FT_OT_Transforms.r_hand_empties[6].location - FT_OT_Transforms.r_hand_empties[5].location
        up_vector = FT_OT_Transforms.r_hand_empties[5-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[5].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[5].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 6
        FT_OT_Transforms.r_hand_empties[6]
        direction = FT_OT_Transforms.r_hand_empties[7].location - FT_OT_Transforms.r_hand_empties[6].location
        up_vector = FT_OT_Transforms.r_hand_empties[6-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[6].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[6].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 7
        FT_OT_Transforms.r_hand_empties[7]
        direction = FT_OT_Transforms.r_hand_empties[8].location - FT_OT_Transforms.r_hand_empties[7].location
        up_vector = FT_OT_Transforms.r_hand_empties[7-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[7].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[7].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 9
        FT_OT_Transforms.r_hand_empties[9]
        direction = FT_OT_Transforms.r_hand_empties[10].location - FT_OT_Transforms.r_hand_empties[9].location
        up_vector = FT_OT_Transforms.r_hand_empties[9-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[9].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[9].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 10
        FT_OT_Transforms.r_hand_empties[10]
        direction = FT_OT_Transforms.r_hand_empties[11].location - FT_OT_Transforms.r_hand_empties[10].location
        up_vector = FT_OT_Transforms.r_hand_empties[10-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[10].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[10].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 11
        FT_OT_Transforms.r_hand_empties[11]
        direction = FT_OT_Transforms.r_hand_empties[12].location - FT_OT_Transforms.r_hand_empties[11].location
        up_vector = FT_OT_Transforms.r_hand_empties[11-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[11].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[11].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 13
        FT_OT_Transforms.r_hand_empties[13]
        direction = FT_OT_Transforms.r_hand_empties[14].location - FT_OT_Transforms.r_hand_empties[13].location
        up_vector = FT_OT_Transforms.r_hand_empties[13-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[13].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[13].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 14
        FT_OT_Transforms.r_hand_empties[14]
        direction = FT_OT_Transforms.r_hand_empties[15].location - FT_OT_Transforms.r_hand_empties[14].location
        up_vector = FT_OT_Transforms.r_hand_empties[14-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[14].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[14].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 15
        FT_OT_Transforms.r_hand_empties[15]
        direction = FT_OT_Transforms.r_hand_empties[16].location - FT_OT_Transforms.r_hand_empties[15].location
        up_vector = FT_OT_Transforms.r_hand_empties[15-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[15].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[15].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 17
        FT_OT_Transforms.r_hand_empties[17]
        direction = FT_OT_Transforms.r_hand_empties[18].location - FT_OT_Transforms.r_hand_empties[17].location
        up_vector = FT_OT_Transforms.r_hand_empties[17-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[17].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[17].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 19
        FT_OT_Transforms.r_hand_empties[19]
        direction = FT_OT_Transforms.r_hand_empties[20].location - FT_OT_Transforms.r_hand_empties[19].location
        up_vector = FT_OT_Transforms.r_hand_empties[19-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[19].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[19].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 18
        FT_OT_Transforms.r_hand_empties[18]
        direction = FT_OT_Transforms.r_hand_empties[19].location - FT_OT_Transforms.r_hand_empties[18].location
        up_vector = FT_OT_Transforms.r_hand_empties[18-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.r_hand_empties[18].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.r_hand_empties[18].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        
        #L

        FT_OT_Transforms.l_hand_empties[1]
        direction = FT_OT_Transforms.l_hand_empties[2].location - FT_OT_Transforms.l_hand_empties[1].location
        up_vector = FT_OT_Transforms.l_hand_empties[1-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[1].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[1].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 2
        FT_OT_Transforms.l_hand_empties[2]
        direction = FT_OT_Transforms.l_hand_empties[3].location - FT_OT_Transforms.l_hand_empties[2].location
        up_vector = FT_OT_Transforms.l_hand_empties[2-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[2].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[2].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 3
        FT_OT_Transforms.l_hand_empties[3]
        direction = FT_OT_Transforms.l_hand_empties[4].location - FT_OT_Transforms.l_hand_empties[3].location
        up_vector = FT_OT_Transforms.l_hand_empties[3-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[3].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[3].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 5
        FT_OT_Transforms.l_hand_empties[5]
        direction = FT_OT_Transforms.l_hand_empties[6].location - FT_OT_Transforms.l_hand_empties[5].location
        up_vector = FT_OT_Transforms.l_hand_empties[5-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[5].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[5].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 6
        FT_OT_Transforms.l_hand_empties[6]
        direction = FT_OT_Transforms.l_hand_empties[7].location - FT_OT_Transforms.l_hand_empties[6].location
        up_vector = FT_OT_Transforms.l_hand_empties[6-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[6].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[6].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 7
        FT_OT_Transforms.l_hand_empties[7]
        direction = FT_OT_Transforms.l_hand_empties[8].location - FT_OT_Transforms.l_hand_empties[7].location
        up_vector = FT_OT_Transforms.l_hand_empties[7-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[7].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[7].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 9
        FT_OT_Transforms.l_hand_empties[9]
        direction = FT_OT_Transforms.l_hand_empties[10].location - FT_OT_Transforms.l_hand_empties[9].location
        up_vector = FT_OT_Transforms.l_hand_empties[9-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[9].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[9].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 10
        FT_OT_Transforms.l_hand_empties[10]
        direction = FT_OT_Transforms.l_hand_empties[11].location - FT_OT_Transforms.l_hand_empties[10].location
        up_vector = FT_OT_Transforms.l_hand_empties[10-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[10].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[10].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 11
        FT_OT_Transforms.l_hand_empties[11]
        direction = FT_OT_Transforms.l_hand_empties[12].location - FT_OT_Transforms.l_hand_empties[11].location
        up_vector = FT_OT_Transforms.l_hand_empties[11-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[11].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[11].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 13
        FT_OT_Transforms.l_hand_empties[13]
        direction = FT_OT_Transforms.l_hand_empties[14].location - FT_OT_Transforms.l_hand_empties[13].location
        up_vector = FT_OT_Transforms.l_hand_empties[13-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[13].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[13].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 14
        FT_OT_Transforms.l_hand_empties[14]
        direction = FT_OT_Transforms.l_hand_empties[15].location - FT_OT_Transforms.l_hand_empties[14].location
        up_vector = FT_OT_Transforms.l_hand_empties[14-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[14].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[14].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 15
        FT_OT_Transforms.l_hand_empties[15]
        direction = FT_OT_Transforms.l_hand_empties[16].location - FT_OT_Transforms.l_hand_empties[15].location
        up_vector = FT_OT_Transforms.l_hand_empties[15-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[15].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[15].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 17
        FT_OT_Transforms.l_hand_empties[17]
        direction = FT_OT_Transforms.l_hand_empties[18].location - FT_OT_Transforms.l_hand_empties[17].location
        up_vector = FT_OT_Transforms.l_hand_empties[17-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[17].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[17].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 19
        FT_OT_Transforms.l_hand_empties[19]
        direction = FT_OT_Transforms.l_hand_empties[20].location - FT_OT_Transforms.l_hand_empties[19].location
        up_vector = FT_OT_Transforms.l_hand_empties[19-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[19].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[19].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
        # 18
        FT_OT_Transforms.l_hand_empties[18]
        direction = FT_OT_Transforms.l_hand_empties[19] - FT_OT_Transforms.l_hand_empties[18].location
        up_vector = FT_OT_Transforms.l_hand_empties[18-1].matrix_world.to_quaternion() @ Vector((0, 0, 1))
        FT_OT_Transforms.l_hand_empties[18].rotation_euler = direction.to_track_quat('Z', 'Y').to_euler()
        FT_OT_Transforms.l_hand_empties[18].rotation_euler.rotate_axis('Z', up_vector.angle(direction))
    
    headBone = None        
    RightArm = None
    LeftArm = None
    RightForeArm = None
    LeftForeArm = None
    RightHand = None
    LeftHand = None
    Hips = None
    RightUpLeg = None
    LeftUpLeg = None
    RightLeg = None
    LeftLeg = None
    RightFoot = None
    LeftFoot = None
    RightShoulder = None
    LeftShoulder = None

    def boneData(d):

        print(len(d))
        print('bonedata start')
        FT_OT_Transforms.Hips.rotation_quaternion = Quaternion((d[87], d[88], d[89], d[90]))
        FT_OT_Transforms.headBone.rotation_quaternion = Quaternion((d[59], d[60], d[61], d[62]))
        FT_OT_Transforms.RightArm.rotation_quaternion = Quaternion((d[63], d[64], d[65], d[66]))
        FT_OT_Transforms.RightForeArm.rotation_quaternion = Quaternion((d[71],d[72], d[73], d[74]))
        FT_OT_Transforms.RightHand.rotation_quaternion = Quaternion((d[79], d[80], d[81], d[82]))
        
       # FT_OT_Transforms.LeftArm.rotation_quaternion = Quaternion((d[67], d[68], -d[69], -d[70]))
        #FT_OT_Transforms.LeftForeArm.rotation_quaternion = Quaternion((d[75], d[76], -d[77], -d[78]))
        #FT_OT_Transforms.LeftHand.rotation_quaternion = Quaternion((d[83], d[84], -d[85],- d[86]))
       # FT_OT_Transforms.RightShoulder.rotation_quaternion = Quaternion((d[169], d[170], d[172], d[171]))
        #FT_OT_Transforms.LeftArm.rotation_quaternion = Quaternion((d[63], d[64], d[65], d[66]))
       # FT_OT_Transforms.LeftShoulder.rotation_quaternion = Quaternion((
       # d[173], d[174], d[176], d[175]))
       # FT_OT_Transforms.LeftShoulder.rotation_quaternion = Quaternion((d[173], d[174], -d[175], -d[176]))
        #FT_OT_Transforms.RightShoulder.rotation_quaternion = Quaternion((d[173], d[174], -d[175], -d[176]))
     #   FT_OT_Transforms.LeftShoulder.rotation_quaternion = Quaternion((d[173], d[174], d[176], d[175]))
       
       
        #FT_OT_Transforms.RightUpLeg.rotation_quaternion = Quaternion((d[91], d[92], -d[93], -d[94]))
       # FT_OT_Transforms.LeftUpLeg.rotation_quaternion = Quaternion((d[95], d[96], -d[97], -d[98]))
       
       
       
        ## only one float value "x"
        #FT_OT_Transforms.RightLeg.rotation_quaternion = Quaternion((d[91], d[92]))
        #FT_OT_Transforms.RightLeg.rotation_quaternion = Quaternion((d[93], d[94]))
        ###
        #FT_OT_Transforms.RightFoot.rotation_quaternion = Quaternion((d[95], d[96], d[97], d[98]))
        #FT_OT_Transforms.LeftFoot.rotation_quaternion = Quaternion((d[99], d[100], d[101], d[102]))

    def reset_blendShapes(cam, ik, face):

        if(face is not None):
            #ao = face
            print('face not none')
            for shape in face.data.shape_keys.key_blocks:
                shape.value = 0
            for index, shape in enumerate(face.data.shape_keys.key_blocks):
                print(index, shape)
            # face.location.x = FT_OT_Transforms.face_og_loc_x
            # face.location.y = FT_OT_Transforms.face_og_loc_y
            # face.location.z = FT_OT_Transforms.face_og_loc_z
            # face.rotation_quaternion[0]= FT_OT_Transforms.face_og_rot_w
            # face.rotation_quaternion[1]= FT_OT_Transforms.face_og_rot_x
            # face.rotation_quaternion[2]= FT_OT_Transforms.face_og_rot_y
            # face.rotation_quaternion[3]= FT_OT_Transforms.face_og_rot_z

        if(ik is not None):
            ik.location.x = FT_OT_Transforms.empty_og_loc_x
            ik.location.y = FT_OT_Transforms.empty_og_loc_y
            ik.location.z = FT_OT_Transforms.empty_og_loc_z

            ik.rotation_quaternion[0]= FT_OT_Transforms.empty_og_rot_w
            ik.rotation_quaternion[1]= FT_OT_Transforms.empty_og_rot_x
            ik.rotation_quaternion[2]= FT_OT_Transforms.empty_og_rot_y
            ik.rotation_quaternion[3]= FT_OT_Transforms.empty_og_rot_z


        if(cam is not None):

            cam.location.x = FT_OT_Transforms.cam_og_loc_x
            cam.location.y = FT_OT_Transforms.cam_og_loc_y
            cam.location.z = FT_OT_Transforms.cam_og_loc_z

            cam.rotation_quaternion[0]= FT_OT_Transforms.cam_og_rot_w
            cam.rotation_quaternion[1]= FT_OT_Transforms.cam_og_rot_x
            cam.rotation_quaternion[2]= FT_OT_Transforms.cam_og_rot_y
            cam.rotation_quaternion[3]= FT_OT_Transforms.cam_og_rot_z