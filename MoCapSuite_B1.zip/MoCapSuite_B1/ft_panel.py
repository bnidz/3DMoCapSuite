#from doctest import BLANKLINE_MARKER
#from math import fabs
import bpy 
#from bpy.types import Operator
from bpy.props import (StringProperty, PointerProperty, IntProperty)             
from bpy.types import (Panel, PropertyGroup, Scene)
from bpy import context
import socket

class FT_PT_Panel(Panel):

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_label = "Live MoCap settings"
    bl_category = "MoCap Suite"

    # @classmethod
    # def poll(self,context):
    #     if context.object is None:
    #         #FT_PT_Panel.ObjestSelected = False
    #         return False
    #     else:
    #         FT_PT_Panel.ObjestSelected = True
    #         return True
        
   #     return context.object is not None
    
    context = None
    scene = None
    start_server = None
    stop_server = None

    col1 = None
    col2 = None
    col3 = None
    col4 = None
    col5 = None
    col6 = None
    col7 = None
    col8 = None
    col9 = None

    IP_property = None
    prop_search = None
    enableStart = True
    enableRec = False

    enableStop = False
    track_face_rot = None
    track_cam = None
    Rig_Armature = None
    TRACKING_face = None
    TRACKING_bone = None
    TRACKING_cam = None
    REC_shapes = None
    REC_running = False

    REC_ENABLED = True
    empty_Done = False

    InfoText = ""

    Changed_Avatar = None
#    ### --- maybe wont need this function --- 
    def EnableStopButton(bool):
        FT_PT_Panel.enableStop = bool
    def EnableStartButton(bool):
        FT_PT_Panel.enableStart = bool

    panel_self = None
    panel_context = None
    firstGO = True

    ObjestSelected = False
    SelectedObject = None

    def getNetifaces_stuff():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            # doesn't even have to be reachable
            s.connect(('10.255.255.255', 1))
            IP = s.getsockname()[0]
        except:
            IP = '127.0.0.1'
        finally:
            s.close()
            #FT_PT_Panel.IP_property = IP
        return IP

    def draw(self, context):

        layout = self.layout
        self.scene = context.scene

        #### --- LAYOUT ORDER ---
        row1 = layout.row()
        layout.separator()
        row5 = layout.row()
        row3 = layout.row()
        row6 = layout.row()
        row2 = layout.row()
       # layout.separator()
        row4 = layout.row()
        row7 = layout.row()
        row8 = layout.row()
        row9 = layout.row()

        #### --- // ---
        FT_PT_Panel.col1 = row1.column()
        FT_PT_Panel.col2 = row2.column()
        FT_PT_Panel.col5 = row5.column()
        FT_PT_Panel.col3 = row3.column()
        FT_PT_Panel.col4 = row4.column()
        FT_PT_Panel.col6 = row6.column()
        FT_PT_Panel.col7 = row7.column()
        FT_PT_Panel.col8 = row8.column()
        FT_PT_Panel.col9 = row9.column()

        if(FT_PT_Panel.firstGO):
            FT_PT_Panel.col5.operator("object.dona_model", text="DEFAULT MODEL")
            FT_PT_Panel.InfoText = "No Avatar Selected."
        
        #bpy.context.window_manager.popup_menu(title="Hello World!", icon='INFO')        if FT_PT_Panel.ObjestSelected:

        if context.object is not None:
            print('check for if its applicable object')
            o = context.object
            if o.name == "Armature" or o.name == "CURRENT_Avatar" or o.name == "PREVIOUS_Avatar" or o.name == "Avatar_MESH":
                FT_PT_Panel.SelectedObject = o
                FT_PT_Panel.ObjestSelected = True
                FT_PT_Panel.InfoText = "Ready to Check Avatar"
            else:
                FT_PT_Panel.ObjestSelected = False

            FT_PT_Panel.col2.enabled = True
        else:
            FT_PT_Panel.InfoText = "No Avatar Selected."
            FT_PT_Panel.col5.enabled = True

            FT_PT_Panel.col2.enabled = False

        #### --- START & STOP BUTTONS ---
        if FT_PT_Panel.enableStart == True:
            #if FT_PT_Panel.Changed_Avatar is not None:
            FT_PT_Panel.col2.operator("object.start_server", text="START")
        else:
            FT_PT_Panel.col2.operator("object.stop_server", text="STOP")
            FT_PT_Panel.col5.enabled = False
        FT_PT_Panel.col3.label(text= FT_PT_Panel.InfoText)
        
        #FT_PT_Panel.col5.operator("object.dona_model", text="DEFAULT MODEL")

        #### --- OP / PROP DECLARATIONS ---
        FT_PT_Panel.col1.label(text='IP: {} '.format(FT_PT_Panel.getNetifaces_stuff()))

            
        #### --- TYPE IP & TYPE PORT ---        
        IP_property = FT_PT_Panel.col1.prop(context.scene, "IP_property")
        PORT_property = FT_PT_Panel.col1.prop(context.scene, "PORT_property")
        if FT_PT_Panel.IP_property is None:
            FT_PT_Panel.IP_property = IP_property


        #### --- REC BUTTON --- 
        if(FT_PT_Panel.REC_running == False):
            FT_PT_Panel.col4.operator("object.start_rec", text="RECORD")
            if FT_PT_Panel.REC_ENABLED == False:
                FT_PT_Panel.col4.enabled = False
        else:
            FT_PT_Panel.col4.operator("object.stop_rec", text="STOP REC")

        if FT_PT_Panel.enableRec:
            FT_PT_Panel.col4.enabled = True
        if FT_PT_Panel.enableRec == False:
            FT_PT_Panel.col4.enabled = False