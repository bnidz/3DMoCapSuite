#from asyncio import start_server
#from multiprocessing import context
import bpy
from bpy.types import Operator
#from math import radians 
from bpy.props import *
from .ft_panel import FT_PT_Panel
from array import *
from mathutils import Quaternion



class FT_OT_Transforms(Operator):

    bl_idname = "object.set_transforms" 
    bl_label = "Start mocap"

    HEAD_IK = None 
    Avatar_MESH = None
    TRACKING_Cam = None
    HEAD_TARGET_EMPTY = None
    
    lastFrameQ_w = None
    lastFrameQ_x = None
    lastFrameQ_y = None
    lastFrameQ_z = None
    difference_x = None
    difference_y = None
    difference_z = None
    camLastpos_x = None
    camLastpos_y = None
    camLastpos_z = None
    lastHeadPos_x = None
    lastHeadPos_y = None
    lastHeadPos_z = None

    cam_og_loc_x = None
    cam_og_loc_y = None
    cam_og_loc_z = None
    empty_og_loc_x = None
    empty_og_loc_y = None
    empty_og_loc_z = None
    empty_og_rot_w = None
    empty_og_rot_x = None
    empty_og_rot_y = None
    empty_og_rot_z = None
    cam_og_rot_w = None
    cam_og_rot_x = None
    cam_og_rot_y = None
    cam_og_rot_z = None

    face_og_loc_x = None
    face_og_loc_y = None
    face_og_loc_z = None
    face_og_rot_w = None
    face_og_rot_x = None
    face_og_rot_y = None
    face_og_rot_z = None

    cam_correction_x = None
    cam_correction_y = None
    cam_correction_z = None


    REC = False
    useArma = False
    
    cFirstFrame = True
    firstFrameQ = True 
    headFirstFrame = False

    rotFace = False
    movFace = False

    shapes = [
    'eyeblinkleft',
    'eyelookdownleft',
    'eyelookinleft',
    'eyelookoutleft',
    'eyelookupleft',
    'eyesquintleft',
    'eyewideleft',
    'eyeblinkright',
    'eyelookdownright',
    'eyelookinright',
    'eyelookoutright',
    'eyelookupright',
    'eyesquintright',
    'eyewideright',
    'jawforward',
    'jawleft',
    'jawopen',
    'jawright',
    'mouthpucker',
    'mouthfunnel',
    'mouthclose',
    'mouthsmileright',
    'mouthleft',
    'mouthright',
    'mouthsmileleft',
    'mouthfrownleft',
    'mouthfrownright',
    'mouthdimpleleft',
    'mouthdimpleright',
    'mouthstretchleft',
    'mouthstretchright',
    'mouthrollupper',
    'mouthrolllower',
    'mouthshrugupper',
    'mouthshruglower',
    'mouthpressleft',
    'mouthpressright',
    'mouthlowerdownleft',
    'mouthlowerdownright',
    'mouthupperupleft',
    'mouthupperupright',
    'browdownleft',
    'browdownright',
    'browinnerup',
    'browouterupright',
    'browouterupleft',
    'cheekpuff',
    'cheeksquintleft',
    'cheeksquintright',
    'nosesneerleft',
    'nosesneerright',
    'tongueout',
    ]

    def save_initial_values():

        if(FT_OT_Transforms.HEAD_IK is not None):

            FT_OT_Transforms.empty_og_rot_w = FT_OT_Transforms.HEAD_IK.rotation_quaternion[0]
            FT_OT_Transforms.empty_og_rot_x = FT_OT_Transforms.HEAD_IK.rotation_quaternion[1]
            FT_OT_Transforms.empty_og_rot_y = FT_OT_Transforms.HEAD_IK.rotation_quaternion[2]
            FT_OT_Transforms.empty_og_rot_z = FT_OT_Transforms.HEAD_IK.rotation_quaternion[3]
            FT_OT_Transforms.empty_og_loc_x = FT_OT_Transforms.HEAD_IK.location.x
            FT_OT_Transforms.empty_og_loc_y = FT_OT_Transforms.HEAD_IK.location.y
            FT_OT_Transforms.empty_og_loc_z = FT_OT_Transforms.HEAD_IK.location.z

        if(FT_OT_Transforms.TRACKING_Cam is not None):

            FT_OT_Transforms.cam_og_rot_w = FT_OT_Transforms.TRACKING_Cam.rotation_quaternion[0]
            FT_OT_Transforms.cam_og_rot_x = FT_OT_Transforms.TRACKING_Cam.rotation_quaternion[1]
            FT_OT_Transforms.cam_og_rot_y = FT_OT_Transforms.TRACKING_Cam.rotation_quaternion[2]
            FT_OT_Transforms.cam_og_rot_z = FT_OT_Transforms.TRACKING_Cam.rotation_quaternion[3]
            FT_OT_Transforms.cam_og_loc_x = FT_OT_Transforms.TRACKING_Cam.location.x
            FT_OT_Transforms.cam_og_loc_y = FT_OT_Transforms.TRACKING_Cam.location.y
            FT_OT_Transforms.cam_og_loc_z = FT_OT_Transforms.TRACKING_Cam.location.z

       # if(FT_OT_Transforms.CURRENT_Avatar is not None):

            # FT_OT_Transforms.face_og_loc_x = FT_OT_Transforms.Avatar_MESH.location.x
            # FT_OT_Transforms.face_og_loc_y = FT_OT_Transforms.Avatar_MESH.location.y
            # FT_OT_Transforms.face_og_loc_z = FT_OT_Transforms.Avatar_MESH.location.z
            # FT_OT_Transforms.face_og_rot_w = FT_OT_Transforms.Avatar_MESH.rotation_quaternion[0]
            # FT_OT_Transforms.face_og_rot_x = FT_OT_Transforms.Avatar_MESH.rotation_quaternion[1]
            # FT_OT_Transforms.face_og_rot_y = FT_OT_Transforms.Avatar_MESH.rotation_quaternion[2]
            # FT_OT_Transforms.face_og_rot_z = FT_OT_Transforms.Avatar_MESH.rotation_quaternion[3]

    def head_rotation_q(w,x,y,z):


        ao = FT_OT_Transforms.HEAD_IK
        #ao.rotation_mode = 'QUATERNION'

        #### TEST
        ao.rotation_quaternion[0] = w   #(FT_OT_Transforms.lastFrameQ_w - w)  #w  
        ao.rotation_quaternion[1] = -x  #(FT_OT_Transforms.lastFrameQ_x - x)#-x  
        ao.rotation_quaternion[2] = -z   #(FT_OT_Transforms.lastFrameQ_y - y)#-z  
        ao.rotation_quaternion[3] = -y   #(FT_OT_Transforms.lastFrameQ_z - z)#-y

        if FT_OT_Transforms.REC:
            ao.keyframe_insert(data_path="location", frame=bpy.data.scenes[0].frame_current)
            ao.keyframe_insert(data_path="rotation_quaternion", frame=bpy.data.scenes[0].frame_current)
        #rotQ = True

    quatCor = Quaternion((1,1,0,0))
    quatCam = Quaternion((0,0,0,0))
    quatHIPS = Quaternion((0,0,0,0))
    quatORIGO = Quaternion((0,0,0,0))
    quatORIGO_dif = Quaternion((0,0,0,0))
    


    def from_axis_angle(axis, angle):
        half_angle = angle / 2.0
        scalar = math.cos(half_angle)
        factor = math.sin(half_angle)

        return Quaternion((
            scalar,
            axis[0] * factor,
            axis[1] * factor,
            axis[2] * factor
        ))

    def moveCamera(cw,cx,cy,cz,tx,tz,ty):
    
        #if FT_OT_Transforms.cFirstFrame:
        cam = FT_OT_Transforms.TRACKING_Cam
         #   FT_OT_Transforms.cFirstFrame = False

        FT_OT_Transforms.quatCam[0] = cw
        FT_OT_Transforms.quatCam[1] = -cx
        FT_OT_Transforms.quatCam[2] = -cz
        FT_OT_Transforms.quatCam[3] = -cy
        o = FT_OT_Transforms.quatCam  # use your object name here
        r_inv = o.inverted()

        FT_OT_Transforms.TRACKING_Cam.rotation_quaternion = FT_OT_Transforms.quatCam

        FT_OT_Transforms.TRACKING_Cam.location.x = -tx#(FT_OT_Transforms.camLastpos_x - tx) 
        FT_OT_Transforms.TRACKING_Cam.location.y = -ty#(FT_OT_Transforms.camLastpos_y - ty)
        FT_OT_Transforms.TRACKING_Cam.location.z = -tz#(FT_OT_Transforms.camLastpos_z - tz)
        ao = FT_OT_Transforms.TRACKING_Cam

        if FT_OT_Transforms.REC:
            ao.keyframe_insert(data_path="location", frame=bpy.data.scenes[0].frame_current)
            ao.keyframe_insert(data_path="rotation_quaternion", frame=bpy.data.scenes[0].frame_current)

    def moveHIPS(cw,cx,cy,cz,tx,tz,ty):

        FT_OT_Transforms.quatHIPS[3] = cw
        FT_OT_Transforms.quatHIPS[0] = -cx
        FT_OT_Transforms.quatHIPS[2] = -cz
        FT_OT_Transforms.quatHIPS[1] = -cy
        o = FT_OT_Transforms.quatHIPS  # use your object name here
        r_inv = o.inverted()

        FT_OT_Transforms.HIP_IK_TARGET.rotation_quaternion = FT_OT_Transforms.IK_PARENT.rotation_quaternion

        FT_OT_Transforms.HIP_IK_TARGET.location.x = -tx#(FT_OT_Transforms.camLastpos_x - tx) 
        FT_OT_Transforms.HIP_IK_TARGET.location.y = -ty#(FT_OT_Transforms.camLastpos_y - ty)
        FT_OT_Transforms.HIP_IK_TARGET.location.z = -tz#(FT_OT_Transforms.camLastpos_z - tz)
        ao = FT_OT_Transforms.HIP_IK_TARGET

        if FT_OT_Transforms.REC:

            ao.keyframe_insert(data_path="location", frame=bpy.data.scenes[0].frame_current)
            ao.keyframe_insert(data_path="rotation_quaternion", frame=bpy.data.scenes[0].frame_current)

            # ao.keyframe_insert(data_path="rotation_quaternion")
            # ao.keyframe_insert(data_path="location")
    ORIGO = None

    def SetOrigo_PosRot(px,py,pz,w,x,y,z):


        FT_OT_Transforms.IK_PARENT.location.x = 0
        FT_OT_Transforms.IK_PARENT.location.y = 0
        FT_OT_Transforms.IK_PARENT.location.z = 0
        # FT_OT_Transforms.IK_PARENT.location.x = -px
        # FT_OT_Transforms.IK_PARENT.location.y = -py
        # FT_OT_Transforms.IK_PARENT.location.z = -pz
        FT_OT_Transforms.quatORIGO[0] = -y
        FT_OT_Transforms.quatORIGO[1] = -x
        FT_OT_Transforms.quatORIGO[2] = -z
        FT_OT_Transforms.quatORIGO[3] = w
        FT_OT_Transforms.quatORIGO_dif[0] = w
        FT_OT_Transforms.quatORIGO_dif[1] = -x
        FT_OT_Transforms.quatORIGO_dif[2] = -z
        FT_OT_Transforms.quatORIGO_dif[3] = -y
       # q = FT_OT_Transforms.IK_PARENT.matrix_world.to_quaternion().rotation_difference(FT_OT_Transforms.HIP_IK_TARGET.matrix_world.to_quaternion())
        euler = FT_OT_Transforms.quatORIGO.to_euler()


        zero_orientation = Quaternion((0, 0, 0, 1))
        diff = zero_orientation.rotation_difference(FT_OT_Transforms.quatORIGO)
        #q = empty1.matrix_world.to_quaternion().rotation_difference(empty2.matrix_world.to_quaternion())

       # q_inv = q.invert()

       # FT_OT_Transforms.IK_PARENT.rotation_quaternion = FT_OT_Transforms.quatORIGO
        FT_OT_Transforms.IK_PARENT.rotation_quaternion = diff
        #euler = FT_OT_Transforms.quatORIGO.to_euler()


        zero_orientation = Quaternion((0, 0, 0, 1))
        _diff = zero_orientation.rotation_difference(FT_OT_Transforms.IK_PARENT.rotation_quaternion)
        #q = empty1.matrix_world.to_quaternion().rotation_difference(empty2.matrix_world.to_quaternion())

       # q_inv = q.invert()

       # FT_OT_Transforms.IK_PARENT.rotation_quaternion = FT_OT_Transforms.quatORIGO
        FT_OT_Transforms.ORIGO.rotation_quaternion = _diff
        #print('origorot')



    def moveHead(x,z,y):

        ao = FT_OT_Transforms.HEAD_IK

        ao.location.x = -x 
        ao.location.y = -y
        ao.location.z = -z

        if FT_OT_Transforms.REC:
            ao.keyframe_insert(data_path="location", frame=bpy.data.scenes[0].frame_current)
            ao.keyframe_insert(data_path="rotation_quaternion", frame=bpy.data.scenes[0].frame_current)
        return

    test = False

    def process_command(arr):
        #print(FT_OT_Transforms.a)
        i = 0
        if FT_OT_Transforms.rotQ:
            #print("going to rotQ")
            FT_OT_Transforms.head_rotation_q(arr[0], arr[1], arr[2], arr[3])
            i = 3
            #print("out of rotQ")
            for y in FT_OT_Transforms.Avatar_MESH.data.shape_keys.key_blocks:
                if(i < (52 + 4) and not 3):
                    y.value = arr[i]
                    #print(arr[i])
                    if FT_PT_Panel.REC_shapes == True:
                        y.keyframe_insert("value", frame=bpy.data.scenes[0].frame_current)
                    i += 1
                if(i == 3):
                    y.value = 0
                    i += 1

    def process_handIKs(rpos_x, rpos_y, rpos_z, rrot_w, rrot_x, rrot_y, rrot_z, lpos_x, lpos_y, lpos_z, lrot_w, lrot_x, lrot_y, lrot_z):
        
        r_IK = FT_OT_Transforms.HAND_IK_TARGET_R
        r_IK.location.x = -rpos_x 
        r_IK.location.y = -rpos_z
        r_IK.location.z = -rpos_y
        #return
        l_IK = FT_OT_Transforms.HAND_IK_TARGET_L
        l_IK.location.x = -lpos_x
        l_IK.location.y = -lpos_z
        l_IK.location.z = -lpos_y


        #### TEST
        r_IK.rotation_quaternion[0] = rrot_w   #(FT_OT_Transforms.lastFrameQ_w - w)  #w  
        r_IK.rotation_quaternion[1] = -rrot_x  #(FT_OT_Transforms.lastFrameQ_x - x)#-x  
        r_IK.rotation_quaternion[2] = -rrot_z   #(FT_OT_Transforms.lastFrameQ_y - y)#-z  
        r_IK.rotation_quaternion[3] = -rrot_y
        #### TEST
        l_IK.rotation_quaternion[0] = lrot_w   #(FT_OT_Transforms.lastFrameQ_w - w)  #w  
        l_IK.rotation_quaternion[1] = -lrot_x  #(FT_OT_Transforms.lastFrameQ_x - x)#-x  
        l_IK.rotation_quaternion[2] = -lrot_z   #(FT_OT_Transforms.lastFrameQ_y - y)#-z  
        l_IK.rotation_quaternion[3] = -lrot_y 
        #return

        if FT_OT_Transforms.REC:
            ao = r_IK
            ao.keyframe_insert(data_path="location", frame=bpy.data.scenes[0].frame_current)
            ao.keyframe_insert(data_path="rotation_quaternion", frame=bpy.data.scenes[0].frame_current)
        if FT_OT_Transforms.REC:
            ao = l_IK
            ao.keyframe_insert(data_path="location", frame=bpy.data.scenes[0].frame_current)
            ao.keyframe_insert(data_path="rotation_quaternion", frame=bpy.data.scenes[0].frame_current)


    def process_legIKs(rpos_x, rpos_y, rpos_z, rrot_w, rrot_x, rrot_y, rrot_z, lpos_x, lpos_y, lpos_z, lrot_w, lrot_x, lrot_y, lrot_z):
        
        r_IK = FT_OT_Transforms.LEG_IK_TARGET_R
        r_IK.location.x = -rpos_x 
        r_IK.location.y = -rpos_z
        r_IK.location.z = -rpos_y

        if FT_OT_Transforms.REC:
           FT_OT_Transforms.LEG_IK_TARGET_R.keyframe_insert(data_path="location")
        #return
        l_IK = FT_OT_Transforms.LEG_IK_TARGET_L
        l_IK.location.x = -lpos_x
        l_IK.location.y = -lpos_z
        l_IK.location.z = -lpos_y

        if FT_OT_Transforms.REC:
          FT_OT_Transforms.LEG_IK_TARGET_L.keyframe_insert(data_path="location")

        zero_orientation = Quaternion((0, 0, 0, 1))
        diff = zero_orientation.rotation_difference(FT_OT_Transforms.quatORIGO)
        l_IK.rotation_quaternion = FT_OT_Transforms.IK_PARENT.rotation_quaternion
        #### TEST
        # r_IK.rotation_quaternion[3] = rrot_w   #(FT_OT_Transforms.lastFrameQ_w - w)  #w  
        # r_IK.rotation_quaternion[0] = -rrot_x  #(FT_OT_Transforms.lastFrameQ_x - x)#-x  
        # r_IK.rotation_quaternion[1] = -rrot_z   #(FT_OT_Transforms.lastFrameQ_y - y)#-z  
        # r_IK.rotation_quaternion[2] = -rrot_y

        quat_lk = Quaternion()
        #### TEST
        l_IK.rotation_quaternion = FT_OT_Transforms.IK_PARENT.rotation_quaternion
        # l_IK.rotation_quaternion[3] = lrot_w   #(FT_OT_Transforms.lastFrameQ_w - w)  #w  
        # l_IK.rotation_quaternion[0] = -lrot_x  #(FT_OT_Transforms.lastFrameQ_x - x)#-x  
        # l_IK.rotation_quaternion[1] = -lrot_z   #(FT_OT_Transforms.lastFrameQ_y - y)#-z  
        # l_IK.rotation_quaternion[2] = -lrot_y 
        #return

    HAND_IK_TARGET_L = None
    HAND_IK_TARGET_R = None
    LEG_IK_TARGET_R = None
    LEG_IK_TARGET_L = None
    HIP_IK_TARGET = None
    IK_PARENT = None

    def process_bs(values):

        _values = values[:52]
        for i, value in enumerate(_values):
            for key in (FT_OT_Transforms.Avatar_MESH.data.shape_keys.key_blocks):
                if key.name.lower() == FT_OT_Transforms.shapes[i].lower():
                    key.value = values[i+1]
                    if FT_OT_Transforms.REC: #bpy.data.scenes[0].REC_shapes == True:
                        key.keyframe_insert("value", frame=bpy.data.scenes[0].frame_current)


    def reset_blendShapes(cam, ik, face):

        if(face is not None):
            #ao = face
            print('face not none')
            for shape in face.data.shape_keys.key_blocks:
                shape.value = 0
            for index, shape in enumerate(face.data.shape_keys.key_blocks):
                print(index, shape)
            # face.location.x = FT_OT_Transforms.face_og_loc_x
            # face.location.y = FT_OT_Transforms.face_og_loc_y
            # face.location.z = FT_OT_Transforms.face_og_loc_z
            # face.rotation_quaternion[0]= FT_OT_Transforms.face_og_rot_w
            # face.rotation_quaternion[1]= FT_OT_Transforms.face_og_rot_x
            # face.rotation_quaternion[2]= FT_OT_Transforms.face_og_rot_y
            # face.rotation_quaternion[3]= FT_OT_Transforms.face_og_rot_z

        if(ik is not None):
            ik.location.x = FT_OT_Transforms.empty_og_loc_x
            ik.location.y = FT_OT_Transforms.empty_og_loc_y
            ik.location.z = FT_OT_Transforms.empty_og_loc_z

            ik.rotation_quaternion[0]= FT_OT_Transforms.empty_og_rot_w
            ik.rotation_quaternion[1]= FT_OT_Transforms.empty_og_rot_x
            ik.rotation_quaternion[2]= FT_OT_Transforms.empty_og_rot_y
            ik.rotation_quaternion[3]= FT_OT_Transforms.empty_og_rot_z


        if(cam is not None):

            cam.location.x = FT_OT_Transforms.cam_og_loc_x
            cam.location.y = FT_OT_Transforms.cam_og_loc_y
            cam.location.z = FT_OT_Transforms.cam_og_loc_z

            cam.rotation_quaternion[0]= FT_OT_Transforms.cam_og_rot_w
            cam.rotation_quaternion[1]= FT_OT_Transforms.cam_og_rot_x
            cam.rotation_quaternion[2]= FT_OT_Transforms.cam_og_rot_y
            cam.rotation_quaternion[3]= FT_OT_Transforms.cam_og_rot_z