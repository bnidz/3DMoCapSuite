#from doctest import BLANKLINE_MARKER
#from math import fabs
import bpy 
#from bpy.types import Operator
from bpy.props import (StringProperty, PointerProperty, IntProperty)             
from bpy.types import (Panel)#, PropertyGroup, Scene)
from bpy import context

class FT_PT_Panel(Panel):

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_label = "Live MoCap settings"
    bl_category = "MoCap Suite"

    @classmethod
    def poll(self,context):
        return context.object is not None
    
    context = None
    scene = None
    start_server = None
    stop_server = None

    col1 = None
    col2 = None
    col3 = None
    col4 = None
    col5 = None
    col6 = None
    col7 = None
    col8 = None
    col9 = None

    IP_property = None
    prop_search = None
    enableStart = True
    enableRec = False

    enableStop = False
    track_face_rot = None
    track_cam = None
    Rig_Armature = None
    TRACKING_face = None
    TRACKING_bone = None
    TRACKING_cam = None
    REC_shapes = None
    REC_running = False

    REC_ENABLED = True
    empty_Done = False
#    ### --- maybe wont need this function --- 
    def EnableStopButton(bool):
        FT_PT_Panel.enableStart = bool
    def EnableStartButton(bool):
        FT_PT_Panel.enableStop = bool

    panel_self = None
    panel_context = None

    def draw(self, context):
        layout = self.layout

        #### --- LAYOUT ORDER ---
        row1 = layout.row()
        layout.separator()
        row5 = layout.row()
        row6 = layout.row()
        row3 = layout.row()
        row2 = layout.row()
        layout.separator()
        row4 = layout.row()
        row7 = layout.row()
        row8 = layout.row()
        row9 = layout.row()

        #### --- // ---
        FT_PT_Panel.col1 = row1.column()
        FT_PT_Panel.col2 = row2.column()
        FT_PT_Panel.col3 = row3.column()
        FT_PT_Panel.col4 = row4.column()
        FT_PT_Panel.col5 = row5.column()
        FT_PT_Panel.col6 = row6.column()
        FT_PT_Panel.col7 = row7.column()
        FT_PT_Panel.col8 = row8.column()
        FT_PT_Panel.col9 = row9.column()

        #### --- OP / PROP DECLARATIONS ---
        self.scene = context.scene
        #### --- SELECT HEAD  OBU ---
        TRACKING_face = FT_PT_Panel.col5.prop(context.scene, "TRACKING_face")
        TRACKING_CAM = FT_PT_Panel.col5.prop(context.scene, "TRACKING_cam")

        if(context.scene.TRACKING_cam is not None):
            FT_PT_Panel.col3.enabled = True
        else:
            FT_PT_Panel.col3.enabled = False
        if(context.scene.TRACKING_face is not None):
            FT_PT_Panel.col2.enabled = True
            FT_PT_Panel.col6.enabled = True


            FT_PT_Panel.TRACKING_face = context.scene.TRACKING_face
            empty = bpy.context.scene.objects.get("Face_Empty")
            if empty is None:
        #### --- CREATE EMPTY FOR EVERYTHING ELSE
                FT_PT_Panel.MakeEmpty()
        else:
            FT_PT_Panel.col2.enabled = False
            FT_PT_Panel.col6.enabled = False


        #### --- TYPE IP & TYPE PORT ---
        IP_property = FT_PT_Panel.col1.prop(context.scene, "IP_property")
        PORT_property = FT_PT_Panel.col1.prop(context.scene, "PORT_property")

        #### --- CHECKBOX TRACK FACE & TRACK CAMERA ---
        FT_PT_Panel.track_face_rot = FT_PT_Panel.col6.prop(context.scene, "track_face_rot")
        FT_PT_Panel.track_face_rot = FT_PT_Panel.col6.prop(context.scene, "track_face_pos")
        FT_PT_Panel.track_cam = FT_PT_Panel.col3.prop(context.scene, "track_cam")

        #### --- START & STOP BUTTONS ---
        if FT_PT_Panel.enableStart == True:
            FT_PT_Panel.col2.operator("object.start_server", text="START")
        else:
            FT_PT_Panel.col2.operator("object.stop_server", text="STOP")
        #### --- REC BUTTON --- 
        if(FT_PT_Panel.REC_running == False):
            FT_PT_Panel.col4.operator("object.start_rec", text="RECORD")
            if FT_PT_Panel.REC_ENABLED == False:
                FT_PT_Panel.col4.enabled = False

        else:
            FT_PT_Panel.col4.operator("object.stop_rec", text="STOP REC")

        if FT_PT_Panel.enableRec:
            FT_PT_Panel.col4.enabled = True
        if FT_PT_Panel.enableRec == False:
            FT_PT_Panel.col4.enabled = False

        #FT_PT_Panel.Rig_Armature = FT_PT_Panel.col8.prop(context.scene, "Rig_Armature")

    def MakeEmpty():
            o = bpy.data.objects.new( "Face_Empty", None )
            bpy.context.scene.collection.objects.link(o)
            #o.empty_display_size = 1
            #o.empty_display_type = 'PLAIN_AXES'
            ob = FT_PT_Panel.TRACKING_face 
            #empty = bpy.context.scene.objects.get("Face_Empty")

            # bpy.context.scene.objects.get("Face_Empty").location.y = ob.location.y
            # bpy.context.scene.objects.get("Face_Empty").location.z = ob.location.z

            FT_PT_Panel.TRACKING_bone = o
