from asyncio import start_server
from multiprocessing import context
import bpy
from bpy.types import Operator
import socket
import time
import threading
import array
from math import radians
from bpy.props import *
import select
from . ft_panel import FT_PT_Panel
from array import *

class FT_OT_Start_Server(Operator):

    bl_idname = "object.start_server"
    bl_label = "Start server"
    bl_description = "Start the facetracking server"
    isRunning = False

    @classmethod
    def poll(cls, context):
        ao = context.object

        if ao is not None:
            if ao.mode == "OBJECT":
                return True
        return False

    def orig_rot(o):
        origrot = o.rotation_euler #{ao.rotation_euler[0],ao.rotation_euler[1],ao.rotation_euler[2]}
        print(origrot)
        return origrot

    firstFrame = True
    firstFrameQ = True
    #lastFrame = array('f',[0,0,0])
    #lastFrameQ = array('f',[0,0,0,0])
    #lastXYZ = array('f',[0,0,0])
    lastHeadPos_x = None
    lastHeadPos_y = None
    lastHeadPos_z = None
    lastFrameQ_w = None
    lastFrameQ_x = None
    lastFrameQ_y = None
    lastFrameQ_z = None

    def head_rotation_q(w,x,z,y):

        ao = FT_OT_Start_Server.TRACKING_face
        FT_OT_Start_Server.TRACKING_face.rotation_mode = 'QUATERNION'

        if FT_OT_Start_Server.firstFrameQ:
            FT_OT_Start_Server.lastFrameQ_w = w
            FT_OT_Start_Server.lastFrameQ_x = x
            FT_OT_Start_Server.lastFrameQ_y = y
            FT_OT_Start_Server.lastFrameQ_z = z
            FT_OT_Start_Server.firstFrameQ = False

        #ao.rotation_quaternion[0] += (w - FT_OT_Start_Server.lastFrameQ[0])  
        #ao.rotation_quaternion[1] += (x - FT_OT_Start_Server.lastFrameQ[1])  
        #ao.rotation_quaternion[2] += (y - FT_OT_Start_Server.lastFrameQ[2])  
        #ao.rotation_quaternion[3] += (z - FT_OT_Start_Server.lastFrameQ[3])

        FT_OT_Start_Server.TRACKING_face.rotation_quaternion[0] = w  
        FT_OT_Start_Server.TRACKING_face.rotation_quaternion[1] = -x  
        FT_OT_Start_Server.TRACKING_face.rotation_quaternion[2] = -y  
        FT_OT_Start_Server.TRACKING_face.rotation_quaternion[3] = -z

        FT_OT_Start_Server.lastFrameQ_w = w
        FT_OT_Start_Server.lastFrameQ_x = x
        FT_OT_Start_Server.lastFrameQ_y = y
        FT_OT_Start_Server.lastFrameQ_z = z

        if FT_OT_Start_Server.REC:
            FT_OT_Start_Server.TRACKING_face.keyframe_insert(data_path="rotation_quaternion")
    rotQ = True

    #camTransform = array('f',[0,0,0])
    #lastFrame_cam = array('f',[0,0,0,0])
    REC = False
    cFirstFrame = True
    #camparent = None
    #isEnding = False
    #camposparent = None
    camLastpos_x = None
    camLastpos_y = None
    camLastpos_z = None

    def moveCamera(cw,cx,cy,cz, tx,tz,ty):
        cam = FT_OT_Start_Server.TRACKING_cam

        if FT_OT_Start_Server.cFirstFrame:

            FT_OT_Start_Server.camLastpos_x = tx
            FT_OT_Start_Server.camLastpos_y = ty
            FT_OT_Start_Server.camLastpos_z = tz
            FT_OT_Start_Server.cFirstFrame = False

        if FT_OT_Start_Server.isEnding == False: 

           # if FT_OT_Start_Server.orbiting == False:
                #cam.parent = None
            FT_OT_Start_Server.TRACKING_cam.location.x = -FT_OT_Start_Server.lastHeadPos_x + tx
            FT_OT_Start_Server.TRACKING_cam.location.y = -FT_OT_Start_Server.lastHeadPos_y + ty
            FT_OT_Start_Server.TRACKING_cam.location.z = -FT_OT_Start_Server.lastHeadPos_z + tz

            FT_OT_Start_Server.TRACKING_cam.rotation_quaternion[0] = cw
            FT_OT_Start_Server.TRACKING_cam.rotation_quaternion[1] = -cx
            FT_OT_Start_Server.TRACKING_cam.rotation_quaternion[2] = -cy
            FT_OT_Start_Server.TRACKING_cam.rotation_quaternion[3] = cz

    def removeTemps():
        
        #objs = bpy.data.objects
        #bpy.data.scenes[0].TRACKING_cam.parent = None
        FT_OT_Start_Server.isEnding = True
        #objs.remove(objs["camEmpty"], do_unlink=True)
        #objs.remove(objs["HEAD_Empty"], do_unlink=True)
        #FT_OT_Start_Server.cFirstFrame = True
        #lastHeadPos = array('f',[0,0,0])

    headFirstFrame = True
    def look_at(obj_camera, point):
        loc_camera = obj_camera.matrix_world.to_translation()
        _point = point.matrix_world.to_translation()
        direction = _point - loc_camera
        # point the cameras '-Z' and use its 'Y' as up
        rot_quat = direction.to_track_quat('-Z', 'Y')

        # assume we're using euler rotation
        obj_camera.rotation_euler = rot_quat.to_euler()

    headParent = None

    def moveHead(x,z,y):
        ## ADD OBJECT LOCATION RECORDING TO FRAMES
        ao = FT_OT_Start_Server.TRACKING_face

        if FT_OT_Start_Server.headFirstFrame:

            FT_OT_Start_Server.lastHeadPos_x = x
            FT_OT_Start_Server.lastHeadPos_y = y
            FT_OT_Start_Server.lastHeadPos_z = z

            #FT_OT_Start_Server.headParent = bpy.data.objects.new( "HEAD_Empty", None )
            #bpy.context.scene.collection.objects.link(FT_OT_Start_Server.headParent )
            #FT_OT_Start_Server.headParent.empty_display_size = 2
            #FT_OT_Start_Server.headParent.empty_display_type = 'PLAIN_AXES'
            #FT_OT_Start_Server.headParent.rotation_mode = 'QUATERNION'

            FT_OT_Start_Server.headFirstFrame = False

        FT_OT_Start_Server.TRACKING_face.location.x = -FT_OT_Start_Server.lastHeadPos_x + x
        FT_OT_Start_Server.TRACKING_face.location.y = -FT_OT_Start_Server.lastHeadPos_y + y
        FT_OT_Start_Server.TRACKING_face.location.z = -FT_OT_Start_Server.lastHeadPos_z + z

        #FT_OT_Start_Server.lastHeadPos[0] = x
        #FT_OT_Start_Server.lastHeadPos[1] = y
        #FT_OT_Start_Server.lastHeadPos[2] = z

        if FT_OT_Start_Server.REC:
            FT_OT_Start_Server.TRACKING_face.keyframe_insert(data_path="location")
        return
    test = False

    def process_command(arr):
        #print(FT_OT_Start_Server.TRACKING_face)
        i = 0
        if FT_OT_Start_Server.rotQ:
            #print("going to rotQ")
            FT_OT_Start_Server.head_rotation_q(arr[0], arr[1], arr[2], arr[3])
            i = 3
            #print("out of rotQ")
            for y in FT_OT_Start_Server.TRACKING_face.data.shape_keys.key_blocks:
                if(i < (52 + 4) and not 3):
                    y.value = arr[i]
                    #print(arr[i])
                    if FT_PT_Panel.REC_shapes == True:
                        y.keyframe_insert("value", frame=bpy.data.scenes[0].frame_current)
                    i += 1
                if(i == 3):
                    y.value = 0
                    i += 1

    def process_bs(values):
        ## ADD BLENDSHAPE RECORDING
        for i, shape in enumerate(FT_OT_Start_Server.TRACKING_face.data.shape_keys.key_blocks):
            if(i != 0):
                shape.value = values[i]
                if FT_OT_Start_Server.REC: #bpy.data.scenes[0].REC_shapes == True:
                    shape.keyframe_insert("value", frame=bpy.data.scenes[0].frame_current)
            if(i == 0):
                i = 1
                  
    def reset_blendShapes():
        if(FT_OT_Start_Server.TRACKING_face is not None):
            ao = FT_OT_Start_Server.TRACKING_face #bpy.context.view_layer.objects.active
            ao.rotation_mode = 'QUATERNION'
            ao.rotation_quaternion[0] = 1 
            ao.rotation_quaternion[1] = 0
            ao.rotation_quaternion[2] = 0 
            ao.rotation_quaternion[3] = 0
            ao.location.x = 0
            ao.location.y = 0
            ao.location.z = 0
        if(FT_OT_Start_Server.TRACKING_cam is not None):
            cam = FT_OT_Start_Server.TRACKING_cam
            cam.rotation_mode = 'QUATERNION'
            cam.rotation_quaternion[0] = 1 
            cam.rotation_quaternion[1] = 0
            cam.rotation_quaternion[2] = 0 
            cam.rotation_quaternion[3] = 0
            cam.location.x = 0
            cam.location.y = 0
            cam.location.z = 0

        for shape in ao.data.shape_keys.key_blocks:
            shape.value = 0
            #print(shape.name)
            #print(len(ao.data.shape_keys.key_blocks))
        for index, shape in enumerate(ao.data.shape_keys.key_blocks):
            print(index, shape)

    HOST = ""#FT_PT_Panel.scene.IP_property
    PORT =  8080#FT_PT_Panel.scene.PORT_property
    s = socket
    t = threading.Thread
    timeOutCount = 0
    ready = {1}
    timeOutSeconds = 30
    TRACKING_face = None
    orbiting = False
    TRACKING_cam = None

    arr = array('f')

    def server_function(stop):

        FT_OT_Start_Server.reset_blendShapes()
        print("starting server")
        FT_OT_Start_Server.firstFrame = True

        while True:
            if stop():
                break
            FT_OT_Start_Server.ready = select.select([FT_OT_Start_Server.s], [], [], FT_OT_Start_Server.timeOutSeconds)
            if FT_OT_Start_Server.ready[0]:
            
                #time.sleep(1/120)
                time.sleep(0)
                data = FT_OT_Start_Server.s.recv(512)
                #data =  FT_OT_Start_Server.s.recv(1024)
                FT_PT_Panel.enableRec = True

                if len(data) < 5 and data.decode() == 'STOP':
                    print(data.decode())
                    break
                
                arr = array('f')
                FT_OT_Start_Server.arr = arr
                FT_OT_Start_Server.arr.frombytes(data)
                #print('arr lenght', len( FT_OT_Start_Server.arr))

                if(len( FT_OT_Start_Server.arr) == 66):
                    if FT_OT_Start_Server.context.scene.track_face_rot:
                        FT_OT_Start_Server.head_rotation_q( FT_OT_Start_Server.arr[0],  FT_OT_Start_Server.arr[1],  FT_OT_Start_Server.arr[2],  FT_OT_Start_Server.arr[3])
                    if FT_OT_Start_Server.context.scene.track_face_pos:
                        FT_OT_Start_Server.moveHead( FT_OT_Start_Server.arr[4],  FT_OT_Start_Server.arr[5],  FT_OT_Start_Server.arr[6])
                    if FT_OT_Start_Server.context.scene.track_cam:
                        FT_OT_Start_Server.moveCamera( FT_OT_Start_Server.arr[7],  FT_OT_Start_Server.arr[8],  FT_OT_Start_Server.arr[9],  FT_OT_Start_Server.arr[10],  FT_OT_Start_Server.arr[11],  FT_OT_Start_Server.arr[12],  FT_OT_Start_Server.arr[13])
                    FT_OT_Start_Server.process_bs(FT_OT_Start_Server.arr[13:])

                else:
                    time.sleep(0)
                    #time.sleep(1/120)
                #if(len(arr) == 1):
                    #FT_PT_Panel.enableRec = False
                    #FT_OT_Start_Server.timeOutCount += 1
                    #print("timeout ", FT_OT_Start_Server.timeOutCount * FT_OT_Start_Server.timeOutSeconds, "s")
                    #FT_OT_Start_Server.sendClosingBytes()
                    #FT_PT_Panel.EnableStartButton(True)
                    #FT_PT_Panel.EnableStopButton(False)
                    #break

#        FT_OT_Start_Server.s.close()
#        print("server stopped, socket closed")
#        FT_PT_Panel.enableStart = True
#        FT_PT_Panel.enableStop = False
#        FT_PT_Panel.enableRec = False
#        return {'FINISHED'}
        
    def sendClosingBytes():

        y = 'STOP'
        bytes = y.encode()
        print("mesg len in bytes : ", len(bytes))
        exsHOST = "127.0.0.1"
        exs = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        exs.setblocking(0)
        exs.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        exs.bind((exsHOST,FT_OT_Start_Server.PORT))
        exs.sendto(bytes, (FT_OT_Start_Server.HOST,FT_OT_Start_Server.PORT))
        print("sent closing bytes")
        exs.close()
        return {'FINISHED'}        

    TRACKING_ROT = None
    context = None
    
    def execute(self, context):
        
        FT_OT_Start_Server.context = context
        FT_OT_Start_Server.headFirstFrame = True
        FT_OT_Start_Server.cFirstFrame = True
        FT_OT_Start_Server.HOST = context.scene.IP_property
        FT_OT_Start_Server.PORT = context.scene.PORT_property
        FT_OT_Start_Server.timeOutCount = 0
        FT_OT_Start_Server.stop_threads = True
        FT_OT_Start_Server.REC = False
        ## set bools
        FT_OT_Start_Server.isEnding = False
        FT_OT_Start_Server.cFirstFrame = True
        ### --- Update tracking HEAD object
        FT_OT_Start_Server.TRACKING_face = context.scene.TRACKING_face
        FT_OT_Start_Server.TRACKING_cam = context.scene.TRACKING_cam
        #FT_OT_Start_Server.TRACKING_head = context.scene.TRACKING_head
        FT_OT_Start_Server.reset_blendShapes()
        FT_PT_Panel.enableStart = False
        FT_PT_Panel.enableStop = True
        FT_OT_Start_Server.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        #FT_OT_Start_Server.s.setblocking(0)
        FT_OT_Start_Server.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        FT_OT_Start_Server.s.bind((FT_OT_Start_Server.HOST,FT_OT_Start_Server.PORT))
        #print("active on :", FT_OT_Start_Server.HOST, FT_OT_Start_Server.PORT)
        FT_OT_Start_Server.ao = context.view_layer.objects.active
        FT_OT_Start_Server.stop_threads = False
        FT_OT_Start_Server.t = threading.Thread(target=FT_OT_Start_Server.server_function, args = (lambda : FT_OT_Start_Server.stop_threads,))
        FT_OT_Start_Server.t.daemon = True
        FT_OT_Start_Server.t.start()
        return {'FINISHED'}

    def startCall():

        FT_OT_Start_Server.stop_threads = True
        FT_OT_Start_Server.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        #FT_OT_Start_Server.s.setblocking(0)
        FT_OT_Start_Server.s.bind((FT_OT_Start_Server.HOST,FT_OT_Start_Server.PORT))

        ### HIDE START BUTTON
        #FT_PT_Panel.EnableStopButton(True)
        #FT_PT_Panel.EnableStartButton(False)
        FT_PT_Panel.enableStart = False
        FT_PT_Panel.enableStop = True
        FT_OT_Start_Server.stop_threads = False
        FT_OT_Start_Server.t = threading.Thread(target=FT_OT_Start_Server.server_function, args =(lambda : FT_OT_Start_Server.stop_threads, ))
        FT_OT_Start_Server.t.daemon = True
        FT_OT_Start_Server.t.start()

class FT_OT_Stop_Server(Operator):

    bl_idname = "object.stop_server"
    bl_label = "Stop server"
    bl_description = "Stop the facetracking server"

    @classmethod
    def poll(cls, context):
        ob = context.object
        if ob is not None:
            if ob.mode == "OBJECT":
                return True
        return False

    def execute(self, context):
        ### SHOW START BUTTON
        FT_OT_Start_Server.REC = False
        FT_PT_Panel.enableStart = True
        FT_OT_Start_Server.sendClosingBytes()
        FT_OT_Start_Server.removeTemps()
        #FT_OT_Start_Server.cFirstFrame = True
        return {'FINISHED'}

    def closeCon():
        ### SHOW START BUTTON
        FT_OT_Start_Server.sendClosingBytes()
        return {'FINISHED'}

class FT_OT_Start_Recording(Operator):

    bl_idname = "object.start_rec"
    bl_label = "Start REC"
    bl_description = "Start recording keyframes"

    def execute(self, context):
        print("rec")
        FT_OT_Start_Server.REC = True
        return {'FINISHED'}

class FT_OT_Stop_Recording(Operator):

    bl_idname = "object.stop_rec"
    bl_label = "Start REC"
    bl_description = "Start recording keyframes"

    def execute(self, context):
        FT_OT_Start_Server.REC = False
        print("rec")
        return {'FINISHED'}