#from multiprocessing import context
import bpy 
from bpy.types import Operator, Scene
import socket, requests
#import time
import threading
import array
#from math import radians
from bpy.props import *

import select
from . ft_transforms import FT_OT_Transforms
from . ft_panel import FT_PT_Panel
from array import *
from bpy.app.handlers import persistent
from contextlib import closing

import socketserver

import urllib.request
import tempfile
import ssl
import certifi
from mathutils import Matrix, Quaternion
from math import radians
import os
import ftplib
import io
#import bpy
from bpy import utils
#import os
import bpy
from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
import time

#import bpywebsocket

class FT_OT_Start_Server(Operator):
    
    bl_idname = "object.start_server"
    bl_label = "Start server"
    bl_description = "Start the facetracking server"
    isRunning = False
    
    launch = True
    @classmethod
    def poll(cls, context):
        ao = context.object
        if ao is not None:
            if ao.mode == "OBJECT":
                return True
       # else:
        #    ao = bpy.context.scene.objects.get("HEAD_IK")
         #   bpy.context.scene.objects.active = ao
        return False

    _scene = None
    firstFrame = True
    firstFrameQ = True
    lastHeadPos_x = None
    lastHeadPos_y = None
    lastHeadPos_z = None
    lastFrameQ_w = None
    lastFrameQ_x = None
    lastFrameQ_y = None
    lastFrameQ_z = None

    HEAD_IK = None
    REC = False
    cFirstFrame = True

    camLastpos_x = None
    camLastpos_y = None
    camLastpos_z = None
 
    useArma = False
    difference_x = None
    difference_y = None
    difference_z = None

    headFirstFrame = True
    headParent = None

    firstHeadPos_x = None
    firstHeadPos_y = None
    firstHeadPos_z = None
    test = False
                  
    ao_origrot_0 = 1
    ao_origrot_1 = 0
    ao_origrot_2 = 0
    ao_origrot_3 = 0

    cam_origrot_0 = 1
    cam_origrot_1 = 0
    cam_origrot_2 = 0
    cam_origrot_3 = 0

    LAST_PORT = 0

    HOST = ""#FT_PT_Panel.scene.IP_property
    PORT =  8080#FT_PT_Panel.scene.PORT_property
    s = socket
    t = threading.Thread
    timeOutCount = 0
    ready = {1}
    _ready = {1} 
    timeOutSeconds = 2
    Avatar_MESH = None
    orbiting = False
    TRACKING_Cam = None
    arr = array('f')    
    dick = 9000
    datapacket = None
    justStarted = True
    downloadingModel = False

    CURRENT_Avatar = None
    OLD_AVATAR = None
    CURRENT_Avatar = None
    Old_Armature = None
    Avatar_MESH = None

    # def unlink(ob):
    #     for c in bpy.data.collections:
    #         if ob.name in c.objects:
    #             c.objects.unlink(ob)

    def unlink(ob, col):
        for c in bpy.data.collections[col]:
            if ob.name in c.objects:
                c.objects.unlink(ob)

    def link_old_avatar(context, avatar):        
        children =FT_OT_Start_Server.getChildren(avatar)
        for c in children:
            
            cc = FT_OT_Start_Server.getChildren(c)
            if len(cc) > 0:
                for x in cc:
                    bpy.data.collections["MoCapSuite_Active"].objects.unlink(x)
                    bpy.data.collections["MoCapSuite_InActive"].objects.link(x)
            
            bpy.data.collections["MoCapSuite_Active"].objects.unlink(c)
            bpy.data.collections["MoCapSuite_InActive"].objects.link(c)

        bpy.data.collections["MoCapSuite_Active"].objects.unlink(avatar)
        bpy.data.collections["MoCapSuite_InActive"].objects.link(avatar)


    def SetNewAvatar(new_avatar):
    
        ### UNLINK OLD AVATAR TO INACTIVE
        if FT_OT_Start_Server.CURRENT_Avatar is not None:
            FT_OT_Start_Server.CURRENT_Avatar.parent = None
            FT_OT_Start_Server.CURRENT_Avatar.name = "PREVIOUS_Avatar"

        children = FT_OT_Start_Server.getChildren(FT_OT_Start_Server.CURRENT_Avatar)
        for c in children: 
            print('children name ', c.name)
            if c.name == "Wolf3D_Avatar":# in c.name:
                    FT_OT_Start_Server.CURRENT_Avatar = c.parent
                    FT_OT_Start_Server.Avatar_MESH = c
                    FT_OT_Transforms.Avatar_MESH = c 
                    c.parent.name = "PREVIOUS_Avatar"
                    c.name = "Avatar_MESH_PREVIOUS"
            print('children name ', c.name)
            if c.name == "Avatar_MESH":# in c.name:
                    FT_OT_Start_Server.OLD_AVATAR = c.parent
                    #FT_OT_Start_Server.Avatar_MESH = c
                    #FT_OT_Transforms.Avatar_MESH = c
                    c.name = "Avatar_MESH_PREVIOUS"
                    c.parent.name = "PREVIOUS_Avatar"

        if bpy.context.scene.objects.get("IK_PARENT") is not None:
            childs = FT_OT_Start_Server.getChildren(bpy.context.scene.objects.get("IK_PARENT"))
            for c in childs:
                bpy.data.objects.remove(c)

        FT_OT_Start_Server.link_old_avatar(FT_OT_Start_Server.context, FT_OT_Start_Server.OLD_AVATAR)
            
        children = FT_OT_Start_Server.getChildren(new_avatar)
        for c in children: 
            print('children name ', c.name)
            if c.name == "Wolf3D_Avatar":# in c.name:
                    FT_OT_Start_Server.CURRENT_Avatar = c.parent
                    FT_OT_Start_Server.Avatar_MESH = c
                    FT_OT_Transforms.Avatar_MESH = c 
                    c.parent.name = "CURRENT_Avatar"
                    c.name = "Avatar_MESH"
            print('children name ', c.name)
            if c.name == "Avatar_MESH":# in c.name:
                    FT_OT_Start_Server.CURRENT_Avatar = c.parent
                    FT_OT_Start_Server.Avatar_MESH = c
                    FT_OT_Transforms.Avatar_MESH = c
                    c.parent.name = "CURRENT_Avatar"
            else:
                print('error: Selection not applicable')
                FT_PT_Panel.InfoText = "error: Selection not applicable"


        ### LINK AVATAR TO ACTIVE
        #if bpy.context.scene.objects.get("Armature") is not None:
        FT_OT_Start_Server.link_new_avatar(FT_OT_Start_Server.context, FT_OT_Start_Server.CURRENT_Avatar)
        #o = bpy.context.scene.objects.get("Armature")

        ### -- MAKE ALL RIGGED AGAIN --- 
        FT_PT_Panel.SelectedObject = FT_OT_Start_Server.CURRENT_Avatar
        #FT_OT_Start_Server.CheckSelectedObject(FT_OT_Start_Server.context)
        FT_OT_Start_Server.Check_and_Make_IK_TARGETS(FT_OT_Start_Server.context)
        FT_OT_Start_Server.AddCamera(FT_OT_Start_Server.context)
        ### Save CAM & HEAD
        FT_OT_Start_Server.MakeRig(FT_OT_Start_Server.context)
        FT_OT_Transforms.save_initial_values()
        ### CONTINUE FRAMES
        FT_OT_Start_Server.timeOutCount = 0
        bpy.ops.screen.animation_play()

    def ResumeUpdatingTransforms():
        FT_OT_Start_Server.downloadingModel = False

    def import_glb(url):
    
        FT_OT_Start_Server.timeOutCount = 0
        characters = list(url)
        filtered_characters = [c for c in characters if ord(c) != 0]
        filtered_string = "".join(filtered_characters)
        response = urllib.request.urlopen(filtered_string, context=ssl.create_default_context(cafile=certifi.where()))
        data = response.read()
        file_path = os.path.join(tempfile.gettempdir(), "temp_file.glb")
        with open(file_path, "wb") as f:
            f.write(data)
        bpy.ops.screen.animation_cancel(False)
        new_AVA =bpy.ops.import_scene.gltf(filepath=file_path)
     #   FT_OT_Start_Server.SetNewAvatar(new_AVA)
        FT_OT_Start_Server.SetNewAvatar(bpy.context.scene.objects.get("Armature"))


    def import_glb_button(context, url):

        FT_OT_Start_Server.Check_Make_Collections(context)
        #bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children["MoCapSuite_Active"]

        characters = list(url)
        filtered_characters = [c for c in characters if ord(c) != 0]
        filtered_string = "".join(filtered_characters)
        response = urllib.request.urlopen(filtered_string, context=ssl.create_default_context(cafile=certifi.where()))
        data = response.read()
        file_path = os.path.join(tempfile.gettempdir(), "temp_file.glb")
        with open(file_path, "wb") as f:
            f.write(data)
        #bpy.ops.screen.animation_cancel(False)
        new_AVA = bpy.ops.import_scene.gltf(filepath=file_path)

        bpy.ops.screen.animation_cancel(False)
        ### UNLINK AND LINK NEW OBU
        if bpy.context.scene.objects.get("Armature") is not None:
            FT_OT_Start_Server.link_new_avatar(context, bpy.context.scene.objects.get("Armature"))
        FT_OT_Start_Server.FORM_Button = False

    def link_new_avatar(context, avatar):        
        children =FT_OT_Start_Server.getChildren(avatar)
        for c in children:
            bpy.context.scene.collection.objects.unlink(c)
            bpy.data.collections["MoCapSuite_Active"].objects.link(c)
        bpy.context.scene.collection.objects.unlink(avatar)
        bpy.data.collections["MoCapSuite_Active"].objects.link(avatar)

    FORM_Button = False
 #Debug.Log("");
    def server_infinite():

        if FT_OT_Start_Server.justStarted: 
            FT_OT_Start_Server.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            FT_OT_Start_Server.s.setblocking(False)
            FT_OT_Start_Server.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

            try:
                FT_OT_Start_Server.s.bind((FT_OT_Start_Server.HOST,FT_OT_Start_Server.PORT))
                print('con success!!')
            except:
                print('con failed!')   

            FT_OT_Start_Server.LAST_PORT = FT_OT_Start_Server.PORT
            FT_OT_Start_Server.justStarted = False

        FT_OT_Start_Server.ready = select.select([FT_OT_Start_Server.s], [], [], FT_OT_Start_Server.timeOutSeconds)
        
        if FT_OT_Start_Server.ready[0]:
            #declara data as array of bytes
            data = array('B')
            
            FT_OT_Start_Server.waitingForConnection = False
            while True:
                try:
                    FT_OT_Start_Server.datapacket = FT_OT_Start_Server.s.recv(
                        1472)
                except:
                    #FT_OT_Start_Server.timeOutStop()
                    break

            FT_PT_Panel.enableRec = True
            data = FT_OT_Start_Server.datapacket

            if(data[1472 -1] == 1):
                    FT_PT_Panel.REC_ENABLED = False
                    FT_PT_Panel.enableRec = False
                    arr = array('f')
                    FT_OT_Start_Server.arr = arr
                    FT_OT_Start_Server.arr.frombytes(data[:432])

            if (data[1472 - 1] == 2):
                if(FT_OT_Transforms.headFirstFrame):
                    FT_PT_Panel.REC_ENABLED = True
                    arr = array('f')
                    FT_OT_Start_Server.arr = arr
                    FT_OT_Start_Server.arr.frombytes(data[:432])

            if (data[1472 - 1] == 3):
                bpy.ops.screen.animation_cancel(False)

                print(data[:1472 -1].decode("utf-8"))
                FT_OT_Start_Server.import_glb(data[:1472 -1].decode("utf-8"))
                return
            
            if(data[1472 -1] == 4):
                ## sending mediapipe - not premium
                #bpy.ops.screen.animation_cancel(False)
                arr = array('f')
                FT_OT_Start_Server.arr = arr
                FT_OT_Start_Server.arr.frombytes(data[:1136])
                
            if (data[1472 - 1] == 5):
                ## sending mediapipe - premium
                #bpy.ops.screen.animation_cancel(False)
                arr = array('f')
                FT_OT_Start_Server.arr = arr
                FT_OT_Start_Server.arr.frombytes(data[:1136])

            if(len( FT_OT_Start_Server.arr) == 108):

                FT_OT_Start_Server.sendFaceTrackingData(FT_OT_Start_Server.arr)
                return
                
            if(len(FT_OT_Start_Server.arr) == 284):
                #mediapipe tracking values
                print('lets set values')
                ar = array('f')
                ar = FT_OT_Start_Server.arr
                FT_OT_Start_Server.mediapipeTrackingData(ar)
            else:
                return  
        else:
            FT_OT_Start_Server.timeOutCount += 1
            #print('timeoutcount', FT_OT_Start_Server.timeOutCount)
            if FT_OT_Start_Server.timeOutCount >= 4000:
                FT_OT_Start_Server.timeOutStop()
        return {'FINISHED'}
    
    # function to mediapipe array items
    def printArrayItems(arr):
        # print individual float values
        print('printing values')

    
        
    def sendClosingBytes():
        y = 'STOP'
        bytes = y.encode()
        print("mesg len in bytes : ", len(bytes))
        exsHOST = "127.0.0.1"
        exs = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        exs.setblocking(0)
        exs.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        exs.bind((exsHOST,FT_OT_Start_Server.PORT))
        exs.sendto(bytes, (FT_OT_Start_Server.HOST,FT_OT_Start_Server.PORT))
        print("sent closing bytes")
        exs.close()
        return {'FINISHED'}        

    TRACKING_ROT = None
    context = None
    justStarted = False

    # function for mediapipe tracking
    def mediapipeTrackingData(arr):
        # //pose = 33 vector3 / 99 floats / 396 bytes
        # //hands = 42 vector3 / 126 floats / 504 bytes
        # // = 33 + 42 = 75 vector3 / 225 floats / 900 bytes
        # // + 52 facetracking floats / 208 bytes
        # // = 277 floats / 1108 bytes

        # set posedata in transform script arr 0-98
        FT_OT_Transforms.process_pose(arr[:99])
        # set handdata in transform script arr 99-224
        FT_OT_Transforms.process_hand(arr[98:225])
        # set facedata in transform script arr 225-276
        FT_OT_Transforms.process_bs(arr[224:277])
        # set camera data in transform script arr 277-283
        FT_OT_Transforms.moveCamera(arr[277],  arr[278],  arr[279],
                                    arr[280],  arr[281],  arr[282],  arr[283])
        FT_OT_Transforms.movFace = FT_OT_Start_Server.context.scene.track_face_pos
        FT_OT_Start_Server.shit = True

    # function for sending basic face tracking data to transorms
    def sendFaceTrackingData(arr):
        # sets values if not media pipe
        FT_OT_Transforms.head_rotation_q( FT_OT_Start_Server.arr[0],  FT_OT_Start_Server.arr[1],  FT_OT_Start_Server.arr[2],  FT_OT_Start_Server.arr[3])
        FT_OT_Transforms.movFace = FT_OT_Start_Server.context.scene.track_face_pos
        FT_OT_Transforms.moveHead( FT_OT_Start_Server.arr[4],  FT_OT_Start_Server.arr[5],  FT_OT_Start_Server.arr[6])
        FT_OT_Transforms.moveCamera(FT_OT_Start_Server.arr[7],  FT_OT_Start_Server.arr[8],  FT_OT_Start_Server.arr[9],  FT_OT_Start_Server.arr[10],  FT_OT_Start_Server.arr[11],  FT_OT_Start_Server.arr[12],  FT_OT_Start_Server.arr[13])
        FT_OT_Transforms.process_handIKs(FT_OT_Start_Server.arr[14], FT_OT_Start_Server.arr[15], FT_OT_Start_Server.arr[16], FT_OT_Start_Server.arr[17], FT_OT_Start_Server.arr[18], FT_OT_Start_Server.arr[19], FT_OT_Start_Server.arr[20], FT_OT_Start_Server.arr[21], FT_OT_Start_Server.arr[22], FT_OT_Start_Server.arr[23], FT_OT_Start_Server.arr[24], FT_OT_Start_Server.arr[25], FT_OT_Start_Server.arr[26], FT_OT_Start_Server.arr[27])
        FT_OT_Transforms.moveHIPS(FT_OT_Start_Server.arr[31],  FT_OT_Start_Server.arr[32],  FT_OT_Start_Server.arr[33],  FT_OT_Start_Server.arr[34],  FT_OT_Start_Server.arr[28],  FT_OT_Start_Server.arr[29],  FT_OT_Start_Server.arr[30])
        FT_OT_Transforms.process_legIKs(FT_OT_Start_Server.arr[35], FT_OT_Start_Server.arr[36], FT_OT_Start_Server.arr[37], FT_OT_Start_Server.arr[38], FT_OT_Start_Server.arr[39], FT_OT_Start_Server.arr[40], FT_OT_Start_Server.arr[41], FT_OT_Start_Server.arr[42], FT_OT_Start_Server.arr[43], FT_OT_Start_Server.arr[44], FT_OT_Start_Server.arr[45], FT_OT_Start_Server.arr[46], FT_OT_Start_Server.arr[47], FT_OT_Start_Server.arr[48])
        FT_OT_Transforms.SetOrigo_PosRot(FT_OT_Start_Server.arr[49],FT_OT_Start_Server.arr[50],FT_OT_Start_Server.arr[51],FT_OT_Start_Server.arr[52],FT_OT_Start_Server.arr[53],FT_OT_Start_Server.arr[54],FT_OT_Start_Server.arr[55])
        FT_OT_Transforms.process_bs(FT_OT_Start_Server.arr[55:])
        FT_OT_Start_Server.shit = True

    def run_in_main_thread(function):
        FT_OT_Start_Server.execution_queue.put(function)

    def execute_queued_functions(interval):
        while not FT_OT_Start_Server.execution_queue.empty():
            FT_OT_Start_Server.execution_queue.get()
        return interval

    def timeOutStop():
        ### SHOW START BUTTON

        #FT_OT_Start_Server.s.close()
        FT_OT_Start_Server.shit = False
        FT_PT_Panel.enableRec == False
        print("timeout cancel activated")
        bpy.ops.screen.animation_cancel(False)
        FT_PT_Panel.enableStart = True
        FT_OT_Start_Server.waitingForConnection = True
        FT_OT_Start_Server.timeOutCount = 0
        FT_OT_Start_Server.REC = False
        FT_PT_Panel.enableStart = True
        FT_PT_Panel.enableRec = False
        FT_OT_Transforms.cFirstFrame = True
        FT_OT_Transforms.headFirstFrame = True
        FT_OT_Transforms.firstFrameQ = True
        FT_OT_Start_Server.justStarted = True 
        return {'FINISHED'}

    def is_port_open(ip_address, port):

        _s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        _s.settimeout(0.1)
        _s.settimeout(0.1)
        _s.setblocking(False)
        _s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        #_s = socket.socket()
        result = _s.connect_ex((ip_address, port))
        if result == 0:
            print('port OPEN')
        else:
            print ('port CLOSED, connect_ex returned: ' +str(result))

    def check_socket(host, port):
        _s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        _s.settimeout(0.1)
        with closing(_s):
            try:
                _s.bind((host, port))
                print (host, port)
                return True
            except OSError:
                return False
            finally:
                _s.close()

    def getport(context):

        if(FT_OT_Start_Server.LAST_PORT != 0):
            if FT_OT_Start_Server.check_socket(context.scene.IP_property, FT_OT_Start_Server.LAST_PORT):
                FT_OT_Start_Server.PORT = FT_OT_Start_Server.LAST_PORT
                context.scene.PORT_property = FT_OT_Start_Server.LAST_PORT
                print(f"Port {FT_OT_Start_Server.LAST_PORT} is open")
                FT_OT_Start_Server.shit = True
                return
            else:
                print(f"Last Port {FT_OT_Start_Server.LAST_PORT} is closed")
                FT_OT_Start_Server.s.close()
                print('old socket closed at port', FT_OT_Start_Server.LAST_PORT)

                if FT_OT_Start_Server.check_socket(context.scene.IP_property, FT_OT_Start_Server.LAST_PORT):
                    FT_OT_Start_Server.PORT = FT_OT_Start_Server.LAST_PORT
                    context.scene.PORT_property = FT_OT_Start_Server.LAST_PORT
                    print("CLOSED LAST PORT AND TRYING AGAIN")
                    FT_OT_Start_Server.shit = True
                    return
                else:
                    FT_OT_Start_Server.LAST_PORT = 0
                    FT_OT_Start_Server.getport(context)
                    print("TRYING NEW PORT")
        else:
            for port in range(4096, 14096):#32767):
                if FT_OT_Start_Server.check_socket(context.scene.IP_property, port):
                    FT_OT_Start_Server.PORT = port
                    FT_OT_Start_Server.LAST_PORT = port
                    context.scene.PORT_property = port
                    print(f"Port {port} is open")
                    FT_OT_Start_Server.shit = True
                    return
                else:
                    print(f"Port {port} is closed")

    RIG_DONE = False
    AVATAR_PARENT = None
    
    def AddCamera(context):

        if  bpy.context.scene.objects.get("TRACKING_Cam") is None:
            bpy.ops.object.camera_add(location=(0, 0, 0))
            trackingCam = bpy.context.active_object
            trackingCam.name = "TRACKING_Cam"
            bpy.data.cameras["Camera"].lens = 20.57674

        FT_OT_Start_Server.TRACKING_Cam = bpy.context.scene.objects.get("TRACKING_Cam")
        #bpy.data.cameras["Camera"].lens = 20.57674
        FT_OT_Transforms.TRACKING_Cam = FT_OT_Start_Server.TRACKING_Cam
        FT_OT_Transforms.TRACKING_Cam.parent = FT_OT_Transforms.IK_PARENT
        FT_OT_Start_Server.TRACKING_Cam.rotation_mode = 'QUATERNION'

    HeadLocation_OG_tuple = ([0], [0], [0])
    HeadRotation_OG_tuple = ([0], [0], [0], [0])
    HeadLocation_tuple = ([0], [0], [0])
    HeadRotation_tuple = ([0], [0], [0], [0])
    CameraLocation_tuple = ([0], [0], [0])
    CameraRotation_tuple = ([0], [0], [0], [0])

    AVATAR_FIRTS_TIME = True

    def getChildren(myObject): 
        children = [] 
        for ob in bpy.data.objects: 
            if ob.parent == myObject: 
                children.append(ob) 
        return children 

    def Check_and_Make_IK_TARGETS(context):


        if bpy.context.scene.objects.get("IK_PARENT") is None:
            o = bpy.data.objects.new( "IK_PARENT", None )
            #bpy.data.collections["MoCapSuite_Active"].objects.link(o)
            bpy.data.collections["MoCapSuite_Rig"].objects.link(o)
            FT_OT_Transforms.IK_PARENT = o
            FT_OT_Start_Server.CURRENT_Avatar.parent = o
        else:
            FT_OT_Start_Server.IK_PARENT = bpy.context.scene.objects.get("IK_PARENT")
            FT_OT_Start_Server.CURRENT_Avatar.parent = bpy.context.scene.objects.get("IK_PARENT")

        if bpy.context.scene.objects.get("HAND_IK_R") is None:
            o = bpy.data.objects.new("HAND_IK_R", None )
            #bpy.data.collections["MoCapSuite_Active"].objects.link(o)
            bpy.data.collections["MoCapSuite_Rig"].objects.link(o)
            FT_OT_Transforms.HAND_IK_TARGET_R = o
        else:
            FT_OT_Transforms.HAND_IK_TARGET_R = bpy.context.scene.objects.get("HAND_IK_R")
        
        if bpy.context.scene.objects.get("HAND_IK_L") is None:
            o = bpy.data.objects.new("HAND_IK_L", None )            
            #bpy.data.collections["MoCapSuite_Active"].objects.link(o)
            bpy.data.collections["MoCapSuite_Rig"].objects.link(o)
            FT_OT_Transforms.HAND_IK_TARGET_L = o

        else:
            FT_OT_Transforms.HAND_IK_TARGET_L = bpy.context.scene.objects.get("HAND_IK_L")
        
        if bpy.context.scene.objects.get("LEGIK_L") is None:
            o = bpy.data.objects.new("LEGIK_L", None )            
            #bpy.data.collections["MoCapSuite_Active"].objects.link(o)
            bpy.data.collections["MoCapSuite_Rig"].objects.link(o)
            FT_OT_Transforms.LEG_IK_TARGET_L = o
            cr_constraint = o.constraints.new(type='COPY_ROTATION')
            cr_constraint.target = FT_OT_Transforms.IK_PARENT
            cr_constraint.owner_space = 'WORLD'
            cr_constraint.target_space = 'WORLD'

        else:
            FT_OT_Transforms.LEG_IK_TARGET_L =  bpy.context.scene.objects.get("LEGIK_L")
            
        if bpy.context.scene.objects.get("LEGIK_R") is None:
            o = bpy.data.objects.new("LEGIK_R", None )            
            #bpy.data.collections["MoCapSuite_Active"].objects.link(o)
            bpy.data.collections["MoCapSuite_Rig"].objects.link(o)
            FT_OT_Transforms.LEG_IK_TARGET_R = o
            cr_constraint = o.constraints.new(type='COPY_ROTATION')
            cr_constraint.target = FT_OT_Transforms.IK_PARENT
            cr_constraint.owner_space = 'WORLD'
            cr_constraint.target_space = 'WORLD'
        else:
            FT_OT_Transforms.LEG_IK_TARGET_R =  bpy.context.scene.objects.get("LEGIK_R")
        if bpy.context.scene.objects.get("HIP_IK") is None:
            o = bpy.data.objects.new( "HIP_IK", None )            
            #bpy.data.collections["MoCapSuite_Active"].objects.link(o)
            bpy.data.collections["MoCapSuite_Rig"].objects.link(o)
            FT_OT_Transforms.HIP_IK_TARGET = o
            cr_constraint = o.constraints.new(type='COPY_ROTATION')
            cr_constraint.target = FT_OT_Transforms.IK_PARENT
            cr_constraint.owner_space = 'WORLD'
            cr_constraint.target_space = 'WORLD'
        else:
            FT_OT_Transforms.HIP_IK_TARGET = bpy.context.scene.objects.get("HIP_IK")
            
        if bpy.context.scene.objects.get("HEAD_IK") is None:
            o = bpy.data.objects.new("HEAD_IK", None )
            #bpy.data.collections["MoCapSuite_Active"].objects.link(o)
            bpy.data.collections["MoCapSuite_Rig"].objects.link(o)
            FT_OT_Transforms.HEAD_IK = o
        else:
            FT_OT_Transforms.HEAD_IK = bpy.context.scene.objects.get("HEAD_IK")

        if bpy.context.scene.objects.get("ORIGO") is None:
            o = bpy.data.objects.new("ORIGO", None )
            #bpy.data.collections["MoCapSuite_Active"].objects.link(o)
            bpy.data.collections["MoCapSuite_Rig"].objects.link(o)
            FT_OT_Transforms.ORIGO = o
        else:
            FT_OT_Transforms.ORIGO = bpy.context.scene.objects.get("ORIGO")
        if bpy.context.scene.objects.get("AVATAR_PARENT") is None:
            o = bpy.data.objects.new("AVATAR_PARENT", None )
            #bpy.data.collections["MoCapSuite_Active"].objects.link(o)
            bpy.data.collections["MoCapSuite_Active"].objects.link(o)
            FT_OT_Start_Server.AVATAR_PARENT = o
        else:
            FT_OT_Start_Server.AVATAR_PARENT = bpy.context.scene.objects.get("AVATAR_PARENT")

        ### COPIES FOR SAFETY
        FT_OT_Start_Server.AVATAR_PARENT = bpy.context.scene.objects.get("AVATAR_PARENT")
        FT_OT_Transforms.ORIGO = bpy.context.scene.objects.get("ORIGO")
        FT_OT_Transforms.IK_PARENT = bpy.context.scene.objects.get("IK_PARENT")
        bpy.context.scene.objects.get("IK_PARENT").parent = FT_OT_Transforms.ORIGO
        FT_OT_Start_Server.CURRENT_Avatar.parent = bpy.context.scene.objects.get("IK_PARENT")
        FT_OT_Transforms.Avatar_MESH = bpy.context.scene.objects.get("Avatar_MESH")
        
        FT_OT_Transforms.HAND_IK_TARGET_R = bpy.context.scene.objects.get("HAND_IK_R")
        FT_OT_Transforms.HAND_IK_TARGET_L = bpy.context.scene.objects.get("HAND_IK_L")
        FT_OT_Transforms.LEG_IK_TARGET_L =  bpy.context.scene.objects.get("LEGIK_L")
        FT_OT_Transforms.LEG_IK_TARGET_R =  bpy.context.scene.objects.get("LEGIK_R")
        FT_OT_Transforms.HIP_IK_TARGET = bpy.context.scene.objects.get("HIP_IK")
        FT_OT_Transforms.HEAD_IK = bpy.context.scene.objects.get("HEAD_IK")
        FT_OT_Transforms.HIP_IK_TARGET = bpy.context.scene.objects.get("HIP_IK")

        FT_OT_Transforms.HEAD_IK.parent = FT_OT_Transforms.IK_PARENT
        FT_OT_Transforms.HAND_IK_TARGET_L.parent = FT_OT_Transforms.IK_PARENT
        FT_OT_Transforms.HAND_IK_TARGET_R.parent = FT_OT_Transforms.IK_PARENT
        FT_OT_Transforms.HIP_IK_TARGET.parent = FT_OT_Transforms.IK_PARENT
        FT_OT_Transforms.LEG_IK_TARGET_R.parent = FT_OT_Transforms.IK_PARENT
        FT_OT_Transforms.LEG_IK_TARGET_L.parent = FT_OT_Transforms.IK_PARENT
        FT_OT_Transforms.ORIGO.parent = FT_OT_Start_Server.AVATAR_PARENT 

        #### LOCATIONS NOT ADDED
        bpy.context.scene.objects.get("LEGIK_R").rotation_mode = 'QUATERNION'
        bpy.context.scene.objects.get("LEGIK_L").rotation_mode = 'QUATERNION'
        bpy.context.scene.objects.get("HIP_IK").rotation_mode = 'QUATERNION'
        bpy.context.scene.objects.get("HAND_IK_R").rotation_mode = 'QUATERNION'
        bpy.context.scene.objects.get("HAND_IK_L").rotation_mode = 'QUATERNION'
        bpy.context.scene.objects.get("IK_PARENT").rotation_mode = 'QUATERNION'
        bpy.context.scene.objects.get("HEAD_IK").rotation_mode = 'QUATERNION'
        bpy.context.scene.objects.get("ORIGO").rotation_mode = 'QUATERNION'

    def CheckSelectedObject(context):
        print('see if selected object is usefull --- ')
        FT_PT_Panel.InfoText = "Checking Model.."

        ### MAKE A CHECK FUNCTION IF AVATAR IS:
        ### NEW
        ### CURRENT
        ### PREVIOUS

        selected_objects = [obj for obj in bpy.data.objects if obj.select_get() == True]

        bpy.ops.object.select_all(action='DESELECT')
        for obj in selected_objects:
            print(obj.name)
            if(obj.name == "Armature"):
                bpy.data.objects[obj.name].select_set(True)
                break
            if(obj.name == "Avatar_MESH"):
                bpy.data.objects[obj.name].select_set(True)
                break
            if(obj.name == "Wolf3D_Avatar"):
                bpy.data.objects[obj.name].select_set(True)
                break
            if(obj.name == "CURRENT_Avatar"):
                bpy.data.objects[obj.name].select_set(True)
                break
            if(obj.name == "PREVIOUS_Avatar"):
                bpy.data.objects[obj.name].select_set(True)
                break

        if "Avatar_MESH" in FT_PT_Panel.SelectedObject.name:
            print('CUR avatar possibly')
            o = FT_PT_Panel.SelectedObject
            o.name = "CURRENT_Avatar"
            FT_OT_Start_Server.Avatar_MESH = o
            FT_OT_Start_Server.CURRENT_Avatar = o.parent

        if "Armature" in FT_PT_Panel.SelectedObject.name:
            print('new avatar possibly')
            o = FT_PT_Panel.SelectedObject
            childz = FT_OT_Start_Server.getChildren(o)
            for c in childz:
                if c.name == "Armature":
                    c.name == "RIG_Armature"
            o.name = "Avatar_MESH"
            FT_OT_Start_Server.CURRENT_Avatar = o
            #### NEW SO RIG ------- ######

        else:
            if "CURRENT_Avatar" in FT_PT_Panel.SelectedObject.name:
                o = FT_PT_Panel.SelectedObject
                FT_OT_Start_Server.CURRENT_Avatar = o
                print('current avatar possibly')
                #### ---- NO NEED TO RIG --- MAKE SURE ITS NOT NEW

            else:
                if "PREVIOUS_Avatar" in FT_PT_Panel.SelectedObject.name:
                    o = FT_PT_Panel.SelectedObject
                    FT_OT_Start_Server.CURRENT_Avatar = o
                    o.name = "CURRENT_Avatar"
                    ##### ___ HOX___ NO NEED TO RE-RIG
                    print('old avatar possibly')
                else:
                    print('error: Selection not applicable')
                    FT_PT_Panel.InfoText = "error: Selection not applicable"
                    return {'FINISHED'}

        children = FT_OT_Start_Server.getChildren(FT_OT_Start_Server.CURRENT_Avatar)
        for c in children: 
            print('children name ', c.name)
            if c.name == "Wolf3D_Avatar":# in c.name:
                 FT_OT_Start_Server.CURRENT_Avatar = c.parent
                 FT_OT_Start_Server.Avatar_MESH = c
                 FT_OT_Transforms.Avatar_MESH = c 
                 c.parent.name = "CURRENT_Avatar"
                 c.name = "Avatar_MESH"
            print('children name ', c.name)
            if c.name == "Avatar_MESH":# in c.name:
                 FT_OT_Start_Server.CURRENT_Avatar = c.parent
                 FT_OT_Start_Server.Avatar_MESH = c
                 FT_OT_Transforms.Avatar_MESH = c
                 c.parent.name = "CURRENT_Avatar"

        FT_PT_Panel.InfoText = ""
            # else:
            #     print('error: Selection not applicable')
            #     FT_PT_Panel.InfoText = "error: Selection not applicable"
            #     return {'FINISHED'}  
            
    HeadLocation_trans = None
    def MakeRig(context):

        ## Function for storing and setting OG - IK locations and rotations
        # ### --- > RENAME ---> HERE WITH: CURRENT 
        # if FT_OT_Start_Server.HeadLocation_trans is None:
        #     FT_OT_Start_Server.CURRENT_Avatar = bpy.data.objects["CURRENT_Avatar"]
        #     bpy.context.view_layer.objects.active = FT_OT_Start_Server.CURRENT_Avatar
        #     bpy.ops.object.mode_set(mode="POSE")
        #     FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = None
        #     bone = FT_OT_Start_Server.CURRENT_Avatar.pose.bones["HeadTop_End"]
        #     FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = FT_OT_Start_Server.CURRENT_Avatar.data.bones["HeadTop_End"]
        #     bone.bone.select = True
        #     headBoneMatrix = bone.matrix
        #     matrix_3x3 = headBoneMatrix.to_3x3()
        #     #rotation_3x3 = rotation.to_3x3()
        #     headIK_loc = headBoneMatrix.to_translation()
        #     FT_OT_Start_Server.HEAD_IK.location = headIK_loc
        #     bpy.ops.object.mode_set(mode="OBJECT")

        #FT_OT_Start_Server.CURRENT_Avatar = bpy.data.objects["CURRENT_Avatar"]
        bpy.context.view_layer.objects.active = FT_OT_Start_Server.CURRENT_Avatar
        bpy.ops.object.mode_set(mode="POSE")
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = None
        bone = FT_OT_Start_Server.CURRENT_Avatar.pose.bones["HeadTop_End"]
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = FT_OT_Start_Server.CURRENT_Avatar.data.bones["HeadTop_End"]
        bone.bone.select = True

        headBoneMatrix = bone.matrix
        matrix_3x3 = headBoneMatrix.to_3x3()
        HeadLocation_top = headBoneMatrix.to_translation()      
        FT_OT_Start_Server.HeadLocation_trans = HeadLocation_top#(HeadLocation_top.x, HeadLocation_top.y, HeadLocation_top.z)

        bpy.context.view_layer.objects.active = bpy.context.scene.objects.get("CURRENT_Avatar") 
        bpy.ops.object.mode_set(mode="POSE")
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = None
        bone = FT_OT_Start_Server.CURRENT_Avatar.pose.bones["Head"]
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = FT_OT_Start_Server.CURRENT_Avatar.data.bones["Head"]
        bone.bone.select = True

        headBoneMatrix = bone.matrix
        HeadLocation = headBoneMatrix.to_translation()
        HeadRotation = headBoneMatrix.to_quaternion()
        CameraLocation = headBoneMatrix.to_translation()
        CameraRotation = headBoneMatrix.to_quaternion()
    
        FT_OT_Transforms.HEAD_IK = bpy.context.scene.objects.get("HEAD_IK")
        FT_OT_Transforms.HEAD_IK.location = HeadLocation_top;
        bpy.ops.pose.constraint_add(type="IK")

        constraint = bone.constraints[-1]  # Get the last added constraint
        constraint.target = FT_OT_Transforms.HEAD_IK
        constraint.chain_count = 5
        constraint.use_rotation = True

        ## ADD HAND IK'S
        ## RIGHT

        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = None
        bone = FT_OT_Start_Server.CURRENT_Avatar.pose.bones["RightHand"]
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = FT_OT_Start_Server.CURRENT_Avatar.data.bones["RightHand"]
        bone.bone.select = True

        headBoneMatrix = bone.matrix
        HeadLocation = headBoneMatrix.to_translation()
        HeadRotation = headBoneMatrix.to_quaternion()
        bpy.context.scene.objects.get("HAND_IK_R").location = HeadLocation
        bpy.ops.pose.constraint_add(type="IK")

        constraint = bone.constraints[-1]  # Get the last added constraint
        FT_OT_Transforms.HAND_IK_TARGET_R = bpy.context.scene.objects.get("HAND_IK_R")
        constraint.target = FT_OT_Transforms.HAND_IK_TARGET_R
        constraint.chain_count = 3
        constraint.use_rotation = True
        ## LEFT
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = None
        bone = FT_OT_Start_Server.CURRENT_Avatar.pose.bones["LeftHand"]
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = FT_OT_Start_Server.CURRENT_Avatar.data.bones["LeftHand"]
        bone.bone.select = True

        headBoneMatrix = bone.matrix
        HeadLocation = headBoneMatrix.to_translation()
        HeadRotation = headBoneMatrix.to_quaternion()
        bpy.context.scene.objects.get("HAND_IK_L").location = HeadLocation

        bpy.ops.pose.constraint_add(type="IK")

        constraint = bone.constraints[-1]  # Get the last added constraint
        FT_OT_Transforms.HAND_IK_TARGET_L = bpy.context.scene.objects.get("HAND_IK_L")

        constraint.target = FT_OT_Transforms.HAND_IK_TARGET_L
        constraint.chain_count = 3
        constraint.use_rotation = True

        ## LEG_LEFT
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = None
        bone = FT_OT_Start_Server.CURRENT_Avatar.pose.bones["LeftFoot"]
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = FT_OT_Start_Server.CURRENT_Avatar.data.bones["LeftFoot"]
        bone.bone.select = True

        headBoneMatrix = bone.matrix
        HeadLocation = headBoneMatrix.to_translation()
        HeadRotation = headBoneMatrix.to_quaternion()
        bpy.context.scene.objects.get("LEGIK_L").location = HeadLocation
        bpy.ops.pose.constraint_add(type="IK")

        constraint = bone.constraints[-1]  # Get the last added constraint
        FT_OT_Transforms.LEG_IK_TARGET_L = bpy.context.scene.objects.get("LEGIK_L")

        constraint.target = FT_OT_Transforms.LEG_IK_TARGET_L
        constraint.chain_count = 2
        constraint.use_rotation = False
        constraint.use_tail = False
        ## COPY ROTATION CONSTRAINT

        bpy.ops.pose.constraint_add(type="LIMIT_ROTATION")
        constraint = bone.constraints[-1]  # Get the last added constraint
        constraint.use_limit_x = True
        constraint.use_limit_y = True
        constraint.use_limit_z = True
        #constraint.target = bpy.context.scene.objects.get("LEGIK_R")
        constraint.owner_space = 'LOCAL_WITH_PARENT'
        constraint.target_space = 'LOCAL'

        ## LEG_RIGHT
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = None
        bone = FT_OT_Start_Server.CURRENT_Avatar.pose.bones["RightFoot"]
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = FT_OT_Start_Server.CURRENT_Avatar.data.bones["RightFoot"]
        bone.bone.select = True

        headBoneMatrix = bone.matrix
        HeadLocation = headBoneMatrix.to_translation()
        HeadRotation = headBoneMatrix.to_quaternion()
        bpy.context.scene.objects.get("LEGIK_R").location = HeadLocation

        bpy.ops.pose.constraint_add(type="IK")

        constraint = bone.constraints[-1]  # Get the last added constraint
        FT_OT_Transforms.LEG_IK_TARGET_R = bpy.context.scene.objects.get("LEGIK_R")
        constraint.target = FT_OT_Transforms.LEG_IK_TARGET_R
        constraint.chain_count = 2
        constraint.use_rotation = False
        constraint.use_tail = False

        ## COPY ROTATION CONSTRAINT
        bpy.ops.pose.constraint_add(type="LIMIT_ROTATION")
        constraint = bone.constraints[-1]  # Get the last added constraint
        constraint.use_limit_x = True
        constraint.use_limit_y = True
        constraint.use_limit_z = True
        #constraint.target = bpy.context.scene.objects.get("LEGIK_R")
        constraint.owner_space = 'LOCAL_WITH_PARENT'

        ## HIPS
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = None
        bone = FT_OT_Start_Server.CURRENT_Avatar.pose.bones["Hips"]
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = FT_OT_Start_Server.CURRENT_Avatar.data.bones["Hips"]
        bone.bone.select = True
        headBoneMatrix = bone.matrix
        HeadLocation = headBoneMatrix.to_translation()
        HeadRotation = headBoneMatrix.to_quaternion()
        bpy.context.scene.objects.get("HIP_IK").location = HeadLocation

        bpy.ops.pose.constraint_add(type="COPY_LOCATION")

        constraint = bone.constraints[-1]  # Get the last added constraint
        FT_OT_Transforms.HIP_IK_TARGET = bpy.context.scene.objects.get("HIP_IK")
        constraint.target = FT_OT_Transforms.HIP_IK_TARGET
        bpy.ops.pose.constraint_add(type="COPY_ROTATION")
        constraint = bone.constraints[-1]
        constraint.owner_space = 'LOCAL'
        constraint.target_space = 'LOCAL'
        # Get the last added constraint
        constraint.target = bpy.context.scene.objects.get("HIP_IK")
        #constraint.chain_count = 3
        #constraint.use_rotation = True

        bpy.ops.object.mode_set(mode="OBJECT")
        #FT_OT_Transforms.Avatar_MESH = FT_OT_Start_Server.CURRENT_Avatar
        #FT_OT_Start_Server.Avatar_MESH = FT_OT_Start_Server.CURRENT_Avatar

##        FT_OT_Start_Server.IK_PARENT.rotation_euler.rotate_axis("X", radians(90))
#         FT_OT_Transforms.HIP_IK_TARGET.parent = FT_OT_Start_Server.IK_PARENT
#         FT_OT_Transforms.HIP_IK_TARGET.rotation_euler.rotate_axis("X", radians(90))
#         FT_OT_Transforms.IK_PARENT = FT_OT_Start_Server.IK_PARENT
#         FT_OT_Transforms.HEAD_IK.parent = FT_OT_Start_Server.IK_PARENT
#         FT_OT_Transforms.HEAD_IK.location = FT_OT_Start_Server.HeadLocation_trans
#         FT_OT_Transforms.HEAD_IK.rotation_euler.rotate_axis("X", radians(90))
#         FT_OT_Transforms.HAND_IK_TARGET_L.parent = FT_OT_Start_Server.IK_PARENT
#         FT_OT_Transforms.HAND_IK_TARGET_L.rotation_euler.rotate_axis("X", radians(270))
#         FT_OT_Transforms.HAND_IK_TARGET_R.parent = FT_OT_Start_Server.IK_PARENT
#         FT_OT_Transforms.HAND_IK_TARGET_R.rotation_euler.rotate_axis("X", radians(270))
#         FT_OT_Transforms.LEG_IK_TARGET_R.parent = FT_OT_Start_Server.IK_PARENT
#         #FT_OT_Transforms.LEG_IK_TARGET_R.rotation_euler.rotate_axis("X", radians(90))
        
#         FT_OT_Transforms.LEG_IK_TARGET_L.parent = FT_OT_Start_Server.IK_PARENT
          #FT_OT_Transforms.LEG_IK_TARGET_L.rotation_euler.rotate_axis("X", radians(90))

#        FT_OT_Start_Server.SetTranslations_CAM_and_EMPTY(context)
#        FT_OT_Start_Server.SetParents()
#        FT_OT_Transforms.save_initial_values()

        FT_PT_Panel.enableStart = True
        print('done rig')

    IK_PARENT = None
    HAND_IK_TARGET_R = None
    HAND_IK_TARGET_L = None

    def GET_OG_HEADPOS(context):

        for o in bpy.data.objects:
            if o.name == "Armature":
        #if(bpy.data.objects["Armature"] is not None):
                FT_OT_Start_Server.CURRENT_Avatar = bpy.data.objects["Armature"]
                FT_OT_Start_Server.CURRENT_Avatar.name = "Current_Armature"
        for o in bpy.data.objects:
            if o.name == "Wolf3D_Avatar":
                context.scene.Avatar_MESH = o
                o.name = "CURRENT_Avatar"
        FT_OT_Start_Server.CURRENT_Avatar = bpy.data.objects["Current_Armature"]
        bpy.context.view_layer.objects.active = FT_OT_Start_Server.CURRENT_Avatar
        bpy.ops.object.mode_set(mode="POSE")
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = None
        bone = FT_OT_Start_Server.CURRENT_Avatar.pose.bones["HeadTop_End"]
        FT_OT_Start_Server.CURRENT_Avatar.data.bones.active = FT_OT_Start_Server.CURRENT_Avatar.data.bones["HeadTop_End"]
        bone.bone.select = True

        headBoneMatrix = bone.matrix
        matrix_3x3 = headBoneMatrix.to_3x3()
        #rotation_3x3 = rotation.to_3x3()
        HeadLocation = headBoneMatrix.to_translation()
        HeadRotation = headBoneMatrix.to_quaternion()
        FT_OT_Start_Server.HeadLocation_OG_tuple = (HeadLocation[0], HeadLocation[1], HeadLocation[2])
        FT_OT_Start_Server.HeadRotation_OG_tuple = (HeadRotation.w, HeadRotation.x, HeadRotation.y, HeadRotation.z)
        bpy.ops.object.mode_set(mode="OBJECT")
        FT_OT_Start_Server.AVATAR_FIRTS_TIME = False
    IP_property = None

    def getNetifaces_stuff():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            # doesn't even have to be reachable
            s.connect(('10.255.255.255', 1))
            IP = s.getsockname()[0]
        except:
            IP = '127.0.0.1'
        finally:
            s.close()
        return IP

    def setIP(context):
        print('ip',FT_OT_Start_Server.getNetifaces_stuff())
        bpy.data.scenes.get( "Scene" ).IP_property =FT_OT_Start_Server.getNetifaces_stuff()

    def SetTranslations_CAM_and_EMPTY(context):

        #FT_OT_Start_Server.CURRENT_Avatar = context.scene.Avatar_MESH
        FT_OT_Start_Server.Avatar_MESH = bpy.context.scene.objects.get("Avatar_MESH")
        FT_OT_Start_Server.TRACKING_Cam = bpy.context.scene.objects.get("TRACKING_Cam")
        FT_OT_Transforms.TRACKING_Cam = bpy.context.scene.objects.get("TRACKING_Cam")
        FT_OT_Transforms.Avatar_MESH = FT_OT_Start_Server.CURRENT_Avatar
        FT_OT_Transforms.HEAD_IK =  bpy.context.scene.objects.get("HEAD_IK")
        FT_OT_Transforms.HAND_IK_TARGET_L = bpy.context.scene.objects.get("HAND_IK_L")
        FT_OT_Transforms.HAND_IK_TARGET_R = bpy.context.scene.objects.get("HAND_IK_R")
        FT_OT_Transforms.LEG_IK_TARGET_R =  bpy.context.scene.objects.get("LEGIK_R")
        FT_OT_Transforms.LEG_IK_TARGET_L =  bpy.context.scene.objects.get("LEGIK_L")
        FT_OT_Transforms.HIP_IK_TARGET =    bpy.context.scene.objects.get("HIP_IK")
        FT_OT_Transforms.IK_PARENT =    bpy.context.scene.objects.get("IK_PARENT")

        #### LOCATIONS NOT ADDED
        bpy.context.scene.objects.get("LEGIK_R").rotation_mode = 'QUATERNION'
        bpy.context.scene.objects.get("LEGIK_L").rotation_mode = 'QUATERNION'
        bpy.context.scene.objects.get("HIP_IK").rotation_mode = 'QUATERNION'
        bpy.context.scene.objects.get("HAND_IK_R").rotation_mode = 'QUATERNION'
        bpy.context.scene.objects.get("HAND_IK_L").rotation_mode = 'QUATERNION'
        bpy.context.scene.objects.get("IK_PARENT").rotation_mode = 'QUATERNION'

    def SetParents():

            FT_OT_Transforms.Avatar_MESH = FT_OT_Start_Server.Avatar_MESH
            #FT_OT_Start_Server.Avatar_MESH = FT_OT_Start_Server.CURRENT_Avatar
            FT_OT_Transforms.HIP_IK_TARGET.parent = FT_OT_Start_Server.IK_PARENT
            FT_OT_Transforms.HIP_IK_TARGET.rotation_euler.rotate_axis("X", radians(90))
            FT_OT_Transforms.IK_PARENT = FT_OT_Start_Server.IK_PARENT
            FT_OT_Transforms.HEAD_IK.parent = FT_OT_Start_Server.IK_PARENT
            FT_OT_Transforms.HEAD_IK.location = FT_OT_Start_Server.HeadLocation_trans
            FT_OT_Transforms.HEAD_IK.rotation_euler.rotate_axis("X", radians(90))
            FT_OT_Transforms.HAND_IK_TARGET_L.parent = FT_OT_Start_Server.IK_PARENT
            FT_OT_Transforms.HAND_IK_TARGET_L.rotation_euler.rotate_axis("X", radians(270))
            FT_OT_Transforms.HAND_IK_TARGET_R.parent = FT_OT_Start_Server.IK_PARENT
            FT_OT_Transforms.HAND_IK_TARGET_R.rotation_euler.rotate_axis("X", radians(270))
            FT_OT_Transforms.LEG_IK_TARGET_R.parent = FT_OT_Start_Server.IK_PARENT
            #FT_OT_Transforms.LEG_IK_TARGET_R.rotation_euler.rotate_axis("X", radians(90))
            FT_OT_Transforms.LEG_IK_TARGET_L.parent = FT_OT_Start_Server.IK_PARENT
            #FT_OT_Transforms.LEG_IK_TARGET_L.rotation_euler.rotate_axis("X", radians(90))
            FT_OT_Transforms.TRACKING_Cam =FT_OT_Start_Server.TRACKING_Cam
            FT_OT_Transforms.TRACKING_Cam.parent = FT_OT_Start_Server.IK_PARENT

    Collection_Active = None
    Collection_InActive = None

    def Check_Make_Collections(context):
        collectionFound = False
        for myCol in bpy.data.collections:
            print(myCol.name)
            if myCol.name == "MoCapSuite_InActive":
                collectionFound = True
                print ("Collection found in scene")
                break
        if collectionFound == False:
            newCol = bpy.data.collections.new("MoCapSuite_InActive")
            bpy.context.scene.collection.children.link(newCol)
            newCol.hide_viewport = True
        collectionFound = False
        for myCol in bpy.data.collections:
            print(myCol.name)
            if myCol.name == "MoCapSuite_Active":
                collectionFound = True
                print ("Collection found in scene")
                break
        if collectionFound == False:
            newCol = bpy.data.collections.new("MoCapSuite_Active")
            bpy.context.scene.collection.children.link(newCol)
        for myCol in bpy.data.collections:
            print(myCol.name)
            if myCol.name == "MoCapSuite_Rig":
                collectionFound = True
                print ("Collection found in scene")
                break
        if collectionFound == False:
            newCol = bpy.data.collections.new("MoCapSuite_Rig")
            bpy.context.scene.collection.children.link(newCol)

        bpy.data.collections['MoCapSuite_Rig'].hide_viewport = True
    
    def execute(self, context):

        FT_OT_Start_Server.context = context
        FT_OT_Start_Server.Check_Make_Collections(context)
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children["MoCapSuite_Active"]

        FT_OT_Start_Server.context = context
        FT_OT_Start_Server.HOST = FT_OT_Start_Server.context.scene.IP_property
        FT_OT_Start_Server.getport(context)
        FT_OT_Start_Server.timeOutCount = 0
        FT_OT_Start_Server.waitingForConnection = True
        FT_OT_Start_Server.CheckSelectedObject(context)
        FT_OT_Start_Server.Check_and_Make_IK_TARGETS(context)
        FT_OT_Start_Server.AddCamera(context)
        ### Save CAM & HEAD
        FT_OT_Start_Server.MakeRig(context)
        FT_OT_Transforms.save_initial_values()
      
        ### -----CONNECTION STUFF-----------------###
        print('ip ', FT_OT_Start_Server.getNetifaces_stuff())
        FT_OT_Transforms.reset_blendShapes(FT_OT_Start_Server.TRACKING_Cam, FT_OT_Transforms.HEAD_IK, FT_OT_Start_Server.Avatar_MESH)
        #bpy.context.scene.collection.children.unlink(bpy.context.scene.collection.children)
        children = FT_OT_Start_Server.getChildren(FT_OT_Start_Server.IK_PARENT)
        #    bpy.data.collections["MoCapSuite_Active"].objects.link(FT_OT_Transforms.IK_PARENT)
        #    for c in children:
        #    bpy.context.scene.collection.objects.unlink(c)
        #    bpy.data.collections["MoCapSuite_Active"].objects.link(c)
        #    bpy.context.scene.collection.objects.unlink(FT_OT_Transforms.IK_PARENT)
        #    bpy.data.collections["MoCapSuite_Active"].objects.link(FT_OT_Transforms.IK_PARENT)

        FT_OT_Start_Server.timeOutSeconds = .004
        #FT_OT_Start_Server.timeOutSeconds = 1
        #FT_OT_Start_Server.timeOutStop()
        print(context.scene.IP_property, 'ip')
        #FT_OT_Transforms.firstFrameQ = True
        #FT_OT_Transforms.headFirstFrame = True
        FT_OT_Start_Server.stop_threads = True
        FT_OT_Start_Server.isEnding = False
        #FT_OT_Transforms.cFirstFrame = True
        FT_OT_Transforms.REC = False
        FT_PT_Panel.enableStart = False
        FT_PT_Panel.enableStop = True
        FT_OT_Start_Server.justStarted = True
        FT_OT_Start_Server.shit = True
        bpy.ops.screen.animation_play()
        #FT_OT_Start_Server.ResumeUpdatingTransforms()
        return {'FINISHED'}

    # def start_server():
    #     print(FT_OT_Start_Server.context.scene.IP_property, 'this is the porttttt!!!')
    #     FT_OT_Start_Server.HOST = FT_OT_Start_Server.context.scene.IP_property

    #     FT_OT_Start_Server.getport(FT_OT_Start_Server.context)
    #     #FT_OT_Start_Server.PORT = context.scene.PORT_property
    #     FT_OT_Start_Server.timeOutCount = 0
    #     FT_OT_Start_Server.waitingForConnection = True
    #     FT_OT_Start_Server.context = FT_OT_Start_Server.context

    #     FT_OT_Start_Server.timeOutSeconds = .004
    #     FT_OT_Transforms.firstFrameQ = True
    #     FT_OT_Transforms.headFirstFrame = True
    #     FT_OT_Start_Server.stop_threads = True
    #     FT_OT_Start_Server.isEnding = False
    #     FT_OT_Transforms.cFirstFrame = True
    #     FT_OT_Transforms.REC = False
    #     ### --- Update tracking HEAD object
    #     if(FT_OT_Start_Server.CURRENT_Avatar is None):
    #         FT_OT_Start_Server.context.scene.Avatar_MESH.name = "CURRENT_Avatar"
    #         FT_OT_Start_Server.Avatar_MESH = FT_OT_Start_Server.context.scene.Avatar_MESH
    #         FT_OT_Start_Server.TRACKING_Cam = FT_OT_Start_Server.context.scene.TRACKING_Cam
    #         FT_OT_Transforms.Avatar_MESH = FT_OT_Start_Server.context.scene.Avatar_MESH
    #         FT_OT_Transforms.TRACKING_Cam = FT_OT_Start_Server.context.scene.TRACKING_Cam

    #     FT_OT_Transforms.a()        
    #     FT_PT_Panel.enableStart = False
    #     FT_PT_Panel.enableStop = True
        
    #     FT_OT_Start_Server.justStarted = True
    #     FT_OT_Start_Server.shit = True
    #     bpy.ops.screen.animation_play()
    #     FT_OT_Start_Server.ResumeUpdatingTransforms()
    #     return {'FINISHED'} 

    shit = False
    waitingForConnection = False
    Rig_Armature = None
    HEAD_IK = None

class FT_OT_Stop_Server(Operator):

    bl_idname = "object.stop_server"
    bl_label = "Stop server"
    bl_description = "Stop the facetracking server"

    def execute(self, context):  
        ### SHOW START BUTTON
        bpy.ops.screen.animation_cancel(False)
        FT_OT_Start_Server.justStarted = False
        FT_OT_Start_Server.REC = False
        FT_OT_Start_Server.shit = False
        FT_OT_Start_Server.timeOutStop()
        return {'FINISHED'}
    
    def stop_server():    
        ### SHOW START BUTTON
        bpy.ops.screen.animation_cancel(False)
        FT_OT_Start_Server.justStarted = False
        FT_OT_Start_Server.REC = False
        FT_OT_Start_Server.shit = False
        FT_OT_Start_Server.timeOutStop()

        #FT_OT_Start_Server.start_server()
        return {'FINISHED'}

@persistent
def FT_RUN_Server_Cycle(dummy1,dummy2):
    if(FT_OT_Start_Server.shit == True):
        FT_OT_Start_Server.server_infinite()
        #print('server wanted to start')
    return {'FINISHED'}

bpy.app.handlers.frame_change_post.append(FT_RUN_Server_Cycle)
#bpy.app.handlers.load_post.append(SET_IP)

class FT_OT_Start_Recording(Operator):
    bl_idname = "object.start_rec"
    bl_label = "Start REC"
    bl_description = "Start recording keyframes"

    def execute(self, context):
        if FT_PT_Panel.REC_ENABLED == False:
            print("no rec should be available")
            FT_PT_Panel.enableRec = False
            return {'FINISHED'}          
                                           
        print("rec")
        #FT_OT_Transforms.Avatar_MESH = FT_OT_Start_Server.CURRENT_Avatar
        print(FT_PT_Panel.REC_ENABLED)
        FT_OT_Transforms.REC = True
        FT_PT_Panel.REC_running = True
        FT_PT_Panel.enableRec = False
        return {'FINISHED'}

class FT_OT_Download_Default_Model(Operator):    

    bl_idname = "object.dona_model"
    bl_label = "Start REC"
    bl_description = "Downloads default model"

    def dona_the_model():
        FT_OT_Start_Server.FORM_Button = True                                 
        FT_OT_Start_Server.import_glb('https://models.readyplayer.me/63bcf4d325903a9ffc56c175.glb')
        return {'FINISHED'}
    
    def execute(self, context):
        FT_OT_Start_Server.FORM_Button = True                                 
        FT_OT_Start_Server.import_glb_button(context, 'https://models.readyplayer.me/63bcf4d325903a9ffc56c175.glb')
        return {'FINISHED'}

class FT_OT_Upload_Model(Operator):
    
    bl_idname = "object.upload_model"
    bl_label = "Upload Model"
    bl_description = "Uploads model"
    first = False

    servu = None
    exs = None
    ip = None

    def upload_complete():
        print("File uploaded successfully.")

        time.sleep(3)
        FT_OT_Upload_Model.exs.close()
        FT_OT_Upload_Model.servu.socket.close()
        FT_OT_Upload_Model.servu.close_all()
        return {'FINISHED'}

    def execute(self, context):

        if FT_OT_Upload_Model.exs is not None:
            FT_OT_Upload_Model.exs.detach()
            FT_OT_Upload_Model.exs.close()
        if FT_OT_Upload_Model.servu is not None:
            FT_OT_Upload_Model.servu.close_all()

        if FT_OT_Upload_Model.ip is None:
            FT_OT_Upload_Model.ip = FT_OT_Start_Server.getNetifaces_stuff()
            
        exs = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        exs.setblocking(False)
        exs.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        exs.bind((FT_OT_Upload_Model.ip, context.scene.PORT_property))

        FT_OT_Upload_Model.exs = exs
        chunk_size = 1024 * 4
        selected_obj = bpy.context.active_object
        addon_dir = os.path.join(bpy.utils.user_resource('SCRIPTS'), 'addons/MoCap_Suite_from_web_before_fbt_001/')

        new_obj_path = os.path.join(addon_dir, 'selected_object.glb')
        bpy.ops.export_scene.gltf(filepath=new_obj_path, use_selection=True)

        string_url = "ftp://" + FT_OT_Upload_Model.ip + ":2121/" + "selected_object.glb"
        print(string_url.encode())
        packet_data = bytes([1]) + string_url.encode()
        #exs.sendto(packet_data, ('192.168.8.162', 4106))
        print("sendmodel active to = ",
              context.scene.IP_property, ":", context.scene.PORT_property)
        exs.sendto(packet_data, (context.scene.IP_property,
                   context.scene.PORT_property))
       # //print('') 
        authorizer = DummyAuthorizer()
        _filepath = bpy.path.abspath(new_obj_path)
        authorizer.add_anonymous(addon_dir, perm='elradfmwM')
        handler = FTPHandler
        handler.authorizer = authorizer

        # Modify the FTPHandler class to add a callback function
        class MyFTPHandler(FTPHandler):
            def on_file_sent(self, file):
                time.sleep(5)
                FT_OT_Upload_Model.upload_complete()

        server = FTPServer((FT_OT_Upload_Model.ip, 2121), MyFTPHandler)
        FT_OT_Upload_Model.servu = server
        server.serve_forever()
        return {'FINISHED'}

class FT_OT_Stop_Recording(Operator):
    bl_idname = "object.stop_rec"
    bl_label = "Stop Rec"
    bl_description = "Stop recording keyframes"

    def execute(self, context):
        FT_OT_Transforms.REC = False
        FT_PT_Panel.REC_running = False
        #FT_PT_Panel.enableRec = True
        print("rec")
        return {'FINISHED'}  





    #     bpy.ops.export_scene.gltf(filepath=file_path, use_selection=True)

