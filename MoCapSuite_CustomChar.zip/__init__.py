
bl_info = {
        'name' : 'MoCap Suite',
        'author' : 'bnidz',
        'description' : 'Addon for MoCap Suite iOS App',
        'blender' : (2, 80, 0),
        'version' : (0, 1, 55),  
        'location' : 'View3D',
        'category' : 'Object'}

import bpy, os, importlib, socket, urllib.request, subprocess, platform
from bpy.types import PointerProperty, Scene, Object, BoolProperty, ArmatureBones
from bpy import context
import os, importlib, socket, urllib.request, subprocess, platform, sys, threading
def install_package(package):
    subprocess.call([sys.exec_prefix + '/bin/python3.10', '-m', 'pip','install', '--upgrade', '--target', sys.exec_prefix + '/lib/python3.10/site-packages', package])
    
#install_package('bpywebsocket')
#install_package('websocket')
install_package('pyftpdlib')

from . ft_op_new import FT_OT_Start_Server, FT_OT_Stop_Server, FT_OT_Start_Recording, FT_OT_Stop_Recording, FT_OT_Download_Default_Model, FT_OT_Upload_Model
from . ft_transforms import FT_OT_Transforms
from . ft_panel import FT_PT_Panel
classes = (FT_OT_Start_Server, FT_OT_Stop_Server, FT_PT_Panel, FT_OT_Start_Recording, FT_OT_Stop_Recording, FT_OT_Transforms, FT_OT_Download_Default_Model, FT_OT_Upload_Model)

def mac_get_ip_address():
    output = subprocess.check_output("ifconfig").decode()
    # Parse the output to extract the IP address
    lines = output.split("\n")
    for line in lines:
        if "inet " in line:
            parts = line.split()
            if parts[1] != "127.0.0.1":
                return parts[1]
    return None

def win_get_ip_address():
    output = subprocess.check_output("ipconfig").decode()
    # Parse the output to extract the IP address
    lines = output.split("\n")
    for line in lines:
        if "IPv4 Address" in line:
            parts = line.split(": ")
            if parts[1] != "127.0.0.1":
                return parts[1]
    return None

def getNetifaces_stuff():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except:
        IP = '127.0.0.1'
    finally:
        s.close()
    #FT_OT_Start_Server.IP_prop = IP
    return IP

def register():
    
    for c in classes:
        bpy.utils.register_class(c)

    bpy.types.Scene.IP_property = bpy.props.StringProperty \
    (
        name = "This IP, use this in APP too",
        description = "IP Address for this Computer", 
        default = getNetifaces_stuff(),
    )
    bpy.types.Scene.PORT_property = bpy.props.IntProperty \
    (
        name = "Port",
        description = "Port for tracking connection, change port if not able to connect",
        default = 4096
    )

    bpy.types.Scene.TRACKING_face = bpy.props.PointerProperty \
    (
        type = bpy.types.Object,
        name = "Face",
        description = "Mesh object with the tracking blendshapes"
    )

    bpy.types.Scene.TRACKING_cam = bpy.props.PointerProperty \
    (
        type = bpy.types.Object,
        name = "Camera",
        description = "Camera Object to control with client touch"
    )

    bpy.types.Scene.track_face_rot = bpy.props.BoolProperty \
    (
        name="Track head rotation",
        description="Track face rotation",
        default = False
    )
    bpy.types.Scene.track_face_pos = bpy.props.BoolProperty \
    (
        name="Track head position",
        description="Track head position",
        default = False
    )

    bpy.types.Scene.track_cam = bpy.props.BoolProperty \
    (
        name="Track camera",
        description="Track camera position from client",
        default = False
    )

def unregister():
    
    bpy.utils.unregister_class(FT_OT_Start_Server)
    bpy.utils.unregister_class(FT_PT_Panel)
    bpy.utils.unregister_class(FT_OT_Stop_Server)
    bpy.utils.unregister_class(FT_OT_Start_Recording)
    bpy.utils.unregister_class(FT_OT_Transforms)
    bpy.utils.unregister_class(FT_OT_Stop_Recording)
    bpy.utils.unregister_class(FT_OT_Download_Default_Model)
    bpy.utils.unregister_class(FT_OT_Upload_Model)
    
    #bpy.utils.unregister_class(FT_OT_ResetCharPos)

    del bpy.types.Scene.IP_property
    del bpy.types.Scene.PORT_property
    del bpy.types.Scene.TRACKING_face  
    del bpy.types.Scene.track_cam
    del bpy.types.Scene.track_face_rot
    del bpy.types.Scene.track_face_pos
    del bpy.types.Scene.TRACKING_cam
    #del bpy.types.Scene.Face_Empty