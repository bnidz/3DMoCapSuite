# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "FaceTrackAddon",
    "author" : "bnidz",
    "description" : "",
    "blender" : (2, 80, 0),
    "version" : (0, 0, 3),
    "location" : "View3D",
    "warning" : "",
    "category" : "Object"
}

import bpy
from bpy.types import PointerProperty, Scene, Object, BoolProperty, ArmatureBones
#from . ft_op import FT_OT_Start_Server, FT_OT_Stop_Server
from . ft_panel import FT_PT_Panel

from . ft_op_new import FT_OT_Start_Server, FT_OT_Stop_Server, FT_OT_Start_Recording

classes = (FT_OT_Start_Server, FT_OT_Stop_Server, FT_PT_Panel, FT_OT_Start_Recording)

def register():
    for c in classes:
        bpy.utils.register_class(c)

    bpy.types.Scene.IP_property = bpy.props.StringProperty \
    (
        name = "IP",
        description = "IP Address for this server",
        default = "192.168.8.116"
    )
    bpy.types.Scene.PORT_property = bpy.props.IntProperty \
    (
        name = "Port",
        description = "Port for tracking connection",
        default = 8080
    )
    bpy.types.Scene.TRACKING_face = bpy.props.PointerProperty \
    (
        type = bpy.types.Object,
        name = "Face",
        description = "Mesh object with the tracking blendshapes"
    )

#    bpy.types.Scene.TRACKING_head = bpy.props.PointerProperty \
#    (
#        type = bpy.types.Object,
#        name = "Head Bone",
#        description = "Bone that controls head movement"
#    )
    bpy.types.Scene.TRACKING_cam = bpy.props.PointerProperty \
    (
        type = bpy.types.Object,
        name = "Camera",
        description = "Camera Object to control with client touch"
    )

    bpy.types.Scene.track_face_rot = bpy.props.BoolProperty \
    (
        name="Track head rotation",
        description="Track face rotation",
        default = False
    )
    bpy.types.Scene.track_face_pos = bpy.props.BoolProperty \
    (
        name="Track head position",
        description="Track head position",
        default = False
    )

    bpy.types.Scene.track_cam = bpy.props.BoolProperty \
    (
        name="Track camera",
        description="Track camera position from client",
        default = False
    )

#    bpy.types.Scene.REC_shapes = bpy.props.BoolProperty \
#    (
#        name="Record BlendShapes",
#        description="Record blendshapes on the current frame. Press play to to record live.",
#        default = False
#    )


def unregister():
    
    bpy.utils.unregister_class(FT_OT_Start_Server)
    bpy.utils.unregister_class(FT_PT_Panel)
    bpy.utils.unregister_class(FT_OT_Stop_Server)
    bpy.utils.unregister_class(FT_OT_Start_Recording)

    del bpy.types.Scene.IP_property
    del bpy.types.Scene.PORT_property
    del bpy.types.Scene.TRACKING_face  
    del bpy.types.Scene.track_cam
    del bpy.types.Scene.track_face_rot
    #del bpy.types.Scene.REC_shapes
    del bpy.types.Scene.TRACKING_cam