from asyncio import start_server
from multiprocessing import context
import bpy
from bpy.types import Operator
from math import radians
from bpy.props import *
from .ft_panel import FT_PT_Panel
from array import *

class FT_OT_Transforms(Operator):

    bl_idname = "object.set_transforms"
    bl_label = "Start mocap"

    HEAD_TRACKING_BONE = None
    TRACKING_face = None
    TRACKING_cam = None
    HEAD_TARGET_EMPTY = None
    
    lastFrameQ_w = None
    lastFrameQ_x = None
    lastFrameQ_y = None
    lastFrameQ_z = None
    difference_x = None
    difference_y = None
    difference_z = None
    camLastpos_x = None
    camLastpos_y = None
    camLastpos_z = None
    lastHeadPos_x = None
    lastHeadPos_y = None
    lastHeadPos_z = None

    cam_og_loc_x = None
    cam_og_loc_y = None
    cam_og_loc_z = None
    empty_og_loc_x = None
    empty_og_loc_y = None
    empty_og_loc_z = None
    cam_og_rot_w = None
    cam_og_rot_x = None
    cam_og_rot_y = None
    cam_og_rot_z = None
    empty_og_rot_w = None
    empty_og_rot_x = None
    empty_og_rot_y = None
    empty_og_rot_z = None

    cam_correction_x = None
    cam_correction_y = None
    cam_correction_z = None


    REC = False
    useArma = False
    
    cFirstFrame = True
    firstFrameQ = True 
    headFirstFrame = False


    def save_initial_values():

        if(FT_OT_Transforms.HEAD_TRACKING_BONE is not None):

            FT_OT_Transforms.empty_og_rot_w = FT_OT_Transforms.HEAD_TRACKING_BONE.rotation_quaternion[0]
            FT_OT_Transforms.empty_og_rot_x = FT_OT_Transforms.HEAD_TRACKING_BONE.rotation_quaternion[1]
            FT_OT_Transforms.empty_og_rot_y = FT_OT_Transforms.HEAD_TRACKING_BONE.rotation_quaternion[2]
            FT_OT_Transforms.empty_og_rot_z = FT_OT_Transforms.HEAD_TRACKING_BONE.rotation_quaternion[3]
            FT_OT_Transforms.empty_og_loc_x = FT_OT_Transforms.HEAD_TRACKING_BONE.location.x
            FT_OT_Transforms.empty_og_loc_y = FT_OT_Transforms.HEAD_TRACKING_BONE.location.y
            FT_OT_Transforms.empty_og_loc_z = FT_OT_Transforms.HEAD_TRACKING_BONE.location.z

        if(FT_OT_Transforms.TRACKING_cam is not None):

            FT_OT_Transforms.cam_og_rot_w = FT_OT_Transforms.TRACKING_cam.rotation_quaternion[0]
            FT_OT_Transforms.cam_og_rot_x = FT_OT_Transforms.TRACKING_cam.rotation_quaternion[1]
            FT_OT_Transforms.cam_og_rot_y = FT_OT_Transforms.TRACKING_cam.rotation_quaternion[2]
            FT_OT_Transforms.cam_og_rot_z = FT_OT_Transforms.TRACKING_cam.rotation_quaternion[3]
            FT_OT_Transforms.cam_og_loc_x = FT_OT_Transforms.TRACKING_cam.location.x
            FT_OT_Transforms.cam_og_loc_y = FT_OT_Transforms.TRACKING_cam.location.y
            FT_OT_Transforms.cam_og_loc_z = FT_OT_Transforms.TRACKING_cam.location.z


    def head_rotation_q(w,x,z,y):

        if(FT_OT_Transforms.HEAD_TRACKING_BONE is None):
            ao = FT_OT_Transforms.TRACKING_face
        if(FT_OT_Transforms.HEAD_TRACKING_BONE is not None):
            ao = FT_OT_Transforms.HEAD_TRACKING_BONE

        ao.rotation_mode = 'QUATERNION'
        
        if FT_OT_Transforms.firstFrameQ:

            FT_OT_Transforms.lastFrameQ_w = ao.rotation_quaternion[0] #w
            FT_OT_Transforms.lastFrameQ_x = ao.rotation_quaternion[1] #x
            FT_OT_Transforms.lastFrameQ_y = ao.rotation_quaternion[3] #y
            FT_OT_Transforms.lastFrameQ_z = ao.rotation_quaternion[2] #z

            FT_OT_Transforms.firstFrameQ = False

        #### TEST
        ao.rotation_quaternion[0] = w  
        ao.rotation_quaternion[1] = x  
        ao.rotation_quaternion[2] = -z  
        ao.rotation_quaternion[3] = y

        if FT_OT_Transforms.REC:
            FT_OT_Transforms.TRACKING_face.keyframe_insert(data_path="rotation_quaternion")
        rotQ = True

    def moveCamera(cw,cx,cy,cz, tx,tz,ty):

            if(FT_OT_Transforms.HEAD_TRACKING_BONE is not None):
                ao = FT_OT_Transforms.HEAD_TRACKING_BONE
                parent = ao.parent
            else:
                return

            if FT_OT_Transforms.cFirstFrame:
                

                cam = FT_OT_Transforms.TRACKING_cam
                
                #cam.location = ao.location
                FT_OT_Transforms.TRACKING_cam.location.x = (FT_OT_Transforms.empty_og_loc_x + -FT_OT_Transforms.cam_correction_x + tx) 
                FT_OT_Transforms.TRACKING_cam.location.y = (FT_OT_Transforms.empty_og_loc_y + -FT_OT_Transforms.cam_correction_y + ty)
                FT_OT_Transforms.TRACKING_cam.location.z = (FT_OT_Transforms.empty_og_loc_z + -FT_OT_Transforms.cam_correction_z + tz)

                FT_OT_Transforms.camLastpos_x = tx 
                FT_OT_Transforms.camLastpos_y = ty
                FT_OT_Transforms.camLastpos_z = tz
                #return

                FT_OT_Transforms.cFirstFrame = False

            FT_OT_Transforms.TRACKING_cam.location.x -= (FT_OT_Transforms.camLastpos_x - tx) 
            FT_OT_Transforms.TRACKING_cam.location.y -= (FT_OT_Transforms.camLastpos_y - ty)
            FT_OT_Transforms.TRACKING_cam.location.z -= (FT_OT_Transforms.camLastpos_z - tz)

            FT_OT_Transforms.camLastpos_x = tx 
            FT_OT_Transforms.camLastpos_y = ty  
            FT_OT_Transforms.camLastpos_z = tz 

            FT_OT_Transforms.TRACKING_cam.rotation_quaternion[0] = cw
            FT_OT_Transforms.TRACKING_cam.rotation_quaternion[1] = -cx
            FT_OT_Transforms.TRACKING_cam.rotation_quaternion[2] = -cy
            FT_OT_Transforms.TRACKING_cam.rotation_quaternion[3] = cz

    def moveHead(x,z,y):

        if(FT_OT_Transforms.HEAD_TRACKING_BONE is None):
            ao = FT_OT_Transforms.TRACKING_face

            ao.location.x = x
            ao.location.y = y
            ao.location.z = z
            return

        if(FT_OT_Transforms.HEAD_TRACKING_BONE is not None):
            ao = FT_OT_Transforms.HEAD_TRACKING_BONE

        if FT_OT_Transforms.headFirstFrame:

            FT_OT_Transforms.cam_correction_x = x
            FT_OT_Transforms.cam_correction_y = y
            FT_OT_Transforms.cam_correction_z = z

            FT_OT_Transforms.lastHeadPos_x = x 
            FT_OT_Transforms.lastHeadPos_y = y
            FT_OT_Transforms.lastHeadPos_z = z
            #return

            FT_OT_Transforms.headFirstFrame = False

        ao.location.x -= (FT_OT_Transforms.lastHeadPos_x - x) 
        ao.location.y -= (FT_OT_Transforms.lastHeadPos_y - y)
        ao.location.z -= (FT_OT_Transforms.lastHeadPos_z - z)

        FT_OT_Transforms.lastHeadPos_x = x 
        FT_OT_Transforms.lastHeadPos_y = y  
        FT_OT_Transforms.lastHeadPos_z = z 

        if FT_OT_Transforms.REC:
            FT_OT_Transforms.TRACKING_face.keyframe_insert(data_path="location")
        return
    test = False

    def process_command(arr):
        #print(FT_OT_Transforms.TRACKING_face)
        i = 0
        if FT_OT_Transforms.rotQ:
            #print("going to rotQ")
            FT_OT_Transforms.head_rotation_q(arr[0], arr[1], arr[2], arr[3])
            i = 3
            #print("out of rotQ")
            for y in FT_OT_Transforms.TRACKING_face.data.shape_keys.key_blocks:
                if(i < (52 + 4) and not 3):
                    y.value = arr[i]
                    #print(arr[i])
                    if FT_PT_Panel.REC_shapes == True:
                        y.keyframe_insert("value", frame=bpy.data.scenes[0].frame_current)
                    i += 1
                if(i == 3):
                    y.value = 0
                    i += 1

    def process_bs(values):
        ## ADD BLENDSHAPE RECORDING
        for i, shape in enumerate(FT_OT_Transforms.TRACKING_face.data.shape_keys.key_blocks):
            if(i != 0):
                shape.value = values[i]
                if FT_OT_Transforms.REC: #bpy.data.scenes[0].REC_shapes == True:
                    shape.keyframe_insert("value", frame=bpy.data.scenes[0].frame_current)
            if(i == 0):
                i = 1


    def reset_blendShapes(cam, bone, face):

        if(face is not None):
            ao = face

            for shape in ao.data.shape_keys.key_blocks:
                shape.value = 0
            for index, shape in enumerate(ao.data.shape_keys.key_blocks):
                print(index, shape)
        if(bone is not None):
            bone.location.x = FT_OT_Transforms.empty_og_loc_x
            bone.location.y = FT_OT_Transforms.empty_og_loc_y
            bone.location.z = FT_OT_Transforms.empty_og_loc_z

            bone.rotation_quaternion[0]= FT_OT_Transforms.empty_og_rot_w
            bone.rotation_quaternion[1]= FT_OT_Transforms.empty_og_rot_x
            bone.rotation_quaternion[2]= FT_OT_Transforms.empty_og_rot_y
            bone.rotation_quaternion[3]= FT_OT_Transforms.empty_og_rot_z


        if(cam is not None):

            cam.location.x = FT_OT_Transforms.cam_og_loc_x
            cam.location.y = FT_OT_Transforms.cam_og_loc_y
            cam.location.z = FT_OT_Transforms.cam_og_loc_z

            cam.rotation_quaternion[0]= FT_OT_Transforms.cam_og_rot_w
            cam.rotation_quaternion[1]= FT_OT_Transforms.cam_og_rot_x
            cam.rotation_quaternion[2]= FT_OT_Transforms.cam_og_rot_y
            cam.rotation_quaternion[3]= FT_OT_Transforms.cam_og_rot_z