from asyncio import start_server
from multiprocessing import context
import bpy
from bpy.types import Operator
import socket
import time
import threading
import array
from math import radians
from bpy.props import *
import select
from . ft_panel import FT_PT_Panel
from . ft_transforms import FT_OT_Transforms
from array import *
import queue
from bpy.app.handlers import persistent

import ft_panel
#import ft_transforms

class FT_OT_Start_Server(Operator):

    bl_idname = "object.start_server"
    bl_label = "Start server"
    bl_description = "Start the facetracking server"
    isRunning = False
    
    @classmethod
    def poll(cls, context):
        ao = context.object

        if ao is not None:
            if ao.mode == "OBJECT":
                return True
        return False

    def orig_rot(o):
        origrot = o.rotation_euler #{ao.rotation_euler[0],ao.rotation_euler[1],ao.rotation_euler[2]}
        print(origrot)
        return origrot

    firstFrame = True
    firstFrameQ = True
    #lastFrame = array('f',[0,0,0])
    #lastFrameQ = array('f',[0,0,0,0])
    #lastXYZ = array('f',[0,0,0])
    lastHeadPos_x = None
    lastHeadPos_y = None
    lastHeadPos_z = None
    lastFrameQ_w = None
    lastFrameQ_x = None
    lastFrameQ_y = None
    lastFrameQ_z = None

    HEAD_TARGET_EMPTY = None

    def MakeRigTargets():

        if FT_OT_Start_Server.HEAD_TARGET_EMPTY is None:

            if FT_OT_Start_Server.Rig_Armature is not None:
                ob = FT_OT_Start_Server.Rig_Armature
            else:
                FT_OT_Transforms.useArma = False
                return

            if ob.type == 'ARMATURE':
                #armature = ob.data

                for bone in ob.pose.bones:
                    
                    print(bone.name)

                    if(bone.name == "HEAD"):

                        ## DO EMPTY FOR TARGET
                            #o = bpy.data.objects.new( "empty", None )
                        # due to the new mechanism of "collection"
                            #bpy.context.scene.collection.objects.link( o )
                        # empty_draw was replaced by empty_display
                            # o.empty_display_size = 1/3
                            # o.empty_display_type = 'PLAIN_AXES'
                            # crc = bone.constraints.new('COPY_ROTATION')
                            # crc_2 = bone.constraints.new('COPY_LOCATION')
                            # #give it a target bone
                            # crc.target = bone
                            # crc_2.target = bone   
                            # print("FOUND HEAD BONE")
                        #o.location = FT_OT_Start_Server.TRACKING_face.location
                        # o.rotation_mode = 'QUATERNION'

                        for obj in bpy.data.objects:
                            if "head_target" in obj.name.lower():
                                 FT_OT_Transforms.HEAD_TARGET_EMPTY = obj
                        # o.rotation_quaternion = FT_OT_Start_Server.TRACKING_face.rotation_quaternion
                        #FT_OT_Start_Server.HEAD_TARGET_EMPTY = bone                     
                        # note subtarget uses name not object.
                        FT_OT_Transforms.HEAD_TRACKING_BONE = bone
                        #crc.subtarget = bone2.name

                        break

            print("Printed BONES!")


    def head_rotation_q(w,x,z,y):

        if(FT_OT_Start_Server.HEAD_TRACKING_BONE is None):
            return
        ao = FT_OT_Start_Server.HEAD_TRACKING_BONE
        #ao = FT_OT_Start_Server.TRACKING_face
        #ao = FT_OT_Start_Server.HEAD_TARGET_EMPTY
        ao.rotation_mode = 'QUATERNION'
        
        if FT_OT_Start_Server.firstFrameQ:
            FT_OT_Start_Server.lastFrameQ_w =        ao.rotation_quaternion[0] #w
            FT_OT_Start_Server.lastFrameQ_x =        ao.rotation_quaternion[1] #x
            FT_OT_Start_Server.lastFrameQ_y =        ao.rotation_quaternion[3] #y
            FT_OT_Start_Server.lastFrameQ_z =        ao.rotation_quaternion[2] #z

            FT_OT_Start_Server.useArma = True

            FT_OT_Start_Server.firstFrameQ = False

        # ao.rotation_quaternion[0] *= FT_OT_Start_Server.lastFrameQ_w#* w  
        # ao.rotation_quaternion[1] *= FT_OT_Start_Server.lastFrameQ_x#* x  
        # ao.rotation_quaternion[2] *= FT_OT_Start_Server.lastFrameQ_z#* z  
        # ao.rotation_quaternion[3] *= FT_OT_Start_Server.lastFrameQ_y#* y

#### TEST
        ao.rotation_quaternion[0] = w  
        ao.rotation_quaternion[1] = -x  
        ao.rotation_quaternion[2] = -y  
        ao.rotation_quaternion[3] = -z


        # FT_OT_Start_Server.lastFrameQ_w = w
        # FT_OT_Start_Server.lastFrameQ_x = x
        # FT_OT_Start_Server.lastFrameQ_y = y
        # FT_OT_Start_Server.lastFrameQ_z = z

        if FT_OT_Start_Server.REC:
            FT_OT_Start_Server.TRACKING_face.keyframe_insert(data_path="rotation_quaternion")
        rotQ = True

    #camTransform = array('f',[0,0,0])
    #lastFrame_cam = array('f',[0,0,0,0])
    REC = False
    cFirstFrame = True
    #camparent = None
    #isEnding = False
    #camposparent = None
    camLastpos_x = None
    camLastpos_y = None
    camLastpos_z = None
 
    useArma = False
#    camEmpty = None
    difference_x = None
    difference_y = None
    difference_z = None

    def moveCamera(cw,cx,cy,cz, tx,tz,ty):

        if FT_OT_Start_Server.useArma:

            cam = FT_OT_Start_Server.TRACKING_cam
            FT_OT_Start_Server.TRACKING_cam.rotation_mode = 'QUATERNION'

            if FT_OT_Start_Server.cFirstFrame:

                # FT_OT_Start_Server.camEmpty = bpy.data.objects.new("empty", None)
                # bpy.context.scene.collection.objects.link(FT_OT_Start_Server.camEmpty)
                # FT_OT_Start_Server.camEmpty.empty_display_size = 1/3
                # FT_OT_Start_Server.camEmpty.empty_display_type = 'PLAIN_AXES'

                FT_OT_Start_Server.difference_x = tx + FT_OT_Start_Server.TRACKING_face.location.x
                FT_OT_Start_Server.difference_y = ty + FT_OT_Start_Server.TRACKING_face.location.y
                FT_OT_Start_Server.difference_z = tz + FT_OT_Start_Server.TRACKING_face.location.z

                FT_OT_Start_Server.camLastpos_x = FT_OT_Start_Server.difference_x 
                FT_OT_Start_Server.camLastpos_y = FT_OT_Start_Server.difference_y
                FT_OT_Start_Server.camLastpos_z = FT_OT_Start_Server.difference_z

                FT_OT_Start_Server.TRACKING_cam.location.x = FT_OT_Start_Server.difference_x 
                FT_OT_Start_Server.TRACKING_cam.location.y = FT_OT_Start_Server.difference_y
                FT_OT_Start_Server.TRACKING_cam.location.z = FT_OT_Start_Server.difference_z

                FT_OT_Start_Server.cFirstFrame = False


            ### CAM COR POS
            # FT_OT_Start_Server.difference_x = tx + FT_OT_Start_Server.TRACKING_face.location.x
            # FT_OT_Start_Server.difference_y = ty + FT_OT_Start_Server.TRACKING_face.location.y
            # FT_OT_Start_Server.difference_z = tz + FT_OT_Start_Server.TRACKING_face.location.z
            FT_OT_Start_Server.difference_x = tx + FT_OT_Start_Server.TRACKING_face.location.x
            FT_OT_Start_Server.difference_y = ty + FT_OT_Start_Server.TRACKING_face.location.y
            FT_OT_Start_Server.difference_z = tz + FT_OT_Start_Server.TRACKING_face.location.z

            FT_OT_Start_Server.TRACKING_cam.location.x = FT_OT_Start_Server.difference_x 
            FT_OT_Start_Server.TRACKING_cam.location.y = FT_OT_Start_Server.difference_y
            FT_OT_Start_Server.TRACKING_cam.location.z = FT_OT_Start_Server.difference_z

            # FT_OT_Start_Server.TRACKING_cam.location.x = (FT_OT_Start_Server.camLastpos_x - FT_OT_Start_Server.difference_x)
            # FT_OT_Start_Server.TRACKING_cam.location.y = (FT_OT_Start_Server.camLastpos_y - FT_OT_Start_Server.difference_y)
            # FT_OT_Start_Server.TRACKING_cam.location.z = (FT_OT_Start_Server.camLastpos_z - FT_OT_Start_Server.difference_z)

            # FT_OT_Start_Server.camLastpos_x = FT_OT_Start_Server.difference_x 
            # FT_OT_Start_Server.camLastpos_y = FT_OT_Start_Server.difference_y
            # FT_OT_Start_Server.camLastpos_z = FT_OT_Start_Server.difference_z

            ### CAM ROT
            FT_OT_Start_Server.TRACKING_cam.rotation_quaternion[0] = cw
            FT_OT_Start_Server.TRACKING_cam.rotation_quaternion[1] = -cx
            FT_OT_Start_Server.TRACKING_cam.rotation_quaternion[2] = -cy
            FT_OT_Start_Server.TRACKING_cam.rotation_quaternion[3] = cz

            return
        
        else:
            return

        tx = FT_OT_Start_Server.TRACKING_face.location.x + tx
        ty = FT_OT_Start_Server.TRACKING_face.location.y + ty
        tz = FT_OT_Start_Server.TRACKING_face.location.z + tz

        cam = FT_OT_Start_Server.TRACKING_cam
        FT_OT_Start_Server.TRACKING_cam.rotation_mode = 'QUATERNION'
        if FT_OT_Start_Server.cFirstFrame:

            FT_OT_Start_Server.camLastpos_x = tx
            FT_OT_Start_Server.camLastpos_y = ty
            FT_OT_Start_Server.camLastpos_z = tz
            FT_OT_Start_Server.cFirstFrame = False

        if FT_OT_Start_Server.isEnding == False: 

           # if FT_OT_Start_Server.orbiting == False:
                #cam.parent = None

            if FT_OT_Start_Server.camLastpos_z is not None:
                FT_OT_Start_Server.TRACKING_cam.location.x = -FT_OT_Start_Server.camLastpos_x + tx
                FT_OT_Start_Server.TRACKING_cam.location.y = -FT_OT_Start_Server.camLastpos_y + ty
                FT_OT_Start_Server.TRACKING_cam.location.z = -FT_OT_Start_Server.camLastpos_z + tz
            else:
                FT_OT_Start_Server.TRACKING_cam.location.x = tx
                FT_OT_Start_Server.TRACKING_cam.location.y = ty
                FT_OT_Start_Server.TRACKING_cam.location.z = tz

            FT_OT_Start_Server.TRACKING_cam.rotation_quaternion[0] = cw
            FT_OT_Start_Server.TRACKING_cam.rotation_quaternion[1] = -cx
            FT_OT_Start_Server.TRACKING_cam.rotation_quaternion[2] = -cy
            FT_OT_Start_Server.TRACKING_cam.rotation_quaternion[3] = cz

    def removeTemps():
        
        #objs = bpy.data.objects
        #bpy.data.scenes[0].TRACKING_cam.parent = None
        FT_OT_Start_Server.isEnding = True
        #objs.remove(objs["camEmpty"], do_unlink=True)
        #objs.remove(objs["HEAD_Empty"], do_unlink=True)
        #FT_OT_Start_Server.cFirstFrame = True
        #lastHeadPos = array('f',[0,0,0])

    headFirstFrame = True
    def look_at(obj_camera, point):
        loc_camera = obj_camera.matrix_world.to_translation()
        _point = point.matrix_world.to_translation()
        direction = _point - loc_camera
        # point the cameras '-Z' and use its 'Y' as up
        rot_quat = direction.to_track_quat('-Z', 'Y')

        # assume we're using euler rotation
        obj_camera.rotation_euler = rot_quat.to_euler()

    headParent = None

    firstHeadPos_x = None
    firstHeadPos_y = None
    firstHeadPos_z = None

    def moveHead(x,z,y):

        if(FT_OT_Start_Server.HEAD_TRACKING_BONE is None):
            return
        #ao = FT_OT_Start_Server.HEAD_TARGET_EMPTY
        ao = FT_OT_Start_Server.HEAD_TRACKING_BONE


        if FT_OT_Start_Server.headFirstFrame:
            
            FT_OT_Start_Server.lastHeadPos_x = x 
            FT_OT_Start_Server.lastHeadPos_y = y
            FT_OT_Start_Server.lastHeadPos_z = z
            #return

            FT_OT_Start_Server.headFirstFrame = False
        #ao.location.x += FT_OT_Start_Server-

        ao.location.x -= (FT_OT_Start_Server.lastHeadPos_x - x)
        ao.location.y -= (FT_OT_Start_Server.lastHeadPos_y - y)
        ao.location.z -= (FT_OT_Start_Server.lastHeadPos_z - z)

        FT_OT_Start_Server.lastHeadPos_x = x 
        FT_OT_Start_Server.lastHeadPos_y = y 
        FT_OT_Start_Server.lastHeadPos_z = z 

        if FT_OT_Start_Server.REC:
            FT_OT_Start_Server.TRACKING_face.keyframe_insert(data_path="location")
        return
    test = False

    def process_command(arr):
        #print(FT_OT_Start_Server.TRACKING_face)
        i = 0
        if FT_OT_Start_Server.rotQ:
            #print("going to rotQ")
            FT_OT_Start_Server.head_rotation_q(arr[0], arr[1], arr[2], arr[3])
            i = 3
            #print("out of rotQ")
            for y in FT_OT_Start_Server.TRACKING_face.data.shape_keys.key_blocks:
                if(i < (52 + 4) and not 3):
                    y.value = arr[i]
                    #print(arr[i])
                    if FT_PT_Panel.REC_shapes == True:
                        y.keyframe_insert("value", frame=bpy.data.scenes[0].frame_current)
                    i += 1
                if(i == 3):
                    y.value = 0
                    i += 1

    def process_bs(values):
        ## ADD BLENDSHAPE RECORDING
        for i, shape in enumerate(FT_OT_Start_Server.TRACKING_face.data.shape_keys.key_blocks):
            if(i != 0):
                shape.value = values[i]
                if FT_OT_Start_Server.REC: #bpy.data.scenes[0].REC_shapes == True:
                    shape.keyframe_insert("value", frame=bpy.data.scenes[0].frame_current)
            if(i == 0):
                i = 1
                  
    ao_origrot_0 = 1
    ao_origrot_1 = 0
    ao_origrot_2 = 0
    ao_origrot_3 = 0


    cam_origrot_0 = 1
    cam_origrot_1 = 0
    cam_origrot_2 = 0
    cam_origrot_3 = 0

    def reset_blendShapes():
        if(FT_OT_Start_Server.TRACKING_face is not None):
            ao = FT_OT_Start_Server.TRACKING_face #bpy.context.view_layer.objects.active
            ao.rotation_mode = 'QUATERNION'
            #ao.rotation_quaternion[0] = 1 
            #ao.rotation_quaternion[1] = 0
            #ao.rotation_quaternion[2] = 0 
            #ao.rotation_quaternion[3] = 0

            #save orig rotations

            FT_OT_Start_Server.ao_origrot_0 = ao.rotation_quaternion[0] 
            FT_OT_Start_Server.ao_origrot_1 = ao.rotation_quaternion[1]
            FT_OT_Start_Server.ao_origrot_2 = ao.rotation_quaternion[2] 
            FT_OT_Start_Server.ao_origrot_3 = ao.rotation_quaternion[3]

            #ao.location.x = 0
            #ao.location.y = 0
            #ao.location.z = 0
        if(FT_OT_Start_Server.TRACKING_cam is not None):
            cam = FT_OT_Start_Server.TRACKING_cam
            cam.rotation_mode = 'QUATERNION'
            FT_OT_Start_Server.cam_origrot_0 =  cam.rotation_quaternion[0]
            FT_OT_Start_Server.cam_origrot_1 =  cam.rotation_quaternion[1]
            FT_OT_Start_Server.cam_origrot_2 =  cam.rotation_quaternion[2]
            FT_OT_Start_Server.cam_origrot_3 =  cam.rotation_quaternion[3]
            cam.rotation_quaternion[0] = FT_OT_Start_Server.cam_origrot_0
            cam.rotation_quaternion[1] = FT_OT_Start_Server.cam_origrot_1
            cam.rotation_quaternion[2] = FT_OT_Start_Server.cam_origrot_2
            cam.rotation_quaternion[3] = FT_OT_Start_Server.cam_origrot_3

            ## see if needs fix
            cam.location.x = 0
            cam.location.y = 0
            cam.location.z = 0

        for shape in ao.data.shape_keys.key_blocks:
            shape.value = 0
            #print(shape.name)
            #print(len(ao.data.shape_keys.key_blocks))
        for index, shape in enumerate(ao.data.shape_keys.key_blocks):
            print(index, shape)

    HOST = ""#FT_PT_Panel.scene.IP_property
    PORT =  8080#FT_PT_Panel.scene.PORT_property
    s = socket
    t = threading.Thread
    timeOutCount = 0
    ready = {1}
    _ready = {1}
    timeOutSeconds = 2
    TRACKING_face = None
    orbiting = False
    TRACKING_cam = None

    arr = array('f')
    
    dick = 9000
    datapacket = None
    justStarted = True


    def server_infinite():

        if FT_OT_Start_Server.justStarted:

            FT_OT_Start_Server.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            FT_OT_Start_Server.s.setblocking(False)
            FT_OT_Start_Server.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            FT_OT_Start_Server.s.bind((FT_OT_Start_Server.HOST,FT_OT_Start_Server.PORT))
            FT_OT_Start_Server.justStarted = False


        FT_OT_Start_Server.ready = select.select([FT_OT_Start_Server.s], [], [], FT_OT_Start_Server.timeOutSeconds)
        
        if FT_OT_Start_Server.ready[0]:
            FT_OT_Start_Server.waitingForConnection = False
            while True:
                try:
                    FT_OT_Start_Server.datapacket = FT_OT_Start_Server.s.recv(264)
                    #FT_OT_Start_Server.dick += 1
                    #print("empyuig", FT_OT_Start_Server.dick)
                except:
                    break

            FT_PT_Panel.enableRec = True
            data = FT_OT_Start_Server.datapacket

            FT_OT_Start_Server.timeOutSeconds = 1

            arr = array('f')
            FT_OT_Start_Server.arr = arr
            FT_OT_Start_Server.arr.frombytes(data)

            if(len( FT_OT_Start_Server.arr) == 66):
                if FT_OT_Start_Server.context.scene.track_face_rot:
                    FT_OT_Transforms.head_rotation_q( FT_OT_Start_Server.arr[0],  FT_OT_Start_Server.arr[1],  FT_OT_Start_Server.arr[2],  FT_OT_Start_Server.arr[3])
                if FT_OT_Start_Server.context.scene.track_face_pos:
                    FT_OT_Transforms.moveHead( FT_OT_Start_Server.arr[4],  FT_OT_Start_Server.arr[5],  FT_OT_Start_Server.arr[6])
                if FT_OT_Start_Server.context.scene.track_cam:
                    FT_OT_Transforms.moveCamera( FT_OT_Start_Server.arr[7],  FT_OT_Start_Server.arr[8],  FT_OT_Start_Server.arr[9],  FT_OT_Start_Server.arr[10],  FT_OT_Start_Server.arr[11],  FT_OT_Start_Server.arr[12],  FT_OT_Start_Server.arr[13])
                FT_OT_Transforms.process_bs(FT_OT_Start_Server.arr[13:])

            FT_OT_Start_Server.shit = True
            return {'FINISHED'}
            #print("server stopped, socket closed")
            # FT_PT_Panel.enableStart = True
            # FT_PT_Panel.enableStop = False
            # FT_PT_Panel.enableRec = False

        else:

            FT_OT_Start_Server.timeOutCount += 1
            if FT_OT_Start_Server.timeOutCount <= 29:

                FT_OT_Start_Server.timeOutStop()

        
    def sendClosingBytes():

        y = 'STOP'
        bytes = y.encode()
        print("mesg len in bytes : ", len(bytes))
        exsHOST = "127.0.0.1"
        exs = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        exs.setblocking(0)
        exs.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        exs.bind((exsHOST,FT_OT_Start_Server.PORT))
        exs.sendto(bytes, (FT_OT_Start_Server.HOST,FT_OT_Start_Server.PORT))
        print("sent closing bytes")
        exs.close()
        return {'FINISHED'}        

    TRACKING_ROT = None
    context = None
    
    execution_queue = queue.Queue()

    # This function can safely be called in another thread.
    # The function will be executed when the timer runs the next time.

    justStarted = False

    def run_in_main_thread(function):
        FT_OT_Start_Server.execution_queue.put(function)


    def execute_queued_functions(interval):
        while not FT_OT_Start_Server.execution_queue.empty():
            #function = FT_OT_Start_Server.execution_queue.get()
            FT_OT_Start_Server.execution_queue.get()
            #function()
        return interval

    def timeOutStop():

        ### SHOW START BUTTON
        print("timeout cancel activated")
        FT_OT_Start_Server.justStarted = False
        bpy.ops.screen.animation_cancel(False)
        FT_PT_Panel.enableStart = True
        FT_OT_Start_Server.waitingForConnection = True

        FT_OT_Start_Server.REC = False
        FT_PT_Panel.enableStart = True
        #FT_OT_Start_Server.sendClosingBytes()
        FT_OT_Start_Server.removeTemps()
        #FT_OT_Start_Server.cFirstFrame = True
        FT_OT_Start_Server.shit = False
        return {'FINISHED'}

    def execute(self, context):
        
       # FT_OT_Start_Server.reset_blendShapes()
        FT_OT_Start_Server.timeOutCount = 0
        FT_OT_Start_Server.waitingForConnection = True
        FT_OT_Start_Server.context = context
        FT_OT_Start_Server.HOST = context.scene.IP_property
        FT_OT_Start_Server.PORT = context.scene.PORT_property
        FT_OT_Start_Server.timeOutCount = 0
        ## set bools
        FT_OT_Start_Server.Rig_Armature = context.scene.Rig_Armature
        FT_OT_Start_Server.MakeRigTargets()
        FT_OT_Start_Server.timeOutSeconds = 1
        FT_OT_Transforms.firstFrameQ = True
        FT_OT_Transforms.headFirstFrame = True
        FT_OT_Start_Server.stop_threads = True
        FT_OT_Start_Server.isEnding = False
        FT_OT_Transforms.cFirstFrame = True
        FT_OT_Transforms.REC = False
        ### --- Update tracking HEAD object
        bpy.ops.screen.animation_play()
        FT_OT_Start_Server.TRACKING_face = context.scene.TRACKING_face
        FT_OT_Start_Server.TRACKING_cam = context.scene.TRACKING_cam
        FT_OT_Transforms.TRACKING_face = context.scene.TRACKING_face
        FT_OT_Transforms.TRACKING_cam = context.scene.TRACKING_cam
         #FT_OT_Start_Server.TRACKING_head = context.scene.TRACKING_head
        FT_OT_Transforms.reset_blendShapes()
        FT_PT_Panel.enableStart = False
        FT_PT_Panel.enableStop = True
        FT_OT_Start_Server.shit = True
        FT_OT_Start_Server.justStarted = True
        #this_class = FT_OT_Start_Server
        return {'FINISHED'} 

    shit = False
    waitingForConnection = False
    Rig_Armature = None

    HEAD_TRACKING_BONE = None



class FT_OT_Stop_Server(Operator):

    bl_idname = "object.stop_server"
    bl_label = "Stop server"
    bl_description = "Stop the facetracking server"

    def execute(self, context):
        
        ### SHOW START BUTTON
        FT_OT_Start_Server.justStarted = False
        FT_OT_Start_Server.REC = False
        # FT_PT_Panel.enableStart = True
        # FT_OT_Start_Server.sendClosingBytes()
        # FT_OT_Start_Server.removeTemps()
        bpy.ops.screen.animation_cancel(False)
        FT_OT_Start_Server.shit = False

        # bpy.ops.screen.animation_cancel(False)
        # FT_OT_Start_Server.waitingForConnection = True
        FT_OT_Start_Server.timeOutStop()
        return {'FINISHED'}

@persistent
def FT_RUN_Server_Cycle(dummy1,dummy2):
    #def RunCycle():
    #print("run cycle pre")
    if(FT_OT_Start_Server.shit == True):
        FT_OT_Start_Server.server_infinite()
        
        #print("run cycle post")
    return {'FINISHED'}

bpy.app.handlers.frame_change_post.append(FT_RUN_Server_Cycle)

class FT_OT_Start_Recording(Operator):

    bl_idname = "object.start_rec"
    bl_label = "Start REC"
    bl_description = "Start recording keyframes"

    def execute(self, context):
                                                    
        print("rec")
        FT_OT_Transforms.REC = True
        FT_PT_Panel.REC_running = True
        FT_PT_Panel.enableRec = False
        return {'FINISHED'}

class FT_OT_Stop_Recording(Operator):

    bl_idname = "object.stop_rec"
    bl_label = "Stop Rec"
    bl_description = "Stop recording keyframes"

    def execute(self, context):
        
        FT_OT_Transforms.REC = False
        FT_PT_Panel.REC_running = False
        
        #FT_PT_Panel.enableRec = True
        print("rec")
        return {'FINISHED'}  

class FT_OT_ResetCharPos(Operator):

    bl_idname = "object.reset_char"
    bl_label = "Reset Char"
    bl_description = "Reset char if rig"

    def execute(self, context):
        
        ### Here code for char pos reset
        return {'FINISHED'}  