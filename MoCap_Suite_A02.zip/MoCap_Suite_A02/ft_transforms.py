from asyncio import start_server
from multiprocessing import context
import bpy
from bpy.types import Operator
from math import radians
from bpy.props import *
from .ft_panel import FT_PT_Panel
from array import *

class FT_OT_Transforms(Operator):

    bl_idname = "object.set_transforms"
    bl_label = "Start mocap"

    HEAD_TRACKING_BONE = None
    TRACKING_face = None
    TRACKING_cam = None
    HEAD_TARGET_EMPTY = None
    
    lastFrameQ_w = None
    lastFrameQ_x = None
    lastFrameQ_y = None
    lastFrameQ_z = None
    difference_x = None
    difference_y = None
    difference_z = None
    camLastpos_x = None
    camLastpos_y = None
    camLastpos_z = None
    lastHeadPos_x = None
    lastHeadPos_y = None
    lastHeadPos_z = None

    REC = False
    useArma = False
    
    cFirstFrame = True
    firstFrameQ = True 
    headFirstFrame = False

    def head_rotation_q(w,x,z,y):

        if(FT_OT_Transforms.HEAD_TRACKING_BONE is None):
            ao = FT_OT_Transforms.TRACKING_face
        if(FT_OT_Transforms.HEAD_TRACKING_BONE is not None):
            ao = FT_OT_Transforms.HEAD_TRACKING_BONE

        #ao = FT_OT_Transforms.TRACKING_face
        #ao = FT_OT_Transforms.HEAD_TARGET_EMPTY
        ao.rotation_mode = 'QUATERNION'
        
        if FT_OT_Transforms.firstFrameQ:

            FT_OT_Transforms.lastFrameQ_w = ao.rotation_quaternion[0] #w
            FT_OT_Transforms.lastFrameQ_x = ao.rotation_quaternion[1] #x
            FT_OT_Transforms.lastFrameQ_y = ao.rotation_quaternion[3] #y
            FT_OT_Transforms.lastFrameQ_z = ao.rotation_quaternion[2] #z

            #FT_OT_Transforms.useArma = True

            FT_OT_Transforms.firstFrameQ = False

        # ao.rotation_quaternion[0] *= FT_OT_Transforms.lastFrameQ_w#* w  
        # ao.rotation_quaternion[1] *= FT_OT_Transforms.lastFrameQ_x#* x  
        # ao.rotation_quaternion[2] *= FT_OT_Transforms.lastFrameQ_z#* z  
        # ao.rotation_quaternion[3] *= FT_OT_Transforms.lastFrameQ_y#* y

        #### TEST
        ao.rotation_quaternion[0] = w  
        ao.rotation_quaternion[1] = -x  
        ao.rotation_quaternion[2] = -y  
        ao.rotation_quaternion[3] = -z


        # FT_OT_Transforms.lastFrameQ_w = w
        # FT_OT_Transforms.lastFrameQ_x = x
        # FT_OT_Transforms.lastFrameQ_y = y
        # FT_OT_Transforms.lastFrameQ_z = z

        if FT_OT_Transforms.REC:
            FT_OT_Transforms.TRACKING_face.keyframe_insert(data_path="rotation_quaternion")
        rotQ = True

    def moveCamera(cw,cx,cy,cz, tx,tz,ty):

        if FT_OT_Transforms.useArma:

            cam = FT_OT_Transforms.TRACKING_cam
            FT_OT_Transforms.TRACKING_cam.rotation_mode = 'QUATERNION'

            if FT_OT_Transforms.cFirstFrame:

                # FT_OT_Transforms.camEmpty = bpy.data.objects.new("empty", None)
                # bpy.context.scene.collection.objects.link(FT_OT_Transforms.camEmpty)
                # FT_OT_Transforms.camEmpty.empty_display_size = 1/3
                # FT_OT_Transforms.camEmpty.empty_display_type = 'PLAIN_AXES'

                FT_OT_Transforms.difference_x = tx + FT_OT_Transforms.TRACKING_face.location.x
                FT_OT_Transforms.difference_y = ty + FT_OT_Transforms.TRACKING_face.location.y
                FT_OT_Transforms.difference_z = tz + FT_OT_Transforms.TRACKING_face.location.z

                FT_OT_Transforms.camLastpos_x = FT_OT_Transforms.difference_x 
                FT_OT_Transforms.camLastpos_y = FT_OT_Transforms.difference_y
                FT_OT_Transforms.camLastpos_z = FT_OT_Transforms.difference_z

                FT_OT_Transforms.TRACKING_cam.location.x = FT_OT_Transforms.difference_x 
                FT_OT_Transforms.TRACKING_cam.location.y = FT_OT_Transforms.difference_y
                FT_OT_Transforms.TRACKING_cam.location.z = FT_OT_Transforms.difference_z

                FT_OT_Transforms.cFirstFrame = False

            ### CAM COR POS
            # FT_OT_Transforms.difference_x = tx + FT_OT_Transforms.TRACKING_face.location.x
            # FT_OT_Transforms.difference_y = ty + FT_OT_Transforms.TRACKING_face.location.y
            # FT_OT_Transforms.difference_z = tz + FT_OT_Transforms.TRACKING_face.location.z

            FT_OT_Transforms.difference_x = tx + FT_OT_Transforms.TRACKING_face.location.x
            FT_OT_Transforms.difference_y = ty + FT_OT_Transforms.TRACKING_face.location.y
            FT_OT_Transforms.difference_z = tz + FT_OT_Transforms.TRACKING_face.location.z

            FT_OT_Transforms.TRACKING_cam.location.x = FT_OT_Transforms.difference_x 
            FT_OT_Transforms.TRACKING_cam.location.y = FT_OT_Transforms.difference_y
            FT_OT_Transforms.TRACKING_cam.location.z = FT_OT_Transforms.difference_z

            # FT_OT_Transforms.TRACKING_cam.location.x = (FT_OT_Transforms.camLastpos_x - FT_OT_Transforms.difference_x)
            # FT_OT_Transforms.TRACKING_cam.location.y = (FT_OT_Transforms.camLastpos_y - FT_OT_Transforms.difference_y)
            # FT_OT_Transforms.TRACKING_cam.location.z = (FT_OT_Transforms.camLastpos_z - FT_OT_Transforms.difference_z)

            # FT_OT_Transforms.camLastpos_x = FT_OT_Transforms.difference_x 
            # FT_OT_Transforms.camLastpos_y = FT_OT_Transforms.difference_y
            # FT_OT_Transforms.camLastpos_z = FT_OT_Transforms.difference_z

            ### CAM ROT
            FT_OT_Transforms.TRACKING_cam.rotation_quaternion[0] = cw
            FT_OT_Transforms.TRACKING_cam.rotation_quaternion[1] = -cx
            FT_OT_Transforms.TRACKING_cam.rotation_quaternion[2] = -cy
            FT_OT_Transforms.TRACKING_cam.rotation_quaternion[3] = cz

            return
        
        else:

            # tx = FT_OT_Transforms.TRACKING_face.location.x + tx
            # ty = FT_OT_Transforms.TRACKING_face.location.y + ty
            # tz = FT_OT_Transforms.TRACKING_face.location.z + tz

            # cam = FT_OT_Transforms.TRACKING_cam
            # FT_OT_Transforms.TRACKING_cam.rotation_mode = 'QUATERNION'
            # if FT_OT_Transforms.cFirstFrame:

            #     FT_OT_Transforms.camLastpos_x = tx
            #     FT_OT_Transforms.camLastpos_y = ty
            #     FT_OT_Transforms.camLastpos_z = tz
            #     FT_OT_Transforms.cFirstFrame = False

            # if FT_OT_Transforms.isEnding == False: 

            # # if FT_OT_Transforms.orbiting == False:
            #         #cam.parent = None

            #     if FT_OT_Transforms.camLastpos_z is not None:
            #         FT_OT_Transforms.TRACKING_cam.location.x = -FT_OT_Transforms.camLastpos_x + tx
            #         FT_OT_Transforms.TRACKING_cam.location.y = -FT_OT_Transforms.camLastpos_y + ty
            #         FT_OT_Transforms.TRACKING_cam.location.z = -FT_OT_Transforms.camLastpos_z + tz
            #     else:
            #         FT_OT_Transforms.TRACKING_cam.location.x = tx
            #         FT_OT_Transforms.TRACKING_cam.location.y = ty
            #         FT_OT_Transforms.TRACKING_cam.location.z = tz

                FT_OT_Transforms.TRACKING_cam.location.x = tx
                FT_OT_Transforms.TRACKING_cam.location.y = ty
                FT_OT_Transforms.TRACKING_cam.location.z = tz

                FT_OT_Transforms.TRACKING_cam.rotation_quaternion[0] = cw
                FT_OT_Transforms.TRACKING_cam.rotation_quaternion[1] = -cx
                FT_OT_Transforms.TRACKING_cam.rotation_quaternion[2] = -cy
                FT_OT_Transforms.TRACKING_cam.rotation_quaternion[3] = cz

    def moveHead(x,z,y):

        if(FT_OT_Transforms.HEAD_TRACKING_BONE is None):
            ao = FT_OT_Transforms.TRACKING_face

            ao.location.x = x
            ao.location.y = y
            ao.location.z = z
            return

        if(FT_OT_Transforms.HEAD_TRACKING_BONE is not None):
            ao = FT_OT_Transforms.HEAD_TRACKING_BONE
        #ao = FT_OT_Transforms.HEAD_TARGET_EMPTY
        #ao = FT_OT_Transforms.HEAD_TRACKING_BONE


        if FT_OT_Transforms.headFirstFrame:
            
            FT_OT_Transforms.lastHeadPos_x = x 
            FT_OT_Transforms.lastHeadPos_y = y
            FT_OT_Transforms.lastHeadPos_z = z
            #return

            FT_OT_Transforms.headFirstFrame = False
        #ao.location.x += FT_OT_Transforms-

        ao.location.x -= (FT_OT_Transforms.lastHeadPos_x - x) 
        ao.location.y -= (FT_OT_Transforms.lastHeadPos_y - y)
        ao.location.z -= (FT_OT_Transforms.lastHeadPos_z - z)

        FT_OT_Transforms.lastHeadPos_x = x 
        FT_OT_Transforms.lastHeadPos_y = y  
        FT_OT_Transforms.lastHeadPos_z = z 

        if FT_OT_Transforms.REC:
            FT_OT_Transforms.TRACKING_face.keyframe_insert(data_path="location")
        return
    test = False

    def process_command(arr):
        #print(FT_OT_Transforms.TRACKING_face)
        i = 0
        if FT_OT_Transforms.rotQ:
            #print("going to rotQ")
            FT_OT_Transforms.head_rotation_q(arr[0], arr[1], arr[2], arr[3])
            i = 3
            #print("out of rotQ")
            for y in FT_OT_Transforms.TRACKING_face.data.shape_keys.key_blocks:
                if(i < (52 + 4) and not 3):
                    y.value = arr[i]
                    #print(arr[i])
                    if FT_PT_Panel.REC_shapes == True:
                        y.keyframe_insert("value", frame=bpy.data.scenes[0].frame_current)
                    i += 1
                if(i == 3):
                    y.value = 0
                    i += 1

    def process_bs(values):
        ## ADD BLENDSHAPE RECORDING
        for i, shape in enumerate(FT_OT_Transforms.TRACKING_face.data.shape_keys.key_blocks):
            if(i != 0):
                shape.value = values[i]
                if FT_OT_Transforms.REC: #bpy.data.scenes[0].REC_shapes == True:
                    shape.keyframe_insert("value", frame=bpy.data.scenes[0].frame_current)
            if(i == 0):
                i = 1

    def reset_blendShapes():
        if(FT_OT_Transforms.TRACKING_face is not None):
            ao = FT_OT_Transforms.TRACKING_face #bpy.context.view_layer.objects.active
            ao.rotation_mode = 'QUATERNION'
            #ao.rotation_quaternion[0] = 1 
            #ao.rotation_quaternion[1] = 0
            #ao.rotation_quaternion[2] = 0 
            #ao.rotation_quaternion[3] = 0

            #save orig rotations

            FT_OT_Transforms.ao_origrot_0 = ao.rotation_quaternion[0] 
            FT_OT_Transforms.ao_origrot_1 = ao.rotation_quaternion[1]
            FT_OT_Transforms.ao_origrot_2 = ao.rotation_quaternion[2] 
            FT_OT_Transforms.ao_origrot_3 = ao.rotation_quaternion[3]

            #ao.location.x = 0
            #ao.location.y = 0
            #ao.location.z = 0
        if(FT_OT_Transforms.TRACKING_cam is not None):
            cam = FT_OT_Transforms.TRACKING_cam
            cam.rotation_mode = 'QUATERNION'
            FT_OT_Transforms.cam_origrot_0 =  cam.rotation_quaternion[0]
            FT_OT_Transforms.cam_origrot_1 =  cam.rotation_quaternion[1]
            FT_OT_Transforms.cam_origrot_2 =  cam.rotation_quaternion[2]
            FT_OT_Transforms.cam_origrot_3 =  cam.rotation_quaternion[3]
            cam.rotation_quaternion[0] = FT_OT_Transforms.cam_origrot_0
            cam.rotation_quaternion[1] = FT_OT_Transforms.cam_origrot_1
            cam.rotation_quaternion[2] = FT_OT_Transforms.cam_origrot_2
            cam.rotation_quaternion[3] = FT_OT_Transforms.cam_origrot_3

            ## see if needs fix
            cam.location.x = 0
            cam.location.y = 0
            cam.location.z = 0

        for shape in ao.data.shape_keys.key_blocks:
            shape.value = 0
            #print(shape.name)
            #print(len(ao.data.shape_keys.key_blocks))
        for index, shape in enumerate(ao.data.shape_keys.key_blocks):
            print(index, shape)