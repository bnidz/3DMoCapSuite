#from asyncio import start_server
from multiprocessing import context
import bpy 
from bpy.types import Operator
import socket
#import time
import threading
import array
from math import radians
from bpy.props import *
import select
from . ft_transforms import FT_OT_Transforms
from . ft_panel import FT_PT_Panel
from array import *
#import queue 
from bpy.app.handlers import persistent 

#import ft_panel
#import ft_transforms

class FT_OT_Start_Server(Operator):

    bl_idname = "object.start_server"
    bl_label = "Start server"
    bl_description = "Start the facetracking server"
    isRunning = False
    
    @classmethod
    def poll(cls, context):
        ao = context.object

        if ao is not None:
            if ao.mode == "OBJECT":
                return True
        return False

    def orig_rot(o):
        origrot = o.rotation_euler #{ao.rotation_euler[0],ao.rotation_euler[1],ao.rotation_euler[2]}
        print(origrot)
        return origrot

    firstFrame = True
    firstFrameQ = True
    lastHeadPos_x = None
    lastHeadPos_y = None
    lastHeadPos_z = None
    lastFrameQ_w = None
    lastFrameQ_x = None
    lastFrameQ_y = None
    lastFrameQ_z = None

    HEAD_TARGET_EMPTY = None

    def MakeRigTargets():

        if FT_OT_Start_Server.HEAD_TARGET_EMPTY is None:

            if FT_OT_Start_Server.Rig_Armature is not None:
                ob = FT_OT_Start_Server.Rig_Armature
                FT_OT_Transforms.HEAD_TRACKING_BONE = ob
            else:
                FT_OT_Transforms.useArma = False
                return

    REC = False
    cFirstFrame = True

    camLastpos_x = None
    camLastpos_y = None
    camLastpos_z = None
 
    useArma = False
#    camEmpty = None
    difference_x = None
    difference_y = None
    difference_z = None

    headFirstFrame = True
    headParent = None

    firstHeadPos_x = None
    firstHeadPos_y = None
    firstHeadPos_z = None
    test = False
                  
    ao_origrot_0 = 1
    ao_origrot_1 = 0
    ao_origrot_2 = 0
    ao_origrot_3 = 0

    cam_origrot_0 = 1
    cam_origrot_1 = 0
    cam_origrot_2 = 0
    cam_origrot_3 = 0

    HOST = ""#FT_PT_Panel.scene.IP_property
    PORT =  8080#FT_PT_Panel.scene.PORT_property
    s = socket
    t = threading.Thread
    timeOutCount = 0
    ready = {1}
    _ready = {1} 
    timeOutSeconds = 2
    TRACKING_face = None
    orbiting = False
    TRACKING_cam = None

    arr = array('f')
    
    dick = 9000
    datapacket = None
    justStarted = True

    def server_infinite():

        if FT_OT_Start_Server.justStarted:

            FT_OT_Start_Server.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            FT_OT_Start_Server.s.setblocking(False)
            FT_OT_Start_Server.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            FT_OT_Start_Server.s.bind((FT_OT_Start_Server.HOST,FT_OT_Start_Server.PORT))
            FT_OT_Start_Server.justStarted = False

        FT_OT_Start_Server.ready = select.select([FT_OT_Start_Server.s], [], [], FT_OT_Start_Server.timeOutSeconds)
        
        if FT_OT_Start_Server.ready[0]:
            FT_OT_Start_Server.waitingForConnection = False
            while True:
                try:
                    FT_OT_Start_Server.datapacket = FT_OT_Start_Server.s.recv(265)
                    #FT_OT_Start_Server.dick += 1
                    #print("empyuig", FT_OT_Start_Server.dick)
                except:
                    break

            FT_PT_Panel.enableRec = True
            data = FT_OT_Start_Server.datapacket
            FT_OT_Start_Server.timeOutSeconds = 1
            if(data[264] == 1):
                    FT_PT_Panel.REC_ENABLED = False
                    FT_PT_Panel.enableRec = False
                    #print('NOT NOT NOT PREMIUM')
            if(data[264] == 2):
                if(FT_OT_Transforms.headFirstFrame):
                    FT_PT_Panel.REC_ENABLED = True
                    #print('IS PREMIUM')

            arr = array('f')
            FT_OT_Start_Server.arr = arr
            FT_OT_Start_Server.arr.frombytes(data[:264])

            if(len( FT_OT_Start_Server.arr) == 66):
                if FT_OT_Start_Server.context.scene.track_face_rot:
                    FT_OT_Transforms.head_rotation_q( FT_OT_Start_Server.arr[0],  FT_OT_Start_Server.arr[1],  FT_OT_Start_Server.arr[2],  FT_OT_Start_Server.arr[3])
                if FT_OT_Start_Server.context.scene.track_face_pos:
                    FT_OT_Transforms.moveHead( FT_OT_Start_Server.arr[4],  FT_OT_Start_Server.arr[5],  FT_OT_Start_Server.arr[6])
                if FT_OT_Start_Server.context.scene.track_cam:
                    FT_OT_Transforms.moveCamera( FT_OT_Start_Server.arr[7],  FT_OT_Start_Server.arr[8],  FT_OT_Start_Server.arr[9],  FT_OT_Start_Server.arr[10],  FT_OT_Start_Server.arr[11],  FT_OT_Start_Server.arr[12],  FT_OT_Start_Server.arr[13])
                FT_OT_Transforms.process_bs(FT_OT_Start_Server.arr[13:])
            FT_OT_Start_Server.shit = True

            return {'FINISHED'}

        else:

            FT_OT_Start_Server.timeOutCount += 1
            if FT_OT_Start_Server.timeOutCount <= 29:

                FT_OT_Start_Server.timeOutStop()

    def sendClosingBytes():

        y = 'STOP'
        bytes = y.encode()
        print("mesg len in bytes : ", len(bytes))
        exsHOST = "127.0.0.1"
        exs = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        exs.setblocking(0)
        exs.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        exs.bind((exsHOST,FT_OT_Start_Server.PORT))
        exs.sendto(bytes, (FT_OT_Start_Server.HOST,FT_OT_Start_Server.PORT))
        print("sent closing bytes")
        exs.close()
        return {'FINISHED'}        

    TRACKING_ROT = None
    context = None

    justStarted = False

    def run_in_main_thread(function):
        FT_OT_Start_Server.execution_queue.put(function)


    def execute_queued_functions(interval):
        while not FT_OT_Start_Server.execution_queue.empty():
            #function = FT_OT_Start_Server.execution_queue.get()
            FT_OT_Start_Server.execution_queue.get()
            #function()
        return interval

    def timeOutStop():

        ### SHOW START BUTTON
        FT_PT_Panel.enableRec == False
        print("timeout cancel activated")
        FT_OT_Start_Server.justStarted = False
        bpy.ops.screen.animation_cancel(False)
        FT_OT_Transforms.reset_blendShapes(FT_OT_Start_Server.TRACKING_cam, FT_OT_Transforms.HEAD_TRACKING_BONE, FT_OT_Start_Server.TRACKING_face)

        FT_PT_Panel.enableStart = True
        FT_OT_Start_Server.waitingForConnection = True

        FT_OT_Start_Server.REC = False
        FT_PT_Panel.enableStart = True
        FT_PT_Panel.enableRec = False
        FT_OT_Start_Server.shit = False
        FT_OT_Transforms.cFirstFrame = True
        FT_OT_Transforms.headFirstFrame = True
        FT_OT_Transforms.firstFrameQ = True
        
        return {'FINISHED'}

    def execute(self, context):
        
       # FT_OT_Start_Server.reset_blendShapes()
        FT_OT_Start_Server.timeOutCount = 0
        FT_OT_Start_Server.waitingForConnection = True
        FT_OT_Start_Server.context = context
        FT_OT_Start_Server.HOST = context.scene.IP_property
        FT_OT_Start_Server.PORT = context.scene.PORT_property
        FT_OT_Start_Server.timeOutCount = 0
        ## set bools
        FT_OT_Start_Server.Rig_Armature = context.scene.Rig_Armature
        FT_OT_Start_Server.MakeRigTargets()
        FT_OT_Start_Server.timeOutSeconds = 1
        FT_OT_Transforms.firstFrameQ = True
        FT_OT_Transforms.headFirstFrame = True
        FT_OT_Start_Server.stop_threads = True
        FT_OT_Start_Server.isEnding = False
        FT_OT_Transforms.cFirstFrame = True
        FT_OT_Transforms.REC = False
        ### --- Update tracking HEAD object
        bpy.ops.screen.animation_play()
        FT_OT_Start_Server.TRACKING_face = context.scene.TRACKING_face
        FT_OT_Start_Server.TRACKING_cam = context.scene.TRACKING_cam
        FT_OT_Transforms.TRACKING_face = context.scene.TRACKING_face
        FT_OT_Transforms.TRACKING_cam = context.scene.TRACKING_cam

        FT_OT_Transforms.save_initial_values()

        FT_PT_Panel.enableStart = False
        FT_PT_Panel.enableStop = True
        FT_OT_Start_Server.shit = True
        FT_OT_Start_Server.justStarted = True
        #this_class = FT_OT_Start_Server
        return {'FINISHED'} 

    shit = False
    waitingForConnection = False
    Rig_Armature = None

    HEAD_TRACKING_BONE = None



class FT_OT_Stop_Server(Operator):

    bl_idname = "object.stop_server"
    bl_label = "Stop server"
    bl_description = "Stop the facetracking server"

    def execute(self, context):
        
        ### SHOW START BUTTON

        FT_OT_Start_Server.justStarted = False
        FT_OT_Start_Server.REC = False
        bpy.ops.screen.animation_cancel(False)
        FT_OT_Start_Server.shit = False

        FT_OT_Start_Server.timeOutStop()
        return {'FINISHED'}

@persistent
def FT_RUN_Server_Cycle(dummy1,dummy2):

    if(FT_OT_Start_Server.shit == True):
        FT_OT_Start_Server.server_infinite()

    return {'FINISHED'}

bpy.app.handlers.frame_change_post.append(FT_RUN_Server_Cycle)

class FT_OT_Start_Recording(Operator):

    bl_idname = "object.start_rec"
    bl_label = "Start REC"
    bl_description = "Start recording keyframes"

    def execute(self, context):
        if FT_PT_Panel.REC_ENABLED == False:
            print("no rec should be available")
            FT_PT_Panel.enableRec = False
            return {'FINISHED'}          
                                           
        print("rec")
        print(FT_PT_Panel.REC_ENABLED)
        FT_OT_Transforms.REC = True
        FT_PT_Panel.REC_running = True
        FT_PT_Panel.enableRec = False
        return {'FINISHED'}

class FT_OT_Stop_Recording(Operator):

    bl_idname = "object.stop_rec"
    bl_label = "Stop Rec"
    bl_description = "Stop recording keyframes"

    def execute(self, context):
        
        FT_OT_Transforms.REC = False
        FT_PT_Panel.REC_running = False
        
        #FT_PT_Panel.enableRec = True
        print("rec")
        return {'FINISHED'}  

class FT_OT_ResetCharPos(Operator):

    bl_idname = "object.reset_char"
    bl_label = "Reset Char"
    bl_description = "Reset char if rig"

    def execute(self, context):
        
        ### Here code for char pos reset
        return {'FINISHED'}  